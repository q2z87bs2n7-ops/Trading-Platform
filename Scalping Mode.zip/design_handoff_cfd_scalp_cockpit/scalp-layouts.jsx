// ── CFD Scalp — three device layouts (Desktop/landscape · iPad portrait · Mobile)
const { useState, useContext } = React;
const TF_LIST = ["1m", "5m", "15m", "1H"];

function CenterPane({ sym }) {
  const ctx = useContext(ScalpCtx);
  const [tf, setTf] = useState("1m");
  const q = ctx.quotes[sym];
  const { big, pips, frac } = splitBigFig(q.mid, q.digits, q.pointSize);
  return (
    <div className="sc-pane sc-center">
      <div className="sc-pane-head">
        <span>{sym} · {tf}</span><span className="grow" />
        <span className="sc-tf">{TF_LIST.map((t) => <b key={t} className={t === tf ? "on" : ""} onClick={() => setTf(t)}>{t}</b>)}</span>
      </div>
      <div className="sc-center-body">
        <div className="sc-chart-wrap">
          <MockCandles w={560} h={250} trend={q.flash === "dn" ? "down" : "up"} seed={sym.charCodeAt(0) + sym.length} />
          <div className="sc-last-tag">{big}{pips}{frac && <sup>{frac}</sup>}</div>
        </div>
        <DealStrip sym={sym} />
      </div>
    </div>
  );
}

// ════ DESKTOP / iPad landscape ═══════════════════════════════════════════
function DesktopLayout() {
  const ctx = useContext(ScalpCtx);
  return (
    <div className="sc-root" data-theme={ctx.theme} data-density={ctx.t.density} style={{ height: "100%", ...ctx.rootStyle }}>
      <div className="sc-desktop">
        <TopBar />
        <div className="sc-grid">
          <RateMatrix />
          <CenterPane sym={ctx.sel} />
          <PositionInfo sym={ctx.sel} />
        </div>
        <Blotter className="sc-blotter" />
      </div>
    </div>
  );
}

// ════ iPad PORTRAIT ══════════════════════════════════════════════════════
function TabletLayout() {
  const ctx = useContext(ScalpCtx);
  return (
    <div className="sc-root" data-theme={ctx.theme} data-density={ctx.t.density} style={{ height: "100%", ...ctx.rootStyle }}>
      <div className="sc-tablet">
        <TopBar />
        <div className="sc-row1">
          <CenterPane sym={ctx.sel} />
          <PositionInfo sym={ctx.sel} />
        </div>
        <div className="sc-row2">
          <RateMatrix />
          <Blotter />
        </div>
      </div>
    </div>
  );
}

// ════ MOBILE PORTRAIT ════════════════════════════════════════════════════
function MobileLayout() {
  const ctx = useContext(ScalpCtx);
  const [tf, setTf] = useState("1m");
  const q = ctx.quotes[ctx.sel];
  const { big, pips, frac } = splitBigFig(q.mid, q.digits, q.pointSize);
  return (
    <div className="sc-root" data-theme={ctx.theme} data-density={ctx.t.density} style={{ height: "100%", ...ctx.rootStyle }}>
      <div className="sc-mobile">
        <div className="sc-m-top">
          <span className="sc-brand"><span className="bolt">⚡</span> Scalp</span>
          <span className="sc-live"><span className="dot" /> Live</span>
          <span className="grow" style={{ flex: 1 }} />
          <span className="sc-stat" style={{ alignItems: "flex-end" }}>
            <span className="sc-stat-lbl">Open P/L</span>
            <span className="sc-stat-val mono" style={{ color: ctx.account.openPl >= 0 ? "var(--pos)" : "var(--neg)" }}>{signed(ctx.account.openPl)}</span>
          </span>
          <button className={"sc-oneclick" + (ctx.oneClick ? " on" : "")} style={{ padding: "5px 8px" }} onClick={() => ctx.setOneClick((v) => !v)}>
            <span className="tog"><span className="knob" /></span>⚡
          </button>
          <button className="sc-iconbtn" onClick={ctx.toggleTheme}>{ctx.theme === "dark" ? "☾" : "☀"}</button>
        </div>

        <div className="sc-m-scroll">
          <div className="sc-m-chips">
            {SEED.map((s) => {
              const qq = ctx.quotes[s.sym];
              return (
                <div key={s.sym} className={"sc-m-chip" + (ctx.sel === s.sym ? " sel" : "")} onClick={() => ctx.setSel(s.sym)}>
                  <span className="s">{s.sym}</span>
                  <span className={"q mono " + (qq.flash === "up" ? "up" : qq.flash === "dn" ? "dn" : "")}>{qq.mid.toFixed(qq.digits)}</span>
                  <span className="sp mono">{spreadPips(qq.bid, qq.ask, qq.pointSize)}p</span>
                </div>
              );
            })}
          </div>

          <div className="sc-m-card">
            <div className="sc-m-card-head"><span>{ctx.sel} · {tf}</span><span className="grow" style={{ flex: 1 }} />
              <span className="sc-tf">{TF_LIST.map((t) => <b key={t} className={t === tf ? "on" : ""} onClick={() => setTf(t)}>{t}</b>)}</span>
            </div>
            <div className="sc-m-chart" style={{ position: "relative" }}>
              <div className="sc-chart-wrap" style={{ borderRadius: 0, border: "none" }}>
                <MockCandles w={360} h={150} trend={q.flash === "dn" ? "down" : "up"} seed={ctx.sel.charCodeAt(0) + ctx.sel.length} />
                <div className="sc-last-tag">{big}{pips}{frac && <sup>{frac}</sup>}</div>
              </div>
            </div>
          </div>

          <div className="sc-lots" style={{ justifyContent: "space-between" }}>
            <span className="lbl">Size</span>
            {(q.pointSize < 1 ? LOTS.fx : LOTS.idx).map((l) => (
              <button key={l} className={"sc-lot" + (lotValue(ctx.sel, l) === ctx.lot ? " on" : "")} style={{ flex: 1 }} onClick={() => ctx.setLot(lotValue(ctx.sel, l))}>{l}</button>
            ))}
          </div>

          <PositionInfo sym={ctx.sel} />
          <Blotter />
        </div>

        <div className="sc-m-dock">
          <DealStrip sym={ctx.sel} size={1.05} />
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { DesktopLayout, TabletLayout, MobileLayout, CenterPane });
