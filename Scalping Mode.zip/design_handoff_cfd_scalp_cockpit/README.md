# Handoff: CFD "Scalp" Mode — Cockpit

## Overview
Scalp is the one high-energy, fast-execution room in an otherwise calm, investing-oriented
paper-trading platform (Stocks · Crypto · CFD silos). This handoff covers the **Cockpit**
direction: a dense, multi-pane CFD dealing terminal built for hardcore scalpers — live
bid/ask tape, one-click fire/flatten, and at-a-glance position management — without tipping
into "casino" gimmickry. It must still read as the same product family as the calm surfaces.

The design targets the existing `CfdScalpPage.tsx` surface in `q2z87bs2n7-ops/Trading-Platform`
(branch `claude/cfd-scalping-mode-proposal-bJ0KX`). It is a **redesign of the existing
functional wireframe**, not a greenfield screen.

## About the Design Files
The files in this bundle are **design references created in HTML/React + Babel** — prototypes
showing the intended look and behavior. **They are not production code to copy directly.**
The task is to **recreate these designs in the Trading-Platform codebase** (React + TypeScript,
lightweight-charts, FXCM/fclite SDK) using its established patterns, components, and data
hooks. Lift exact values — colors, type, spacing, radii — from this README and `scalp.css`.

The prototype runs a **mock quote engine** (≈850ms polling, random-walk bid/ask with a
spread jitter). In production this maps to the existing ~1s FXCM demo polling. Do not ship
the mock engine; wire the real feed.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, radii, motion, and interaction model.
Recreate pixel-faithfully using the codebase's libraries. The only deliberately "stub"
element is **SL/TP entry** (visual only, per the brief) — keep it visual until bracket
orders are supported server-side.

## Form Factors
Three bespoke layouts, one shared session/state model. Breakpoints are by available width:

| Form factor | Design size | When |
|---|---|---|
| **Desktop / iPad landscape** | 1440×940 (fluid ≥1180px) | Three-pane cockpit + full-width blotter |
| **iPad portrait** | 834×1112 | Chart+deal & position top row; matrix + blotter bottom row |
| **Mobile portrait** | 390×844 | Stacked, with a sticky bottom Buy/Sell dock |

---

## Screens / Views

### A. Desktop / iPad-landscape Cockpit
**Purpose:** the primary scalping surface — watch the tape, fire, manage, all without scrolling.

**Layout:** vertical flex, `gap: var(--gap)` (10px dense / 14px roomy), `padding: var(--gap)`.
1. **Top bar** (`.sc-bar`, fixed height ~46px) — full width.
2. **Main grid** (`.sc-grid`, flex:1) — CSS grid `grid-template-columns: 300px 1fr 296px; gap: var(--gap)`:
   - **Left:** Rate Matrix pane
   - **Center:** Chart + Deal strip pane
   - **Right:** Position info pane
3. **Blotter** (`.sc-blotter`, flex:none, `max-height: 200px`) — full width, "Open Positions".

#### Top bar (`.sc-bar`)
Left → right, `display:flex; align-items:center; gap:12px; padding:8px 13px`:
- **Brand** `⚡ Scalp` — Inter 700 15px; the bolt is `var(--accent)` with a soft glow
  (`drop-shadow(0 0 6px var(--accent-glow))`).
- **Live pill** (`.sc-live`) — uppercase 10px/600, `color/bg var(--accent)/var(--accent-bg)`,
  `border-radius:999px`, with a 6px pulsing dot (`@keyframes scpulse`, 1.9s).
- **Divider** (`.sc-div`) 1px `var(--border)`.
- **Stats** (`.sc-stat`) — three stacked label/value pairs: **Equity**, **Free margin**,
  **Open P/L**. Label 8.5px uppercase `var(--mute)`; value 13px/600 **mono**. Open P/L value
  is `var(--pos)`/`var(--neg)` by sign.
- *(spacer)*
- **Hotkey hint** (`.sc-kbd`, only if hint tweak on) — mono 10px `var(--mute)`:
  `B buy · S sell · F flatten · ⎵ confirm`.
- **Size selector** (`.sc-lots`) — label "Size" + 4 lot chips (`.sc-lot`). Active chip:
  `var(--accent)` border + `var(--accent-bg)` + `var(--accent)` text. FX uses 1K/10K/50K/100K;
  indices/metals/crypto use 1/5/10/25 (contracts).
- **Safety toggle** (`.sc-oneclick`) — pill with a 26×15 sliding switch; **1-click** (on,
  accent) vs **Confirm** (off). See Interactions.
- **Theme button** (`.sc-iconbtn`, 30×30) — ☾ in dark / ☀ in light.

#### Rate Matrix (left, `.sc-pane` + `.sc-mx-*`)
- Pane header "Rate Matrix" + count badge.
- Header row + one row per instrument. Grid columns:
  `grid-template-columns: 1fr 1.15fr .55fr 1.15fr .85fr` → **Instr · Sell(bid) · Spr · Buy(ask) · P/L**.
- **Sell** cell is `var(--neg)`, **Buy** cell is `var(--pos)`. Prices use the **big-figure
  split** (see Design Tokens → Number formatting), rendered at `size=0.6`.
- **Tick flash:** on each tick a crossed side gets `.flash-up`/`.flash-dn` — a background
  wash of `var(--pos-bg)`/`var(--neg-bg)`, with opacity scaled by the **motion** tweak via
  `color-mix` and `--flash-a`. A **dead-band** of `pointSize*0.25` suppresses noise flashes.
- **Spread** (`.sc-mx-spread`) mono 10px, centered; `.tight` (≤90% of typical) → `var(--pos)`,
  `.wide` (≥112%) → `var(--neg)`, else `var(--mute)`.
- **P/L** column shows the net open P/L for that instrument (mono, signed, pos/neg color) or `·` if flat.
- Selected row: `.sel` → `var(--accent-soft)` bg + `inset 2px 0 0 var(--accent)` left rail.
- Click a row → selects the instrument (drives chart, deal strip, position pane).
- Footer "+ Add instrument" (`.sc-add`, `var(--accent)`).

#### Center — Chart + Deal (`.sc-center`)
- Pane header: `SYM · {tf}` left; timeframe switcher right (`.sc-tf` — 1m/5m/15m/1H,
  active = `var(--accent)`).
- **Chart** (`.sc-chart-wrap`, flex:1) — candlestick chart. In prod use **lightweight-charts**
  inline (the prototype draws mock candles in SVG). Up candles `var(--pos)`, down `var(--neg)`.
  A **last-price tag** (`.sc-last-tag`) floats at right: `var(--accent)` bg, dark text, mono,
  big-figure split with the fractional-pip as `<sup>`.
- **Deal strip** (`.sc-deal-row`) below the chart: **Sell | spread | Buy**.
  - Buttons (`.sc-deal`) fill the row. Buy: `var(--pos-bg)` + `inset 0 0 0 1px var(--pos-line)`,
    text `var(--pos)`. Sell mirrors with neg. `border-radius:11px`, `padding:13px 10px`.
  - Each button shows label ("Buy"/"Sell", or "Tap to confirm" when armed) + the dealable
    price (Buy=ask, Sell=bid) in big-figure split.
  - A small directional tick glyph (▲/▼) fades in on a matching flash (`.show-tick`).
  - **Center mid** (`.sc-deal-mid`): big accent number = live spread (pips), label "spread",
    and a sub-label showing current mode ("1-click"/"confirm").
  - Fire feedback: `.sc-fired` runs a 0.4s `@keyframes scfire` ripple of `currentColor`.

#### Right — Position info (`.sc-pane.sc-posinfo`)
Shows the **aggregate net position for the selected instrument** (multiple fills collapse
to one net side/size/avg — see Open Questions).
- Header "Position · SYM".
- **Empty state** (`.sc-pi-empty`): centered ⚡ glyph + "No open position in SYM / Fire a Buy or Sell to open one."
- **Populated** (`.sc-pi-body`, `gap:11px`):
  - **Hero**: symbol (17px/700) + full name (`var(--mute)`).
  - **Net card** (`.sc-pi-net`): LONG/SHORT tag (`.sc-side-tag .b/.s`, pos/neg bg), size +
    "avg {price}" (and "{n} fills ·" if aggregated), and right-aligned live P&L (18px/700,
    pos/neg) + pips line.
  - **Metric grid** (`.sc-pi-grid`, 2×2 `.sc-pi-cell`): Mark (bid), Mark (ask), Spread (pips), Margin.
  - **Risk bracket** (`.sc-pi-sltp`) — labelled "visual stub". Two fields (`.sc-field`):
    **SL** tag (`var(--neg)`) and **TP** tag (`var(--pos)`), each a mono input with a placeholder
    derived from current price ±20/35 pips and a "−20p"/"+35p" hint. **Not wired** — visual only.
  - **Actions** (`.sc-pi-actions`): **Reverse** (neutral `.sc-btn`) and **Close long/short**
    (`.sc-btn.danger`, neg).

#### Blotter (`.sc-blotter`, bottom)
- Header "Open Positions" + count, right side shows net open P/L (mono, pos/neg) and a
  **⚡ Flatten all** button (`.sc-flatten`, neg styling) when not flat.
- Header row + one row per fill. Grid columns:
  `26px 1fr 1fr 1.2fr 1fr 1fr 24px` → **side-tag · Instr · Side · Size(right) · Open(right) · P/L(right) · ✕**.
- Side tag is the compact B/S chip. P/L mono, pos/neg, live. Row click selects that instrument.
  ✕ closes that single fill (`closeOne`). Empty state: "Flat — no open positions."

### B. iPad portrait (`.sc-tablet`)
Same panes, re-stacked: TopBar → **row1** (`grid-template-columns: 1fr 320px`, flex:1.1):
Center (chart+deal) | Position info → **row2** (`1fr 1fr`, flex:.9): Rate Matrix | Blotter.

### C. Mobile portrait (`.sc-mobile`)
- **Compact top** (`.sc-m-top`): brand, Live pill, right-aligned Open P/L stat, a compact
  safety toggle (⚡), theme button.
- **Scroll body** (`.sc-m-scroll`, `padding-bottom:84px` to clear the dock):
  - **Instrument chip strip** (`.sc-m-chips`, horizontal scroll) — each chip (`.sc-m-chip`,
    min-width 96px) shows symbol, mid price (flash-tinted up/dn), spread. Selected chip gets
    `var(--accent)` border + ring.
  - **Chart card** (`.sc-m-card`) with its own header + timeframe switcher, 150px chart.
  - **Size selector** row (lot chips stretched full width).
  - **Position info** pane (same component).
  - **Blotter** pane (same component).
- **Sticky dock** (`.sc-m-dock`, absolute bottom): the Deal strip at `size=1.05`, over a
  `linear-gradient(180deg, transparent, var(--bg))` fade, with `env(safe-area-inset-bottom)` padding.

---

## Interactions & Behavior

- **Live quotes:** poll/stream bid/ask per instrument. On each update compute mid; if mid
  moved more than the dead-band (`pointSize*0.25`) flag `flash:"up"|"dn"` for one cycle, then
  clear (~320ms after the tick in the prototype). Spread = `(ask−bid)/pointSize`, with a small
  per-tick jitter in the mock.
- **Instrument selection:** clicking a matrix row, a mobile chip, or any blotter row sets the
  active instrument; chart, deal strip, and position pane all follow.
- **Fire (one-click vs confirm):** governed by the safety toggle / `safety` tweak.
  - **1-click:** a single Buy/Sell click immediately opens a position at the dealable price
    (Buy fills at ask, Sell at bid) and prepends it to the blotter.
  - **Confirm:** first click **arms** that side (label → "Tap to confirm", auto-disarms after
    2.6s); a second click on the armed side fires. Clicking the other side re-arms it instead.
- **Lot/size:** the active lot chip sets order size (FX in units: 1K–100K; indices/metals/crypto
  in contracts: 1–25). Size is shared across layouts.
- **Manage:** per-fill ✕ closes one fill; **Flatten all** clears every position; the position
  pane's **Close long/short** flattens the selected symbol; **Reverse** flips each fill's side
  and re-opens at the current dealable price.
- **Hotkeys** (desktop): `B` buy · `S` sell · `F` flatten — all on the selected instrument.
  Suppressed while focus is in an input. Hint string toggled by the `hotkeys` tweak.
- **Theme:** ☾/☀ toggles dark/light across the whole surface (`data-theme` on `.sc-root`).
- **P&L math (prototype):** `(closePx − open) * sideSign * amount * PLSCALE[sym]`, where Buy
  closes on bid, Sell closes on ask. `PLSCALE` is a rough per-instrument $/point factor for
  feel only — replace with the real contract/pip-value math.
- **Motion (tweak):** `calm` → `--flash-a:0.45`, `normal` → `0.8`, `loud` → `1`. Scales flash
  wash opacity only; layout never moves.
- **SL/TP:** visual stub. Inputs accept text but do not place orders.

## State Management
Single session model (in the prototype, `useScalpEngine` + context). Needed state:
- `quotes[sym]`: `{ bid, ask, mid, spread, digits, pointSize, flash, trail }` — driven by feed.
- `sel`: selected instrument symbol.
- `positions[]`: `{ id, sym, side:"B"|"S", amount, open }` (one entry per fill).
- `lot`: current order size; `oneClick`/`safety`: fire mode; `theme`.
- Derived: per-symbol net (side/size/avg/pl/pips/fills), account roll-up
  (`equity = balance + openPl`, `freeMargin`, `marginLevel`, `usedMargin`).
- Actions: `setSel`, `fire(sym,side,amount)`, `closeOne(id)`, `reverse(id)`, `flattenAll()`,
  `flattenSym(sym)`.
In production, wire `quotes` to the FXCM/fclite polling hook and `positions`/actions to the
demo dealing endpoints already used by `CfdScalpPage.tsx`.

## Design Tokens
From `scalp.css` (Calm v2). Fonts: **Inter** (UI) + **IBM Plex Mono** (all numbers,
`font-variant-numeric: tabular-nums`).

### Colors — Dark (default)
| Token | Value |
|---|---|
| `--bg` | `#0a0c10` |
| `--panel` | `#111418` |
| `--panel-2` | `#181c22` |
| `--panel-3` | `#20262e` |
| `--border` | `#1f242c` |
| `--border-2` | `#2f3640` |
| `--hairline` | `rgba(255,255,255,.065)` |
| `--text` | `#e7ebf0` |
| `--text-2` | `#a6acb6` |
| `--mute` | `#676d77` |
| `--pos` | `oklch(70% .15 158)` |
| `--neg` | `oklch(70% .18 26)` |
| `--accent` (CFD) | `oklch(74% .175 58)` → brief's `oklch(72% 0.18 55)` family (amber/orange) |

### Colors — Light
| Token | Value |
|---|---|
| `--bg` | `#eef0f3` |
| `--panel` | `#ffffff` |
| `--panel-2` | `#f5f6f8` |
| `--border` | `#e2e5ea` |
| `--text` | `#161a20` |
| `--text-2` | `#5b626d` |
| `--mute` | `#9aa0aa` |
| `--pos` | `oklch(52% .14 158)` |
| `--neg` | `oklch(55% .19 26)` |
| `--accent` | `oklch(60% .185 54)` |

Accent is parameterized: `--accent = oklch(var(--acc-l) calc(var(--acc-c) * var(--acc-mult)) var(--acc-h))`.
The **accent** tweak scales `--acc-mult` (subtle 0.78 / normal 1 / punchy 1.28). Derived:
`--accent-2`, `--accent-bg` (/.14), `--accent-soft` (/.08), `--accent-glow` (/.34).

### Spacing / radius / type
- Density vars: dense → `--gap:10px; --pane-pad-y:7px; --pane-pad-x:12px; --row-y:7px`;
  roomy → `14 / 10 / 15 / 10`.
- Radii: panes `11px`, deal buttons `11px`, cells/fields `8–10px`, chips/pills `999px` or `6–8px`.
- Type scale (px): brand 15 · pane labels 10 (uppercase, .07em) · matrix sym 12 · stat val 13 ·
  deal mid 17 · position hero 17 · position P/L 18 · micro labels 8.5 (uppercase).
- Shadows: dark `--shadow:0 10px 34px rgba(0,0,0,.4)`, `--shadow-sm:0 1px 2px rgba(0,0,0,.35)`;
  light `0 8px 26px rgba(20,26,40,.1)` / `0 1px 2px rgba(20,26,40,.06)`.

### Number formatting — big-figure split
Ported in `scalp-data.jsx` as `splitBigFig(value, digits, pointSize)` (mirrors the real
`CfdScalpPage.tsx`). Splits a price into **handle** (dim, 60% opacity, ~15px), **big-pips**
(bold, ~26px), and **fractional-pip** (small superscript, ~12px). `pipDecimals` derives from
`pointSize`. Always render prices through this, never a flat `toFixed`.

## Assets
None external. Brand mark is the **⚡ glyph** (text). Chart uses **lightweight-charts** in
production (mock SVG candles in the prototype). Use the codebase's existing icon set for ☾/☀/✕.
Fonts via Google Fonts (Inter, IBM Plex Mono) — swap to the app's bundled copies.

## Files (in this bundle)
- `Scalp Cockpit.html` — entry point; design_canvas with the 3 artboards + Tweaks panel.
- `scalp.css` — **all tokens + component styles** (the source of truth for visuals).
- `scalp-data.jsx` — mock quote engine, big-figure split, formatters, mock chart/spark.
- `scalp-parts.jsx` — shared components: DealStrip, RateMatrix, ChartPane, PositionInfo, Blotter, TopBar.
- `scalp-layouts.jsx` — the three device layouts (Desktop, Tablet/portrait, Mobile).
- `tweaks-panel.jsx`, `design-canvas.jsx` — prototype scaffolding only; **not** part of the
  production feature (the canvas just presents the three form factors side by side).

## Open Questions (carried from design)
1. **Position pane aggregation:** the right pane shows the *net* position per instrument
   (fills collapsed). Confirm vs. showing individual fills.
2. **Mobile fire placement:** Buy/Sell is a sticky bottom dock. Confirm vs. inline under chart.
3. **SL/TP:** stub until bracket orders exist server-side — confirm scope.
4. **Sound:** intentionally omitted from the mock; the brief allows fill/alert chimes with a
   mute toggle in the real product.
