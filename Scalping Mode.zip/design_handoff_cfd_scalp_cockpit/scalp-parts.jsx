// ── CFD Scalp — shared UI parts (consume ScalpCtx) ───────────────────────────
const { useContext, useState, useEffect, useRef, useCallback } = React;

// aggregate net position per symbol
function netForSym(positions, sym, plOf, pipsOf, quotes) {
  const ps = positions.filter((p) => p.sym === sym);
  if (!ps.length) return null;
  let buy = 0, sell = 0, costB = 0, costS = 0, pl = 0;
  for (const p of ps) {
    pl += plOf(p, quotes);
    if (p.side === "B") { buy += p.amount; costB += p.amount * p.open; }
    else { sell += p.amount; costS += p.amount * p.open; }
  }
  const net = buy - sell;
  const side = net >= 0 ? "B" : "S";
  const amount = Math.abs(net) || (buy + sell);
  const avg = side === "B" ? (costB / (buy || 1)) : (costS / (sell || 1));
  const pips = ps.reduce((a, p) => a + pipsOf(p, quotes) * p.amount, 0) / (ps.reduce((a, p) => a + p.amount, 0) || 1);
  return { side, amount, avg, pl, pips, count: ps.length };
}

// ════ Deal strip — Buy / spread / Sell with one-click vs confirm gating ════
function DealStrip({ sym, size = 1, vertical = false }) {
  const ctx = useContext(ScalpCtx);
  const q = ctx.quotes[sym];
  const [armed, setArmed] = useState(null); // 'B' | 'S' | null
  const [fired, setFired] = useState(null);
  const armTimer = useRef();
  if (!q) return null;

  const doFire = (side) => {
    ctx.fire(sym, side, ctx.lot);
    setFired(side); setArmed(null);
    setTimeout(() => setFired((f) => (f === side ? null : f)), 400);
  };
  const onClick = (side) => {
    if (ctx.oneClick) { doFire(side); return; }
    if (armed === side) { doFire(side); return; }
    setArmed(side);
    clearTimeout(armTimer.current);
    armTimer.current = setTimeout(() => setArmed(null), 2600);
  };

  const Btn = ({ side }) => {
    const isBuy = side === "B";
    const px = isBuy ? q.ask : q.bid;
    const flash = isBuy ? (q.flash === "up" ? "show-tick" : "") : (q.flash === "dn" ? "show-tick" : "");
    return (
      <button className={"sc-deal " + (isBuy ? "buy" : "sell") + " " + flash + (fired === side ? " sc-fired" : "")}
        onClick={() => onClick(side)}>
        <span className="sc-deal-tick">{isBuy ? "▲" : "▼"}</span>
        <span className="sc-deal-lbl">{armed === side ? "Tap to confirm" : (isBuy ? "Buy" : "Sell")}</span>
        <BigFig value={px} digits={q.digits} pointSize={q.pointSize} size={0.92 * size} />
      </button>
    );
  };

  const spread = spreadNum(q.bid, q.ask, q.pointSize);
  return (
    <div className="sc-deal-row" style={vertical ? { flexDirection: "column" } : null}>
      <Btn side="S" />
      <div className="sc-deal-mid">
        <span className="num mono">{spread >= 100 ? spread.toFixed(0) : spread.toFixed(1)}</span>
        <span className="lbl">spread</span>
        <span className="arm">{ctx.oneClick ? "1-click" : "confirm"}</span>
      </div>
      <Btn side="B" />
    </div>
  );
}

// ════ Rate matrix ═════════════════════════════════════════════════════════
function RateMatrix({ compact }) {
  const ctx = useContext(ScalpCtx);
  const syms = SEED.map((s) => s.sym);
  return (
    <div className="sc-pane">
      <div className="sc-pane-head">Rate Matrix <span className="cnt">{syms.length}</span></div>
      <div className="sc-mx-grid">
        <div className="sc-mx-row head">
          <span>Instr</span><span style={{ textAlign: "center" }}>Sell</span><span style={{ textAlign: "center" }}>Spr</span>
          <span style={{ textAlign: "center" }}>Buy</span><span style={{ textAlign: "right" }}>P/L</span>
        </div>
        {syms.map((sym) => {
          const q = ctx.quotes[sym];
          const net = netForSym(ctx.positions, sym, ctx.plOf, ctx.pipsOf, ctx.quotes);
          const spr = spreadNum(q.bid, q.ask, q.pointSize);
          const sprCls = spr <= q.spread * 0.9 ? "tight" : spr >= q.spread * 1.12 ? "wide" : "";
          return (
            <div key={sym} className={"sc-mx-row" + (ctx.sel === sym ? " sel" : "")} onClick={() => ctx.setSel(sym)}>
              <span className="sc-mx-sym">{sym}</span>
              <span className={"sc-q bid" + (q.flash === "dn" ? " flash-dn" : "")}>
                <BigFig value={q.bid} digits={q.digits} pointSize={q.pointSize} size={0.6} color="inherit" />
              </span>
              <span className={"sc-mx-spread mono " + sprCls}>{spr >= 100 ? spr.toFixed(0) : spr.toFixed(1)}</span>
              <span className={"sc-q ask" + (q.flash === "up" ? " flash-up" : "")}>
                <BigFig value={q.ask} digits={q.digits} pointSize={q.pointSize} size={0.6} color="inherit" />
              </span>
              <span className="sc-mx-pl mono" style={{ color: net ? (net.pl >= 0 ? "var(--pos)" : "var(--neg)") : "var(--mute)" }}>
                {net ? signed(net.pl) : "·"}
              </span>
            </div>
          );
        })}
        <div className="sc-add">+ Add instrument</div>
      </div>
    </div>
  );
}

// ════ Chart pane ══════════════════════════════════════════════════════════
const TFS = ["1m", "5m", "15m", "1H"];
function ChartPane({ sym, headInline }) {
  const ctx = useContext(ScalpCtx);
  const q = ctx.quotes[sym];
  const [tf, setTf] = useState("1m");
  const { big, pips, frac } = splitBigFig(q.mid, q.digits, q.pointSize);
  return (
    <React.Fragment>
      {!headInline && (
        <div className="sc-pane-head">
          <span>{sym} · {tf}</span><span className="grow" />
          <span className="sc-tf">{TFS.map((t) => <b key={t} className={t === tf ? "on" : ""} onClick={() => setTf(t)}>{t}</b>)}</span>
        </div>
      )}
      <div className="sc-chart-wrap">
        <MockCandles w={560} h={250} trend={q.mid >= q.bid ? "up" : "down"} seed={sym.charCodeAt(0) + sym.length} />
        <div className="sc-last-tag">{big}{pips}{frac && <sup>{frac}</sup>}</div>
      </div>
    </React.Fragment>
  );
}

// ════ Position info (right pane) ═════════════════════════════════════════
function PositionInfo({ sym }) {
  const ctx = useContext(ScalpCtx);
  const q = ctx.quotes[sym];
  const net = netForSym(ctx.positions, sym, ctx.plOf, ctx.pipsOf, ctx.quotes);
  return (
    <div className="sc-pane sc-posinfo">
      <div className="sc-pane-head">Position · {sym}</div>
      {!net ? (
        <div className="sc-pi-empty">
          <span className="big">⚡</span>
          <div>No open position in <b style={{ color: "var(--text-2)" }}>{sym}</b></div>
          <div style={{ fontSize: 11 }}>Fire a Buy or Sell to open one.</div>
        </div>
      ) : (
        <div className="sc-pi-body">
          <div className="sc-pi-hero">
            <span className="sc-pi-sym">{sym}</span>
            <span className="sc-pi-name">{q.name}</span>
          </div>
          <div className="sc-pi-net">
            <span className={"sc-side-tag " + (net.side === "B" ? "b" : "s")}>{net.side === "B" ? "LONG" : "SHORT"}</span>
            <div className="sc-pi-netmeta">
              <span className="a mono">{fmtUnits(net.amount)}{q.pointSize >= 1 ? " ct" : " units"}</span>
              <span className="b">{net.count > 1 ? net.count + " fills · " : ""}avg <span className="mono">{net.avg.toFixed(q.digits)}</span></span>
            </div>
            <div className="sc-pi-pl">
              <div className="v mono" style={{ color: net.pl >= 0 ? "var(--pos)" : "var(--neg)" }}>{signed(net.pl)}</div>
              <div className="p mono">{net.pips >= 0 ? "+" : ""}{net.pips.toFixed(1)} pips</div>
            </div>
          </div>
          <div className="sc-pi-grid">
            <div className="sc-pi-cell"><span className="k">Mark (bid)</span><span className="v mono">{q.bid.toFixed(q.digits)}</span></div>
            <div className="sc-pi-cell"><span className="k">Mark (ask)</span><span className="v mono">{q.ask.toFixed(q.digits)}</span></div>
            <div className="sc-pi-cell"><span className="k">Spread</span><span className="v mono">{spreadPips(q.bid, q.ask, q.pointSize)} pips</span></div>
            <div className="sc-pi-cell"><span className="k">Margin</span><span className="v mono">{money(q.mid * net.amount * 0.02)}</span></div>
          </div>
          <div className="sc-pi-sltp">
            <div className="lbl-row"><span>Risk bracket</span><span className="sc-field-stub" style={{ color: "var(--mute)" }}>visual stub</span></div>
            <div className="sc-field"><span className="tag sl">SL</span><input placeholder={(net.side === "B" ? q.bid - 20 * q.pointSize : q.ask + 20 * q.pointSize).toFixed(q.digits)} /><span className="stub">−20p</span></div>
            <div className="sc-field"><span className="tag tp">TP</span><input placeholder={(net.side === "B" ? q.ask + 35 * q.pointSize : q.bid - 35 * q.pointSize).toFixed(q.digits)} /><span className="stub">+35p</span></div>
          </div>
          <div className="sc-pi-actions">
            <button className="sc-btn" onClick={() => ctx.positions.filter((p) => p.sym === sym).forEach((p) => ctx.reverse(p.id))}>Reverse</button>
            <button className="sc-btn danger" onClick={() => ctx.flattenSym(sym)}>Close {net.side === "B" ? "long" : "short"}</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ════ Blotter ═══════════════════════════════════════════════════════════
function Blotter({ className }) {
  const ctx = useContext(ScalpCtx);
  return (
    <div className={"sc-pane sc-blotter " + (className || "")}>
      <div className="sc-pane-head">Open Positions <span className="cnt">{ctx.positions.length}</span>
        <span className="grow" />
        <span className="mono" style={{ fontSize: 11, color: ctx.account.openPl >= 0 ? "var(--pos)" : "var(--neg)" }}>net {signed(ctx.account.openPl)}</span>
        {ctx.positions.length > 0 && <button className="sc-flatten" onClick={ctx.flattenAll}>⚡ Flatten all</button>}
      </div>
      <div className="sc-blot-wrap">
        {ctx.positions.length === 0
          ? <div className="sc-blot-empty">Flat — no open positions.</div>
          : (
            <React.Fragment>
              <div className="sc-blot-row head"><span /><span>Instr</span><span>Side</span><span style={{ textAlign: "right" }}>Size</span><span style={{ textAlign: "right" }}>Open</span><span style={{ textAlign: "right" }}>P/L</span><span /></div>
              {ctx.positions.map((p) => {
                const q = ctx.quotes[p.sym];
                const pl = ctx.plOf(p, ctx.quotes);
                return (
                  <div key={p.id} className="sc-blot-row" onClick={() => ctx.setSel(p.sym)} style={{ cursor: "pointer" }}>
                    <span className={"sc-side-tag " + (p.side === "B" ? "b" : "s")} style={{ fontSize: 9, padding: "2px 5px" }}>{p.side}</span>
                    <span className="sc-blot-sym">{p.sym}</span>
                    <span style={{ color: "var(--text-2)" }}>{p.side === "B" ? "Long" : "Short"}</span>
                    <span className="mono" style={{ textAlign: "right" }}>{fmtUnits(p.amount)}</span>
                    <span className="mono" style={{ textAlign: "right", color: "var(--text-2)" }}>{p.open.toFixed(q.digits)}</span>
                    <span className="mono sc-blot-pl" style={{ color: pl >= 0 ? "var(--pos)" : "var(--neg)" }}>{signed(pl)}</span>
                    <button className="sc-blot-x" onClick={(e) => { e.stopPropagation(); ctx.closeOne(p.id); }}>✕</button>
                  </div>
                );
              })}
            </React.Fragment>
          )}
      </div>
    </div>
  );
}

// ════ Top bar ═══════════════════════════════════════════════════════════
const LOTS = { fx: ["1K", "10K", "50K", "100K"], idx: ["1", "5", "10", "25"] };
function lotValue(sym, label) {
  const n = parseFloat(label) * (label.includes("K") ? 1000 : 1);
  return n;
}
function TopBar() {
  const ctx = useContext(ScalpCtx);
  const isFx = ctx.quotes[ctx.sel].pointSize < 1;
  const lots = isFx ? LOTS.fx : LOTS.idx;
  return (
    <div className="sc-bar">
      <span className="sc-brand"><span className="bolt">⚡</span> Scalp</span>
      <span className="sc-live"><span className="dot" /> Live</span>
      <span className="sc-div" />
      <span className="sc-stat"><span className="sc-stat-lbl">Equity</span><span className="sc-stat-val mono">{money(ctx.account.equity)}</span></span>
      <span className="sc-stat"><span className="sc-stat-lbl">Free margin</span><span className="sc-stat-val mono">{money(ctx.account.freeMargin)}</span></span>
      <span className="sc-stat"><span className="sc-stat-lbl">Open P/L</span><span className="sc-stat-val mono" style={{ color: ctx.account.openPl >= 0 ? "var(--pos)" : "var(--neg)" }}>{signed(ctx.account.openPl)}</span></span>
      <span className="grow" style={{ flex: 1 }} />
      {ctx.t.hotkeys && <span className="sc-kbd">B buy · S sell · F flatten · ⎵ confirm</span>}
      <div className="sc-lots"><span className="lbl">Size</span>
        {lots.map((l) => <button key={l} className={"sc-lot" + (lotValue(ctx.sel, l) === ctx.lot ? " on" : "")} onClick={() => ctx.setLot(lotValue(ctx.sel, l))}>{l}</button>)}
      </div>
      <button className={"sc-oneclick" + (ctx.oneClick ? " on" : "")} onClick={() => ctx.setOneClick((v) => !v)}>
        <span className="tog"><span className="knob" /></span>{ctx.oneClick ? "1-click" : "Confirm"}
      </button>
      <button className="sc-iconbtn" title="Toggle theme" onClick={ctx.toggleTheme}>{ctx.theme === "dark" ? "☾" : "☀"}</button>
    </div>
  );
}

Object.assign(window, { DealStrip, RateMatrix, ChartPane, PositionInfo, Blotter, TopBar, netForSym, lotValue, LOTS });
