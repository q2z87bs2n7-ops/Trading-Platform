// ── CFD Scalp — shared data, formatting helpers & live quote engine ──────────
// All numbers render in IBM Plex Mono. Big-figure split mirrors the real
// splitBigFig() in CfdScalpPage.tsx (handle · big-pips · fractional-pip).

// ── Big-figure split (ported from the real component) ───────────────────────
function pipDecimals(pointSize, digits) {
  if (!pointSize || pointSize <= 0) return digits;
  return Math.max(0, Math.round(-Math.log10(pointSize)));
}
function splitBigFig(value, digits, pointSize) {
  if (value == null || Number.isNaN(value)) return { big: "—", pips: "", frac: "" };
  const s = value.toFixed(digits);
  const subPip = Math.max(0, digits - pipDecimals(pointSize, digits));
  const frac = subPip > 0 ? s.slice(s.length - subPip) : "";
  let rem = subPip > 0 ? s.slice(0, s.length - subPip) : s;
  if (rem.endsWith(".")) rem = rem.slice(0, -1);
  let seen = 0, cut = 0;
  for (let i = rem.length - 1; i >= 0; i--) {
    if (rem[i] >= "0" && rem[i] <= "9") {
      seen++;
      if (seen === 2) { cut = i; break; }
    }
  }
  return { big: rem.slice(0, cut), pips: rem.slice(cut), frac };
}

// Big-figure price: small handle, large pips, tiny super fractional-pip.
function BigFig({ value, digits, pointSize, size = 1, color = "inherit" }) {
  const { big, pips, frac } = splitBigFig(value, digits, pointSize);
  return (
    <span className="mono" style={{ lineHeight: 1, color, whiteSpace: "nowrap", display: "inline-flex", alignItems: "baseline" }}>
      <span style={{ fontSize: 15 * size, opacity: 0.6 }}>{big}</span>
      <span style={{ fontSize: 26 * size, fontWeight: 600, letterSpacing: "-0.01em" }}>{pips}</span>
      {frac && <span style={{ fontSize: 12 * size, verticalAlign: "super", opacity: 0.7, marginLeft: 0.5 }}>{frac}</span>}
    </span>
  );
}

function spreadPips(bid, ask, pointSize) {
  if (bid == null || ask == null || !pointSize) return "—";
  const v = (ask - bid) / pointSize;
  return v >= 100 ? v.toFixed(0) : v.toFixed(1);
}
function spreadNum(bid, ask, pointSize) {
  if (bid == null || ask == null || !pointSize) return 0;
  return (ask - bid) / pointSize;
}

const money = (n) =>
  (n < 0 ? "-" : "") + "$" + Math.abs(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const signed = (n) => (n >= 0 ? "+" : "") + money(n);
const fmtUnits = (n) => n >= 1000 ? (n / 1000) + "K" : "" + n;

// ── Seed instrument book — realistic FXCM-style quotes ──────────────────────
const SEED = [
  { sym: "EUR/USD", name: "Euro / US Dollar",          bid: 1.08423, spread: 0.8,  digits: 5, pointSize: 0.0001, vol: 0.9 },
  { sym: "GBP/USD", name: "British Pound / US Dollar",  bid: 1.27185, spread: 1.4,  digits: 5, pointSize: 0.0001, vol: 1.1 },
  { sym: "USD/JPY", name: "US Dollar / Japanese Yen",   bid: 156.842, spread: 1.5,  digits: 3, pointSize: 0.01,   vol: 1.0 },
  { sym: "XAU/USD", name: "Gold / US Dollar",           bid: 2331.45, spread: 4.7,  digits: 2, pointSize: 0.01,   vol: 2.2 },
  { sym: "US30",    name: "Dow Jones 30",               bid: 39245.5, spread: 1.5,  digits: 1, pointSize: 1,      vol: 2.6 },
  { sym: "GER40",   name: "Germany 40 (DAX)",           bid: 18412.3, spread: 1.8,  digits: 1, pointSize: 1,      vol: 2.4 },
  { sym: "US100",   name: "US Tech 100 (Nasdaq)",       bid: 18720.2, spread: 2.3,  digits: 1, pointSize: 1,      vol: 2.8 },
  { sym: "BTC/USD", name: "Bitcoin / US Dollar",        bid: 67234.5, spread: 16.5, digits: 1, pointSize: 1,      vol: 3.4 },
];

// Per-instrument $ per 1.0 price-move per 1 lot/contract (rough, for live P&L feel).
const PLSCALE = { "EUR/USD": 1, "GBP/USD": 1, "USD/JPY": 0.0064, "XAU/USD": 1, "US30": 1, "GER40": 1.08, "US100": 1, "BTC/USD": 1 };

const ACCOUNT_SEED = { balance: 48044.45, day: 0 };

// ── Charts ──────────────────────────────────────────────────────────────────
function MockCandles({ w, h, up = "var(--pos)", down = "var(--neg)", trend = "up", seed = 7 }) {
  const n = Math.max(28, Math.round(w / 13));
  const candles = [];
  let price = h * 0.6;
  let s = seed;
  const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  const cw = w / n;
  const drift = trend === "up" ? -0.3 : 0.32;
  for (let i = 0; i < n; i++) {
    const move = (rand() - 0.5) * 16 + drift;
    const open = price;
    price = Math.max(h * 0.14, Math.min(h * 0.88, price + move));
    const close = price;
    const hi = Math.min(open, close) - rand() * 7 - 2;
    const lo = Math.max(open, close) + rand() * 7 + 2;
    candles.push({ x: i * cw + cw / 2, open, close, hi, lo, up: close < open });
  }
  return (
    <svg width="100%" height="100%" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{ display: "block" }}>
      {candles.map((c, i) => {
        const col = c.up ? up : down;
        const bodyTop = Math.min(c.open, c.close);
        const bodyH = Math.max(1.5, Math.abs(c.close - c.open));
        return (
          <g key={i} opacity={0.92}>
            <line x1={c.x} x2={c.x} y1={c.hi} y2={c.lo} stroke={col} strokeWidth={1} opacity={0.5} />
            <rect x={c.x - cw * 0.3} y={bodyTop} width={cw * 0.6} height={bodyH} fill={col} rx={0.5} />
          </g>
        );
      })}
    </svg>
  );
}

function Spark({ data, color, w = 64, h = 22, sw = 1.5 }) {
  const min = Math.min(...data), max = Math.max(...data);
  const rng = max - min || 1;
  const pts = data.map((v, i) => `${((i / (data.length - 1)) * w).toFixed(1)},${(h - ((v - min) / rng) * h).toFixed(1)}`);
  return (
    <svg width={w} height={h} style={{ display: "block", overflow: "visible" }}>
      <polyline points={pts.join(" ")} fill="none" stroke={color} strokeWidth={sw} strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

// ── Live quote engine ────────────────────────────────────────────────────────
// One engine, shared across all three device layouts (one product, one session).
const ScalpCtx = React.createContext(null);

function useScalpEngine() {
  const [quotes, setQuotes] = React.useState(() => {
    const q = {};
    for (const s of SEED) {
      const sp = s.spread * s.pointSize;
      q[s.sym] = { ...s, bid: s.bid, ask: s.bid + sp, mid: s.bid + sp / 2, flash: null, trail: Array.from({ length: 40 }, (_, i) => s.bid + sp / 2) };
    }
    return q;
  });
  const [sel, setSel] = React.useState("EUR/USD");
  const [positions, setPositions] = React.useState([
    { id: 1, sym: "EUR/USD", side: "B", amount: 50000, open: 1.08402 },
    { id: 2, sym: "US30",    side: "B", amount: 5,     open: 39221.0 },
    { id: 3, sym: "USD/JPY", side: "S", amount: 10000, open: 156.861 },
  ]);
  const idRef = React.useRef(4);

  // tick
  React.useEffect(() => {
    let timers = [];
    const iv = setInterval(() => {
      setQuotes((prev) => {
        const next = { ...prev };
        for (const sym in prev) {
          const o = prev[sym];
          const step = (Math.random() - 0.5) * 2 * o.vol * o.pointSize * 2.4;
          let mid = o.mid + step;
          // gentle mean-pull so values don't wander far from seed
          mid += (o.bid + (o.spread * o.pointSize) / 2 - mid) * 0.0;
          const jitter = 1 + (Math.random() - 0.5) * 0.25;
          const sp = o.spread * o.pointSize * jitter;
          const bid = mid - sp / 2;
          const ask = mid + sp / 2;
          const dead = o.pointSize * 0.25;
          let flash = null;
          if (mid - o.mid > dead) flash = "up";
          else if (o.mid - mid > dead) flash = "dn";
          const trail = o.trail.slice(1).concat(mid);
          next[sym] = { ...o, bid, ask, mid, flash, trail };
        }
        return next;
      });
    }, 850);
    // clear flashes shortly after each tick
    const clr = setInterval(() => {
      setQuotes((prev) => {
        let changed = false;
        const next = { ...prev };
        for (const sym in prev) if (prev[sym].flash) { next[sym] = { ...prev[sym], flash: null }; changed = true; }
        return changed ? next : prev;
      });
    }, 850 + 320);
    return () => { clearInterval(iv); clearInterval(clr); timers.forEach(clearTimeout); };
  }, []);

  const plOf = React.useCallback((p, q) => {
    const quote = q[p.sym];
    if (!quote) return 0;
    // closing price = the price you'd get out at: buys close on bid, sells on ask
    const out = p.side === "B" ? quote.bid : quote.ask;
    const sign = p.side === "B" ? 1 : -1;
    return (out - p.open) * sign * p.amount * (PLSCALE[p.sym] || 1);
  }, []);

  const pipsOf = React.useCallback((p, q) => {
    const quote = q[p.sym];
    if (!quote) return 0;
    const out = p.side === "B" ? quote.bid : quote.ask;
    const sign = p.side === "B" ? 1 : -1;
    return (out - p.open) * sign / quote.pointSize;
  }, []);

  const fire = React.useCallback((sym, side, amount) => {
    setPositions((prev) => {
      const q = quotesRef.current[sym];
      const open = side === "B" ? q.ask : q.bid;
      return [{ id: idRef.current++, sym, side, amount, open }, ...prev];
    });
  }, []);
  const closeOne = React.useCallback((id) => setPositions((prev) => prev.filter((p) => p.id !== id)), []);
  const reverse = React.useCallback((id) => {
    setPositions((prev) => prev.map((p) => p.id === id ? { ...p, side: p.side === "B" ? "S" : "B", open: quotesRef.current[p.sym][p.side === "B" ? "bid" : "ask"] } : p));
  }, []);
  const flattenAll = React.useCallback(() => setPositions([]), []);
  const flattenSym = React.useCallback((sym) => setPositions((prev) => prev.filter((p) => p.sym !== sym)), []);

  const quotesRef = React.useRef(quotes);
  quotesRef.current = quotes;

  // account roll-up
  const openPl = positions.reduce((a, p) => a + plOf(p, quotes), 0);
  const equity = ACCOUNT_SEED.balance + openPl;
  const usedMargin = positions.reduce((a, p) => a + (quotes[p.sym] ? quotes[p.sym].mid * p.amount * (PLSCALE[p.sym] || 1) * 0.02 : 0), 0);
  const account = { equity, openPl, balance: ACCOUNT_SEED.balance, freeMargin: equity - usedMargin, marginLevel: usedMargin ? (equity / usedMargin) * 100 : null };

  return { quotes, sel, setSel, positions, fire, closeOne, reverse, flattenAll, flattenSym, plOf, pipsOf, account };
}

Object.assign(window, {
  BigFig, splitBigFig, spreadPips, spreadNum, money, signed, fmtUnits,
  SEED, MockCandles, Spark, ScalpCtx, useScalpEngine,
});
