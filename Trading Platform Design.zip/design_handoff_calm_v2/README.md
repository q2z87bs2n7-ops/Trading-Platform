# Handoff — Trading Platform v2 UI/UX Refresh ("Calm")

**Target repo:** `q2z87bs2n7-ops/Trading-Platform` (FastAPI + Alpaca paper
backend, React 18 + TypeScript + Vite + Tailwind frontend, TradingView
Charting Library committed at `frontend/public/charting_library/`).

**Scope:** Frontend-only redesign. Backend, data shapes, the streaming
relay, `tv-broker.ts` interface, write-auth seam, and Alpaca paper-only
constraint **stay exactly as-is**. (See *Out of scope* at the bottom.)

**Bottom line:** a refined version of the existing dashboard that
consolidates the three modes (Discover / Trading / ChartBot) into a
cleaner three-pill nav, refreshes the visual system (palette, radii,
type, light+dark toggle), adds a **⌘K command bar** as the universal
AI surface, and restyles the existing **ChartBot side panel** so it's
clearly the dedicated chart assistant — same backend, refreshed shell.

---

## About this bundle

Everything in this folder is a **design reference**, not production code.

- `mock.html` — a self-contained, vanilla-JS prototype of the full
  redesign. Open it in a browser to click around. The Discover, Portfolio,
  and Chart modes are fully wired; light/dark toggle works; the ⌘K modal
  and ChartBot side panel both work end-to-end against mock data.
- `tokens.css` — the refined design tokens, ready to drop into
  `frontend/src/index.css` as a near-1:1 replacement for the existing
  `:root` block.
- `intents.md` — parser tables for ⌘K and ChartBot. Maps user phrases →
  backend tools / mutation hooks. **Read this when implementing the AI
  routing.**
- `shared/mock-data.js` — the static dataset the prototype renders. For
  visual reference only — the real app uses the existing data hooks
  (`usePositions`, `useOrders`, `useMovers`, etc.).

> **Task: recreate the design in the existing React + Tailwind + TanStack
> Query codebase, using its established patterns.** Do **not** import
> the mock HTML or vanilla JS into the app. The mock is the spec for
> what to build, not the implementation.

---

## Fidelity

**High-fidelity.** Colors, type, spacing, radii, shadows, and interaction
states are all final and should be matched closely. Exact tokens are in
`tokens.css`. Where the mock and the existing repo conventions disagree
(e.g. the mock uses inline event handlers, the repo uses React Query +
custom hooks), follow the repo conventions — only the visual output and
behavior need to match the mock.

---

## Architecture decisions made during design

These are the things you should treat as decided. If you disagree with
one, surface it before implementing.

### Three modes, renamed

The header toggle keeps three modes but renames them:

| Was         | Is                  | Notes                                           |
| ----------- | ------------------- | ----------------------------------------------- |
| Discover    | **Discover**        | Same purpose, refreshed visuals                 |
| Trading     | **Portfolio**       | Same purpose, refreshed visuals; renamed because "portfolio" is what users actually look at here |
| ChartBot    | **Chart**           | Same TV terminal underneath; restyled chrome around it; AI panel now called "ChartBot" (its own brand, not the mode name) |

Migration: `localStorage["platform_mode"]` still uses values
`"discover" | "trading" | "chartbot"`. Add one-shot migration:
`"trading" → "portfolio"`, `"chartbot" → "chart"`.

### Two AI surfaces, not one

The model needs two front doors:

- **⌘K command bar** — a centered modal accessible from anywhere in the
  app. Teal accent (matches `--accent`). General-purpose: orders,
  portfolio, scan, news. Replaces the search icon in the top nav with a
  prominent "Ask anything · ⌘K" pill.
- **ChartBot side panel** — the existing chart-specialized AI from
  `components/chat/`, restyled. Violet accent (`--cb-accent`, distinct
  from teal). Mounts only in Chart mode. Open by default. Same backend
  tool loop, same `useChatSession` hook — only the shell + theming
  changes.

See `intents.md` for what each surface knows how to do.

### TradingView Charting Library — what we keep, what we replace

This is the constraint that shaped Chart mode. Specifically:

**Hide TV's top header** with `disabled_features: ["header_resolutions",
"header_chart_type", "header_indicators", "header_compare",
"header_settings", "header_screenshot", "header_fullscreen_button",
"header_widget"]` and render our **own custom top toolbar** above it.
Our buttons call:
- `widget.activeChart().setResolution("1D")` for TF buttons
- `widget.activeChart().createStudy("MACD")` for indicator picker
- `widget.activeChart().setChartType(N)` for chart-type picker (TV
  enum: Bars=0, Candles=1, Line=2, Area=3, HeikinAshi=8, …)

**Keep TV's left drawing toolbar.** Don't try to replace it with hand-built
React. Pass `custom_css_url` to themed CSS that retunes TV's toolbar
colors to match our palette — that's it. The mock's drawing rail is a
visual approximation of what TV's toolbar looks like once themed; the
production implementation just lets TV render its own.

**Active-indicator pills row** (above the chart, below our custom
toolbar) — this is **ours**, not TV's. Listen to TV study add/remove
events and render the pill list reactively.

**Right-rail order ticket and bottom blotter strip** — both outside the
TV widget, plain React.

---

## Implementation roadmap (suggested phasing)

Do this in order. Each phase is roughly one cohesive PR.

1. **Tokens + theme toggle** — drop `tokens.css` into `index.css`
   (replacing the existing `:root` block), wire a `useTheme()` hook that
   sets `document.documentElement.dataset.theme` and persists to
   `localStorage.theme`. Verify all existing components still render with
   the new palette in both modes. **Don't touch the layout yet.**
2. **Top nav rebuild** — refresh `App.tsx`'s header: new brand mark,
   three-pill mode toggle (Discover / Portfolio / Chart), "Ask anything
   ⌘K" pill, theme toggle icon, avatar dot. Mode renaming + localStorage
   migration. Quote/feed metadata moves into the existing `TopBar.tsx`
   status strip.
3. **Discover refresh** — restyle `Tools.tsx` to the new hero + sparkline
   cards + horizontal-scroll watchlist + chart card + movers + news. The
   indices ticker becomes a horizontally-scrolling row of cards with
   sparklines instead of a marquee. Donut goes monochrome teal (8 steps
   of luminance).
4. **Portfolio refresh** — restyle the existing Trading view: hero card
   (portfolio value + day P&L), equity-curve sparkline, positions strip
   as cards, open orders list. Reuses `usePositions`, `useOrders`,
   `useAccount`.
5. **TradeBar + OrderSheet** — the floating bottom-center Buy/Sell pill
   and the bottom-sheet order ticket. `OrderTicket.tsx`'s logic moves
   into the sheet; the sheet is a controlled modal opened by the bar.
   See §"New components" for shape.
6. **⌘K command bar** — new `CmdBar` component. Lives in the app shell so
   it's available cross-mode. Parser in `frontend/src/lib/cmd-intent.ts`
   (new file). Action handlers call existing hooks. See `intents.md`.
7. **Chart mode shell** — refresh `TVPlatform.tsx`: hide TV's header,
   render our custom top toolbar (`ChartTopBar`), wire TF/indicator/chart-
   type buttons to TV's API. Indicator pills row reacts to `widget.activeChart()
   .onStudyAdded().subscribe(...)`. Drawing toolbar stays TV's, themed.
8. **Chart mode right rail + blotter** — `OrderTicketRail` (compact,
   persistent variant of OrderTicket) + `ChartBlotter` (tabbed positions /
   orders / activity strip below chart, collapsible).
9. **ChartBot panel refresh** — restyle `components/chat/ChatPanel.tsx`
   and children (Header, EmptyState, Composer, Message) to the new violet
   visual. **Keep `useChatSession.ts` and `ai-client.ts` unchanged.** Add
   the context pills strip below the header. Add the new
   empty-state suggestions from `intents.md`.
10. **AI tool additions** — extend the system prompt in
    `backend/app/ai/prompt.py` so the model knows about the new shortcuts
    (mark entry, suggest stop, add 50/200 pair). No new backend tools
    needed; these are compositions of existing primitives.
11. **States polish** — loading skeletons, empty states, error banners,
    streaming-disconnected indicator. See §"States" below.
12. **Responsive** — mobile/tablet pass. See §"Responsive".

---

## File-by-file change map

### Existing files — edit

| File | Change |
| ---- | ------ |
| `frontend/src/index.css` | Replace `:root` block with `tokens.css`. Move dark palette under `html[data-theme="dark"]`. Drop the legacy aliases (`--green`, `--red`, `--muted`) once Tailwind config is updated. |
| `frontend/tailwind.config.js` | No structural change — token names are unchanged. Add the new tokens (`--accent-soft`, `--hairline`, `--cb-accent*`, `--r/--r-lg/--r-xl`). |
| `frontend/index.html` | Add Google Fonts `<link>` for Inter + IBM Plex Mono (see `tokens.css` header for the snippet). |
| `frontend/src/App.tsx` | New header (brand mark, three-pill toggle, Ask pill, theme toggle, avatar). Mode rename + migration. Mount `<CmdBar>` once in the shell. |
| `frontend/src/components/TopBar.tsx` | Status strip stays but compacts: market open/closed + next session, equity, day P/L, BP. Move calendar exception popover into an inline chip. |
| `frontend/src/components/Tools.tsx` (Discover) | Full restyle. Hero card replaces the small indices ticker as the page lead. Cards/sparklines for watchlist + indices. Single chart inline. Movers as two side-by-side cards. News list card. |
| `frontend/src/components/Watchlist.tsx` | Two variants needed: (a) Discover — horizontal scrollable cards with sparklines, (b) Chart mode — narrow vertical list. The 5-row paginated dense variant goes away. |
| `frontend/src/components/OrderTicket.tsx` | Split into three surfaces: (a) `<OrderSheet>` bottom sheet for Discover/Portfolio, (b) `<OrderTicketRail>` compact right-rail for Chart, (c) the existing inline form behind ⌘K's "buy 100 AAPL at market" intent. All three share the same submit logic; refactor the form internals into a hook (`useOrderTicket`). |
| `frontend/src/components/Positions.tsx` | Restyle. In Portfolio view, becomes the "positions strip" (one card per row). In Chart blotter, becomes a compact mono table. |
| `frontend/src/components/Orders.tsx` | Restyle to match the new table style. Visible in Portfolio view + Chart blotter. |
| `frontend/src/components/PriceChart.tsx` | Restyle to the new Calm chart card (light line + area + small TF segmented control). Keep `lightweight-charts`. |
| `frontend/src/components/MarketNews.tsx` | Restyle to news card list (no chrome, just rows). |
| `frontend/src/components/TVPlatform.tsx` | Hide TV's native header. Mount `<ChartTopBar>`, `<IndicatorPillsRow>`, `<OrderTicketRail>`, `<ChartBlotter>` as siblings of the TV widget div. Subscribe to TV study/symbol/resolution events to keep our pills in sync. |
| `frontend/src/components/chat/ChatPanel.tsx` | Visual refresh only. Add violet accent, refined header, context pills below header. Layout stays — 380px right-edge collapsible panel, persisted under `chartbot_collapsed`. **Default to OPEN** in Chart mode (changes the readCollapsed default to `false` for new users). |
| `frontend/src/components/chat/ChatHeader.tsx` | Restyle. Replace text "ChartBot" with brand mark + name + tagline. |
| `frontend/src/components/chat/ChatEmptyState.tsx` | New suggestion list (see `intents.md` §"Empty-state suggestions"). |
| `frontend/src/components/chat/ChatMessage.tsx` | Restyle. User bubble right-aligned with violet bg + asymmetric corner. Bot turn with violet eyebrow. Tool-result cards get the violet border-left rail (matches the mock's `.cb-action-card`). |
| `frontend/src/components/chat/ChatComposer.tsx` | Restyle. Pill-shaped textarea, circular violet send button. |
| `backend/app/ai/prompt.py` | Add system-prompt section explaining the new chart shortcuts (mark entry, suggest stop, 50/200 pair). No code change in the tool loop. |

### Existing files — delete after migration

These are listed as orphaned in `BACKLOG.md` already:
- `MarketClock.tsx`, `Calendar.tsx`, `AccountSummary.tsx`,
  `PortfolioSummary.tsx`, `InstrumentInfo.tsx`

Delete them now — the new design doesn't surface them as separate
components. Their data is shown inline via existing hooks (`useClock`,
`useCalendar`, `useAccount`, `usePortfolioHistory`, `useAsset`).

### New files to create

```
frontend/src/components/cmd/CmdBar.tsx                ← centered ⌘K modal
frontend/src/components/cmd/CmdResultCard.tsx         ← shared shell for cards
frontend/src/components/cmd/CmdHotkey.tsx             ← global ⌘K listener + open state
frontend/src/components/trade/TradeBar.tsx            ← floating Buy/Sell pill
frontend/src/components/trade/OrderSheet.tsx          ← bottom-sheet ticket
frontend/src/components/trade/OrderTicketRail.tsx     ← persistent rail ticket (Chart)
frontend/src/components/chart/ChartTopBar.tsx         ← custom top toolbar
frontend/src/components/chart/IndicatorPillsRow.tsx   ← active indicators above chart
frontend/src/components/chart/ChartBlotter.tsx        ← tabbed positions/orders/activity
frontend/src/hooks/useTheme.ts                        ← light/dark + persistence
frontend/src/hooks/useOrderTicket.ts                  ← shared ticket form state
frontend/src/lib/cmd-intent.ts                        ← ⌘K parser (table in intents.md)
```

---

## Screen specs

### Discover (`Tools.tsx`)

A horizontally-bounded page (`max-w-[1280px]`, generous padding). Three
"rows" of cards, with sections:

1. **Hero row** (12-col grid, 1.4fr / 1fr):
   - **Total balance card** (left): "Total balance" label, large equity
     number (`clamp(34px, 5.4vw, 48px)`), pos-tint pill with day P&L + %,
     small "All time" line, three meta bits (Cash / Invested / Buying
     power) as a flex row.
   - **Allocation card** (right): "Allocation" label, monochrome donut
     (8 steps of `--accent` luminance), scrollable legend with %s.
2. **Markets** (heading) → horizontally-scrollable row of index cards
   with sparklines.
3. **Watchlist** (heading) → horizontally-scrollable row of symbol
   cards with sparklines.
4. **Inline chart** card — wide line/area chart with symbol info top-left,
   TF segmented control top-right. Symbol switches when user clicks a
   watchlist/index card.
5. **Movers** (heading) → two equal-width cards (Top gainers / Top
   losers) with rank + sym + name + price + % rows.
6. **News** (heading) → card with full-width news list (ts + src + title).

A floating "AAPL · $192.86 [Buy] [Sell]" trade bar pins to the bottom-
center. Clicking Buy/Sell opens the `<OrderSheet>`.

### Portfolio (`Positions.tsx` + `Orders.tsx` + new equity-curve card)

Two-card hero (same grid as Discover):
- **Portfolio value card** — same hero pattern, but shows portfolio_value
  not equity, plus "Unrealized P&L", "Day's range", "Open orders".
- **Equity curve card** — area chart over 30d, no chrome, legend = "Equity
  curve · 30d" small label top-left.

Then:
- **Positions** (heading) → "positions strip" — list of cards, one per
  position. Each row: name+symbol / qty / avg / mark+day% / P&L. Click
  opens that symbol in Chart mode.
- **Open orders** (heading) → card containing the orders table. Each
  row is a flat layout (no nested cards). Side gets a colored pill.

### Chart (`TVPlatform.tsx`)

Full-bleed workspace inside a `.tv-shell` container with rounded corner +
border + subtle shadow. The page wrap loses its max-width constraint
(`body:has(.view[data-view="chart"].active) .wrap { max-width: 100%; }`).
The floating trade bar hides in Chart mode — the rail ticket replaces it.

Layout (top to bottom):
1. **Top toolbar (`ChartTopBar`)** — symbol info / +Compare / TF tabs /
   Chart-type popover / Indicators popover / Alert / Replay / ChartBot
   launch (violet) / Save layout / Settings / Fullscreen.
2. **Active indicator pills row** (collapses to 0 height when no
   indicators active).
3. **Body** — four columns:
   - Drawing rail (44px, **TV's native, themed**)
   - Watchlist (180px, narrow list)
   - Chart canvas (1fr, TV widget mounts here)
   - Order ticket rail (240px, **always visible**)
4. **Blotter strip** — 200px tall, tabbed (Positions / Orders / Activity),
   collapsible to 33px.
5. **ChartBot side panel** — slides over from right when open (380px),
   overlays the rail ticket and part of the chart. Open by default.

### Order Sheet (`OrderSheet.tsx`) — Discover/Portfolio entry

Bottom sheet, slides up from 100% off-screen. Backdrop blur. Two-column
inside (1fr / 1fr, single col on mobile):
- Left column: Buy/Sell segmented (1.5px border, tinted active), Order
  type chips (Market/Limit/Stop/Stop limit/Trailing), Quantity (stepper
  with +/- and quick-fill chips 10/50/100/Max), Limit/Stop price fields
  (conditionally visible), TIF chips.
- Right column: estimated cost (large mono number in tinted card), review
  rows (Bid / Ask / Buying power / After this order), big primary submit
  button.

Same logic as the existing `OrderTicket.tsx` `validate()` and submit flow.

### ⌘K Command Bar (`CmdBar.tsx`)

Centered modal, 680px max-width, top-anchored at 10vh. Frosted backdrop
(`background: rgba(20,22,28,.45); backdrop-filter: blur(4px)`).

Header: sparkle/asterisk icon (teal) + textarea + Esc kbd. Below: a
"Try" section with suggestion chips (visible only when transcript empty).
Below that: scrollable transcript of (user bubble → AI result card)
pairs.

Result cards use the same `.ai-card` shell:
- Order card → `<CmdResultCard kind="order">`
- Chart card → embedded mini-chart + stats grid + action buttons
- Movers card → ranked grid
- Portfolio card → mini donut + table
- News card → list
- Orders card → table

Each card's primary action button uses the buy/sell tint where
appropriate. "Confirm Buy 100 AAPL" → calls `useSubmitOrder.mutate()` →
toast on success.

### ChartBot Panel — already in repo, restyled

380px right-edge collapsible panel. **Violet** accent throughout. See
§"File-by-file" for the chat/* file changes. See `intents.md` for what
it knows how to do.

Key visual changes from current:
- Gradient header background using `--cb-accent-soft`
- Square brand mark with sparkle icon (violet→violet-2 gradient)
- "ChartBot · Specialized chart assistant" name+tagline
- Context pills row below header (sym · TF · price + active indicators)
- Suggestion chips in empty state (chart-specific, see intents.md)
- Tool-result cards have a violet 2px left border rail and a mono
  one-liner (`✓ draw_trend_line · AAPL · 1D`) + an Undo button that
  issues the inverse tool call.

---

## States to implement

The mock doesn't render every state visibly — implement these
explicitly:

| Surface | Loading | Empty | Error |
| ------- | ------- | ----- | ----- |
| Hero card (Discover, Portfolio) | Skeleton bars in place of equity + meta bits | n/a (always have an account) | Inline error banner on top of card with retry |
| Watchlist cards row | 4 skeleton cards | "Add symbols to start tracking" with a search input | Error chip + retry |
| Indices row | 8 skeleton cards | n/a | Single error chip in row |
| Inline chart | Center spinner over chart area | n/a | "Couldn't load bars for AAPL · retry" |
| Movers | Skeleton rows | "No movers right now" | Inline banner |
| News | Skeleton rows | "No headlines this hour" | Inline banner |
| Positions list | Skeleton rows | "No open positions — use the order sheet to enter one." (existing copy) | Inline banner |
| Orders list | Skeleton rows | "No open orders" | Inline banner |
| Order sheet | Submit button → spinner + "Submitting…" | n/a | Error banner above submit button (existing pattern from `OrderTicket.tsx`) |
| ⌘K result card | Thinking dots (existing pattern) | n/a | Card with "Couldn't fetch · retry" |
| ChartBot panel | Thinking dots in bot turn | Empty-state suggestions visible | Error event in turn with retry button (existing pattern from `ChatMessage.tsx`) |
| Chart mode (TV widget) | TV's own loading | n/a | TV's own |
| Stream disconnected | n/a | n/a | Yellow chip in `TopBar` status strip: "Polling · stream disconnected" — matches existing fallback behavior described in CLAUDE.md |

### Skeleton style

Tailwind: `bg-white/[0.06]` (light) or `bg-white/[0.08]` (dark), rounded
matching the element it replaces, `animate-pulse`. Match the existing
`SkeletonRow` in `Positions.tsx`.

---

## Theme toggle

```ts
// frontend/src/hooks/useTheme.ts
type Theme = "light" | "dark";

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem("theme");
    if (saved === "light" || saved === "dark") return saved;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("theme", theme);
  }, [theme]);

  return { theme, toggle: () => setTheme(t => t === "dark" ? "light" : "dark") };
}
```

The TV widget needs to be re-themed when the user toggles. Pass
`theme: theme === "dark" ? "Dark" : "Light"` to the widget constructor;
on toggle, call `widget.changeTheme("Dark" | "Light")` if the API
supports it, otherwise unmount+remount.

---

## Responsive

The mock collapses gracefully but production should consider:

| Breakpoint | Layout |
| ---------- | ------ |
| ≥1080px desktop | Full layout as specified |
| 880–1080px | Chart mode rail ticket → 220px, watchlist → 150px, otherwise unchanged |
| 720–880px tablet | Discover hero → stacked, donut moves below balance. Chart mode → hide watchlist, ticket below chart in a row, blotter below ticket. ⌘K modal full-width. |
| <720px mobile | Discover/Portfolio: single column, all rows stack. TradeBar full-width at bottom. OrderSheet full-height. ⌘K modal full-screen. ChartBot panel full-screen overlay (slide from right). Chart mode: drawing rail collapses to a top-row toolbar; chart fills screen; ticket as bottom sheet. |

The existing repo is PWA-capable (`vite-plugin-pwa`) so mobile UX matters
more than for a typical dashboard.

---

## TradingView Charting Library — integration guide

Quick reference for `TVPlatform.tsx` rebuild:

```ts
new TradingView.widget({
  symbol: "AAPL",
  container_id: "tv_chart_container",
  library_path: "/charting_library/",
  theme: theme === "dark" ? "Dark" : "Light",
  custom_css_url: "/tv-themed.css",  // ← see below
  toolbar_bg: "var(--panel)",         // hint; CSS overrides win
  disabled_features: [
    "header_widget",                  // hide the entire top header
    "header_resolutions",
    "header_chart_type",
    "header_indicators",
    "header_compare",
    "header_settings",
    "header_screenshot",
    "header_fullscreen_button",
    "use_localstorage_for_settings",  // we own persistence
  ],
  enabled_features: [
    "side_toolbar_in_fullscreen_mode", // keep drawing tools visible
  ],
  // ...existing datafeed + broker wire-up from tv-datafeed.ts / tv-broker.ts
});
```

A new `frontend/public/tv-themed.css` (referenced by `custom_css_url`)
re-tunes the TV CSS variables that drive its left toolbar:

```css
:root {
  --tv-color-platform-background: var(--panel);
  --tv-color-pane-background: var(--panel);
  --tv-color-toolbar-button-background-hover: var(--panel-3);
  --tv-color-toolbar-button-text: var(--text-2);
  --tv-color-toolbar-button-text-hover: var(--text);
  --tv-color-toolbar-divider-background: var(--border);
  /* ...etc — TV's full list is documented in their charting_library.css */
}
```

To keep our pills row in sync with TV's study list:
```ts
widget.activeChart().onChartReady(() => {
  widget.activeChart().getAllStudies().forEach(s => addPill(s));
  // subscribe to add/remove
  // (use the chart's onStudyAdded / onStudyRemoved subscription points)
});
```

The repo's `tv-drawings.ts` already calls drawing APIs from JS — the
ChartBot panel reuses that interface unchanged.

---

## Out of scope / hard constraints

Listed for clarity. **Don't touch any of these.**

1. **Paper-only.** The Alpaca client stays `paper=True`. No live-trading
   path. (Charter hard rule #1.)
2. **Backend.** Endpoints, schemas, AI tool loop, streaming relay,
   tv-broker/datafeed interfaces. The redesign is purely client-side.
3. **`backend/app/ai/tools.py`.** Add a system-prompt section mentioning
   the new shortcuts but don't add new tool functions; compose existing
   primitives.
4. **Deploy pipeline.** Vercel prod, Render relay, GitHub Pages previews
   — keep all three workflows as-is. `vercel.json
   git.deploymentEnabled=false` stays.
5. **Vercel Python landmines** (CLAUDE.md §"Vercel Python runtime"). Do
   not touch `requirements.txt`, do not re-add Pipfile, etc.
6. **`tv-broker.ts` external interface.** The TV `BrokerHost` shape is
   rigid — don't change its method signatures or return shapes.
7. **localStorage keys we keep:**
   - `platform_mode` (with migration trading→portfolio, chartbot→chart)
   - `chartbot_collapsed`
   - `chartbot_session`
   - `ai_drawings_v1`
   - new: `theme` (`"light" | "dark"`)
8. **Watchlist 5-row paginated variant** — the existing dense version
   is being replaced by horizontal cards in Discover and a vertical
   list in Chart. The auto-rotate-every-20s behavior goes away — calm,
   not busy.
9. **The `text-wrap: pretty`, advanced CSS, oklch palette** in the new
   design are intentional. Don't substitute hex equivalents "for
   compatibility" — modern browsers handle it and the visual difference
   matters.

---

## Files in this bundle

```
design_handoff_calm_v2/
├── README.md           ← this file
├── mock.html           ← clickable prototype (open in browser)
├── shared/
│   └── mock-data.js    ← mock dataset for the prototype
├── tokens.css          ← drop-in :root replacement
└── intents.md          ← ⌘K + ChartBot parser tables
```

**To preview the design:** open `mock.html` in a browser. Light/dark
toggle is the moon icon top-right of the nav. ⌘K opens the command bar.
The Chart pill opens Chart mode where the ChartBot panel is already open
on the right.

**To start implementing:** begin with §"Implementation roadmap" phase 1
(tokens + theme toggle). Each phase is self-contained — you can land
them as separate PRs and the app stays in a working state between
phases.

Open questions, surface fast and ask before guessing. Hard problems
likely to come up:
- TV CSS variable list — TV's documentation is sparse; iterate visually.
- `<OrderTicketRail>` vs `<OrderSheet>` shared form state — `useOrderTicket()`
  hook should encapsulate, but watch for prop drift.
- ChartBot panel default-open on first-load — the existing localStorage
  key returns `false` for missing, which is correct (default open).
  Verify it isn't already set to `"1"` from prior sessions.
