// Shared mock data used by all five prototypes so the same trader's state
// appears consistently across variations. Numbers are static; tiny live
// flicker is added per-prototype on top.

window.MOCK = (() => {
  const positions = [
    { sym: "NVDA",  qty: 120, avg: 482.15, last: 514.62, value: 61754.4,  pl: 3896.4,  plpc: 0.0673, day: 0.0212, name: "NVIDIA Corp" },
    { sym: "AAPL",  qty: 200, avg: 184.30, last: 192.86, value: 38572.0,  pl: 1712.0,  plpc: 0.0464, day: 0.0089, name: "Apple Inc" },
    { sym: "MSFT",  qty:  60, avg: 384.10, last: 412.55, value: 24753.0,  pl: 1707.0,  plpc: 0.0741, day: 0.0117, name: "Microsoft Corp" },
    { sym: "META",  qty:  35, avg: 472.80, last: 506.31, value: 17720.8,  pl: 1172.8,  plpc: 0.0708, day: 0.0144, name: "Meta Platforms" },
    { sym: "SPY",   qty:  45, avg: 519.40, last: 542.18, value: 24398.1,  pl: 1025.1,  plpc: 0.0438, day: 0.0061, name: "SPDR S&P 500 ETF" },
    { sym: "TSLA",  qty:  40, avg: 246.20, last: 218.74, value:  8749.6,  pl: -1098.4, plpc: -0.1116, day: -0.0287, name: "Tesla Inc" },
    { sym: "AMZN",  qty:  80, avg: 168.40, last: 178.92, value: 14313.6,  pl:  841.6,  plpc: 0.0625, day: 0.0098, name: "Amazon.com" },
    { sym: "GOOGL", qty: 110, avg: 152.10, last: 161.40, value: 17754.0,  pl: 1023.0,  plpc: 0.0612, day: 0.0072, name: "Alphabet Inc Class A" },
  ];

  const watchlist = [
    ...positions.map(p => p.sym),
    "AMD", "COIN", "QQQ", "IWM", "AVGO", "PLTR",
  ];

  const quotes = {};
  for (const p of positions) {
    quotes[p.sym] = { last: p.last, bid: p.last - 0.04, ask: p.last + 0.04, day: p.day };
  }
  Object.assign(quotes, {
    AMD:   { last: 168.42, bid: 168.38, ask: 168.46, day:  0.0341 },
    COIN:  { last: 248.10, bid: 248.02, ask: 248.18, day: -0.0182 },
    QQQ:   { last: 482.56, bid: 482.52, ask: 482.60, day:  0.0094 },
    IWM:   { last: 214.78, bid: 214.74, ask: 214.82, day: -0.0041 },
    AVGO:  { last: 1842.20, bid: 1842.10, ask: 1842.30, day: 0.0218 },
    PLTR:  { last:  28.46, bid:  28.44, ask:  28.48, day:  0.0512 },
  });

  const account = {
    equity:        124832.14,
    cash:           18402.30,
    bp:             36804.60,
    pv:            106429.84,
    eqAtOpen:      123585.82,
    dayPl:           1246.32,
    dayPlPct:        0.01008,
    totalPl:         9279.50,
    totalPlPct:      0.0805,
  };

  const indices = [
    { sym: "SPX",   name: "S&P 500",      price:  5402.18, chg:  18.42, pct:  0.0034 },
    { sym: "NDX",   name: "Nasdaq 100",   price: 19283.40, chg: 142.18, pct:  0.0074 },
    { sym: "DJI",   name: "Dow Jones",    price: 39847.30, chg: -82.10, pct: -0.0021 },
    { sym: "RUT",   name: "Russell 2000", price:  2104.72, chg: -8.92,  pct: -0.0042 },
    { sym: "VIX",   name: "Volatility",   price:    12.84, chg: -0.46,  pct: -0.0346 },
    { sym: "DAX",   name: "DAX",          price: 18642.50, chg:  72.18, pct:  0.0039 },
    { sym: "FTSE",  name: "FTSE 100",     price:  8284.10, chg: -12.40, pct: -0.0015 },
    { sym: "NIKKEI",name: "Nikkei 225",   price: 38947.20, chg: 218.40, pct:  0.0056 },
    { sym: "HSI",   name: "Hang Seng",    price: 18421.80, chg: -84.60, pct: -0.0046 },
    { sym: "GOLD",  name: "Gold",         price:  2389.40, chg:  18.20, pct:  0.0077 },
    { sym: "OIL",   name: "WTI Crude",    price:    78.42, chg:  -0.84, pct: -0.0106 },
    { sym: "BTC",   name: "Bitcoin",      price: 67842.10, chg: 842.30, pct:  0.0126 },
  ];

  const gainers = [
    { sym: "AVGO", price: 1842.20, pct:  0.0612, name: "Broadcom" },
    { sym: "NVDA", price:  514.62, pct:  0.0548, name: "NVIDIA" },
    { sym: "AMD",  price:  168.42, pct:  0.0341, name: "Adv Micro Devices" },
    { sym: "PLTR", price:   28.46, pct:  0.0512, name: "Palantir" },
    { sym: "MU",   price:  126.40, pct:  0.0418, name: "Micron Technology" },
    { sym: "ARM",  price:  142.18, pct:  0.0387, name: "Arm Holdings" },
  ];

  const losers = [
    { sym: "TSLA",  price:  218.74, pct: -0.0387, name: "Tesla" },
    { sym: "INTC",  price:   28.40, pct: -0.0312, name: "Intel" },
    { sym: "BA",    price:  178.20, pct: -0.0241, name: "Boeing" },
    { sym: "NFLX",  price:  642.10, pct: -0.0218, name: "Netflix" },
    { sym: "PYPL",  price:   62.40, pct: -0.0182, name: "PayPal" },
    { sym: "DIS",   price:  104.20, pct: -0.0148, name: "Disney" },
  ];

  const mostActive = [
    { sym: "NVDA", vol:  82_400_000, trades: 442_180 },
    { sym: "TSLA", vol:  62_180_000, trades: 384_120 },
    { sym: "AAPL", vol:  48_240_000, trades: 281_440 },
    { sym: "AMD",  vol:  41_820_000, trades: 248_180 },
    { sym: "SPY",  vol:  38_400_000, trades: 142_180 },
    { sym: "AMZN", vol:  31_240_000, trades: 198_180 },
  ];

  // 11 sector tiles for heatmap. Pct = day change, weight = relative market cap.
  const sectors = [
    { name: "Technology",        pct:  0.0142, weight: 28 },
    { name: "Financials",        pct:  0.0061, weight: 14 },
    { name: "Health Care",       pct: -0.0024, weight: 13 },
    { name: "Consumer Discretionary", pct:  0.0089, weight: 11 },
    { name: "Communication Svc", pct:  0.0098, weight:  9 },
    { name: "Industrials",       pct: -0.0041, weight:  8 },
    { name: "Consumer Staples",  pct:  0.0008, weight:  6 },
    { name: "Energy",            pct: -0.0142, weight:  4 },
    { name: "Utilities",         pct:  0.0034, weight:  3 },
    { name: "Real Estate",       pct: -0.0086, weight:  2 },
    { name: "Materials",         pct: -0.0021, weight:  2 },
  ];

  const news = [
    { src: "Reuters",  ago: "12m", t: "Nvidia hits fresh all-time high as data-center spend outpaces estimates", sym: "NVDA" },
    { src: "WSJ",      ago: "28m", t: "Fed minutes show split on June cut, dot plot in focus next week", sym: null },
    { src: "Bloomberg",ago: "41m", t: "Tesla recalls 1.8M vehicles over hood-latch software issue", sym: "TSLA" },
    { src: "FT",       ago: "1h",  t: "European chipmakers rally on memory-pricing outlook from Micron", sym: null },
    { src: "CNBC",     ago: "2h",  t: "Apple's Vision Pro EU launch beats internal sell-through targets", sym: "AAPL" },
    { src: "Reuters",  ago: "3h",  t: "OPEC+ holds output steady; Brent retreats from 12-week peak", sym: null },
    { src: "Bloomberg",ago: "3h",  t: "Meta details $14B AI infra capex through Q2 2027 in filing", sym: "META" },
    { src: "WSJ",      ago: "4h",  t: "Banks ease credit standards for the first time since 2022, Fed survey shows", sym: null },
  ];

  const orders = [
    { id: "a3f1", sym: "NVDA", side: "buy",  type: "limit",  qty:  20, lp: 510.00, sp: null, status: "open",     time: "10:42" },
    { id: "b2e7", sym: "AMD",  side: "buy",  type: "stop",   qty:  50, lp: null,   sp: 172.00, status: "open",   time: "10:14" },
    { id: "c8d4", sym: "META", side: "sell", type: "limit",  qty:  15, lp: 512.50, sp: null, status: "open",     time: "09:48" },
    { id: "d4c9", sym: "SPY",  side: "buy",  type: "market", qty:  10, lp: null,   sp: null, status: "filled",   time: "09:32" },
    { id: "e5b2", sym: "TSLA", side: "sell", type: "limit",  qty:  20, lp: 230.00, sp: null, status: "canceled", time: "09:21" },
  ];

  const activities = [
    { time: "10:32:14", type: "FILL",     msg: "BUY 10 SPY @ 542.18 · $5,421.80" },
    { time: "10:14:08", type: "ACCEPTED", msg: "BUY 50 AMD stop @ 172.00 · day"   },
    { time: "10:08:42", type: "FILL",     msg: "SELL 5 META @ 506.31 · $2,531.55" },
    { time: "09:58:21", type: "DIV",      msg: "AAPL dividend · +$48.00"          },
    { time: "09:48:02", type: "ACCEPTED", msg: "SELL 15 META limit @ 512.50 · day"},
    { time: "09:31:00", type: "OPEN",     msg: "Session open · equity $123,585.82"},
  ];

  // Synthetic OHLC bars — 60 daily bars for AAPL. Used by all prototypes' chart.
  function makeBars(seed, n, start, drift, vol) {
    let s = seed;
    function rng() { s = (s * 9301 + 49297) % 233280; return s / 233280; }
    const bars = [];
    let p = start;
    for (let i = 0; i < n; i++) {
      const r1 = rng() - 0.5, r2 = rng() - 0.5;
      const o = p;
      const c = Math.max(1, p + drift + r1 * vol);
      const h = Math.max(o, c) + Math.abs(r2) * vol * 0.6;
      const l = Math.min(o, c) - Math.abs(r2) * vol * 0.6;
      bars.push({ o, h, l, c, v: 1_000_000 + Math.floor(rng() * 8_000_000) });
      p = c;
    }
    return bars;
  }

  const bars = {
    AAPL: makeBars(11, 60, 182, 0.16, 2.6),
    NVDA: makeBars(23, 60, 460, 1.2,  9.4),
    META: makeBars(31, 60, 480, 0.6,  6.8),
    TSLA: makeBars(47, 60, 248, -0.5, 8.1),
    SPY:  makeBars(53, 60, 528, 0.24, 2.4),
    MSFT: makeBars(67, 60, 390, 0.36, 4.2),
  };

  return {
    account, positions, watchlist, quotes,
    indices, gainers, losers, mostActive, sectors,
    news, orders, activities, bars,
  };
})();
