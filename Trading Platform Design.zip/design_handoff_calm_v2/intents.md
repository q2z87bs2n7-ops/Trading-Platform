# AI Intent Tables

Two distinct AI surfaces, each with its own parser/router and result-card style.
Implementation note: both should route through the **existing** backend tool
loop in `backend/app/ai/router.py` — the parser tables here describe what the
*frontend* recognizes and which backend tool / frontend action it dispatches.
Don't bypass the tool loop with client-side fakes; the mock fakes them only
because there's no backend in a static HTML file.

---

## ⌘K Command Bar (general, cross-mode)

Universal assistant. Centered modal. **Teal** accent (`--accent`).
Opens with `⌘K` or by clicking the "Ask anything" pill in the top nav.

| Pattern (regex / keyword)                              | Intent           | Action                                                                                             | Result card                       |
| ------------------------------------------------------ | ---------------- | -------------------------------------------------------------------------------------------------- | --------------------------------- |
| `(buy\|sell) <qty> <SYM> [at market\|at <price>]`      | `order`          | Render order-ticket card; on confirm → `POST /api/orders` with parsed payload                      | Order ticket w/ confirm           |
| `close [my\|out\|all] <SYM>`                           | `order` (close)  | Pre-fill sell qty = position.qty; same flow as above                                               | Order ticket, "Close position" CTA |
| `(move\|change\|update) ... <SYM> limit <price>`       | `modify`         | Find matching open limit; `PATCH /api/orders/{id}` with new `limit_price`                          | Modify card w/ old/new prices     |
| `cancel order <id>` / `cancel <SYM> order`             | `cancel`         | `DELETE /api/orders/{id}`                                                                          | Confirm + undo (`POST` resubmit)  |
| `(portfolio\|positions\|holdings\|book)`               | `portfolio`      | Render portfolio card; reuse `usePositions`, `useAccount`                                          | Donut + table card                |
| `(gainer\|winner\|best) ... today`                     | `movers.gain`    | `useMovers(10)`                                                                                    | Gainers grid                      |
| `(loser\|laggard\|worst)`                              | `movers.lose`    | `useMovers(10)`                                                                                    | Losers grid                       |
| `movers` / `what changed today`                        | `movers.both`    | `useMovers(10)`                                                                                    | Both grids stacked                |
| `(news\|happening\|headlines) [SYM]`                   | `news`           | `useMarketNews(sym?)`                                                                              | News list card                    |
| `(orders\|open orders)`                                | `orders`         | `useOrders({status: "open"})`                                                                      | Orders table card                 |
| `<SYM>` alone, or `how('s\|s) <SYM>` / `chart <SYM>`   | `chart`          | Render symbol summary (price, OHLC, mini-chart) — uses `useSnapshot` + `useBars`                   | Chart card + "Open in workspace"  |
| Bare text not matching above                           | `fallback`       | Suggest chips                                                                                      | Suggestion prose                  |

**Result cards** all use `--accent` (teal) and the same `.ai-card` shell.
Confirm/reject buttons route to existing mutation hooks (`useSubmitOrder`,
`useCancelOrder`, `useReplaceOrder`).

**Empty-state suggestions** (in modal when transcript is empty):
- "What changed today?"
- "Buy 50 AMD at market"
- "How's NVDA?"
- "Show me top gainers"
- "News on Tesla"
- "Close my TSLA position"

---

## ChartBot (chart-mode-only, side panel)

Specialized chart assistant. Right side panel (380px), **violet**
accent (`--cb-accent`). Mounted only when Chart mode is active.

**Open by default** in Chart mode — collapsing leaves a thin vertical tab
on the right edge. State persisted under `localStorage.chartbot_collapsed`
(matches the existing repo's key).

### Existing backend tools (already in `backend/app/ai/tools.py`)

These map 1:1 to the existing implementation; no backend changes needed.

| User phrase                                            | Backend tool         | Notes                                                |
| ------------------------------------------------------ | -------------------- | ---------------------------------------------------- |
| `draw a trendline from <X> to <Y>`                     | `draw_trend_line`    | If `<X>`/`<Y>` are vague ("the low", "recent high"), let model infer from bars; backend tool accepts `time1/price1/time2/price2` |
| `draw fib [from low to high]`                          | `draw_fib_retracement` | Same — model picks anchors                         |
| `draw a horizontal at <price>` / `mark entry at <px>` | `draw_horizontal_line` | Pair with `draw_text` if label requested            |
| `add <N> SMA` / `add 50 and 200 SMA`                   | `add_indicator`      | Existing tool supports `SMA(20)`, `EMA(21)`, `VWAP`, etc. |
| `set timeframe to 4h` / `switch to 1D`                 | `set_resolution`     | TV resolution string                                 |
| `compare with QQQ`                                     | `compare_symbol`     | Existing tool                                        |
| `clear all drawings`                                   | `list_drawings` → bulk `remove_drawing` | Or implement `clear_all_drawings` server-side |
| `screenshot the chart`                                 | `take_screenshot`    | Already exists; image block returned to model        |
| `where would you place stops?`                         | (analysis) + `draw_horizontal_line` | Model decides; suggested stop drawn        |
| `what's the trend?` / `read this chart`                | `get_chart_state` / `inspect_chart` | Pure analysis; no drawing               |
| `explain what you see`                                 | `get_chart_state` + `take_screenshot` | Model summarizes                        |

### New intents to add (small additions)

Beyond what's already wired, the mock demonstrates these. They don't
need new backend tools — model can compose existing primitives — but
the **frontend chat suggestions / system prompt** should include them
so the model knows to reach for them.

- `mark my entry at <price>` → `draw_horizontal_line` + `draw_text` (with "Entry" label)
- `suggest a stop` / `where would you place stops` → analyze recent swing low, then `draw_horizontal_line`
- `add the 50/200` (shortcut) → two `add_indicator` calls
- `clear` (no other words) → confirm prompt first ("Clear 4 drawings on AAPL?"), then bulk remove

### Result card pattern

Every tool call surfaces as a tool-result card under the prose:

```
✓  draw_trend_line · AAPL · 1D     [undo]
```

Where `[undo]` issues an inverse `remove_drawing` call. This already
matches the existing `ChatMessage.tsx` `tool_call` event renderer —
just restyled with the violet border-left rail.

### Empty-state suggestions

These are written as natural-language prompts in the panel's empty state:

- "Trendline from 30-day low to high"
- "Add 50 + 200 SMA"
- "Mark entry at $482"
- "What's the trend?"
- "Where to place stops"
- "Compare with QQQ"
- "Switch to 4h"
- "Clear all drawings"

### Context pills (above transcript)

Show the **current chart state** so the user can see what ChartBot
"knows":

```
[AAPL · 1D · $192.86]   [Volume +2]
```

Pills update on: symbol change, TF change, indicator add/remove, live
price tick (debounced to 1.8s to match watchlist).

---

## Why two separate surfaces

The split is deliberate and the user should be able to tell at a glance
which one they're in:

|                  | ⌘K Command Bar              | ChartBot Panel              |
| ---------------- | --------------------------- | --------------------------- |
| **Shape**        | Centered modal              | Right-edge side panel       |
| **Color**        | Teal (`--accent`)           | Violet (`--cb-accent`)      |
| **Scope**        | All modes                   | Chart mode only             |
| **Specialty**    | Orders, portfolio, scan, news | Drawings, indicators, chart analysis |
| **Trigger**      | `⌘K` from anywhere          | Open by default; toolbar button + edge tab |
| **Persistence**  | Closes on Esc; transcript clears | Persistent; transcript persists per session |
| **System prompt**| General                     | Chart-specialized (existing repo's prompt) |

If the model needs to do something out of its lane (e.g. user asks
"draw a trendline" in ⌘K from Discover view) → respond with a card
that offers to "Open Chart mode and continue in ChartBot →".
