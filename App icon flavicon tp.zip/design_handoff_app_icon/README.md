# Handoff: Trading Platform App Icon & Favicon

## Overview

Replace the placeholder app icon (`frontend/public/icon.svg` — a blue gradient "T" with a line-chart polyline) with a new mark concept called **"Trio"**: three ascending candlesticks on a Calm-teal field. Wire up the favicon, PWA manifest, and iOS apple-touch-icon at the same time.

This is a small, contained change. **Replace one existing file, add seven new ones, and edit `frontend/index.html`. That is the entire scope.**

## ⚠️ Scope discipline

This task has been deliberately scoped. **Do not generate additional sizes or variants beyond the list below.** Specifically, do **not**:

- generate retina/2x/3x duplicates (the SVG + listed PNGs cover every device class we care about)
- add Windows Tile (`browserconfig.xml`, `mstile-*`) assets
- add Safari "mask-icon" / pinned-tab monochrome SVG
- generate dark-mode icon variants
- generate splash-screen images per iOS device model
- compile a `favicon.ico` (modern browsers prefer SVG + PNG; `.ico` is not in scope)

If you think any of these is needed, ask before adding it.

## About the design files

The files in `assets/` are **final production assets**, not HTML prototypes — drop them in as-is. The `reference/` folder contains the original design exploration (`Icon Concepts.html`) and the React component source (`icons.jsx`) for context only; you do **not** need to re-render or re-export anything from those.

## Fidelity

**High-fidelity / final.** Use the assets exactly as provided. The single non-asset task is the `<link>` / `<meta>` markup in `frontend/index.html` and the new `manifest.webmanifest`.

## What to do

### 1. Replace the existing icon

Replace `frontend/public/icon.svg` with `assets/icon.svg` from this bundle.

### 2. Add the new assets

Copy these files into `frontend/public/`:

```
frontend/public/
├── icon.svg                  ← replaces existing
├── icon-maskable.svg         ← new (source vector for the maskable)
├── icon-192.png              ← new (PWA manifest)
├── icon-512.png              ← new (PWA manifest, splash)
├── icon-maskable-512.png     ← new (Android adaptive, 80% safe zone)
├── apple-touch-icon.png      ← new (180×180, iPhone 12 + iPad)
├── favicon.svg               ← new (16-px-tuned vector — different from icon.svg)
├── favicon-32.png            ← new (raster fallback)
└── favicon-16.png            ← new (raster fallback)
```

That is the complete file list — 8 files total (1 replacement, 8 added; one of the added is a new SVG with the same name as the replacement, the math checks out).

### 3. Add `frontend/public/manifest.webmanifest`

Copy `snippets/manifest.webmanifest` from this bundle to `frontend/public/manifest.webmanifest`.

### 4. Edit `frontend/index.html`

Apply the changes shown in `snippets/index.html.diff`. Summarized:

- Remove the existing `<link rel="apple-touch-icon" href="%BASE_URL%icon.svg" />` (SVG is not a valid apple-touch-icon format).
- Update `<meta name="theme-color">` from `#000000` to `#1B6569` so the iOS status bar / Android URL bar tint matches the icon.
- Add the new icon / favicon / manifest `<link>` tags listed in the diff.

## Screens / Views

Not applicable — this is an asset and head-tag change, no UI surface changes.

## Design tokens used

These match `frontend/src/index.css` (Calm v2). Already present in the codebase — do not add duplicates.

| Token | Value (CSS) | sRGB approx | Used in |
|---|---|---|---|
| `--accent` | `oklch(46% 0.07 200)` | `#1B6569` | Icon background, theme-color, favicon background |
| (white) | `#ffffff` | `#ffffff` | Candlesticks |

The PNG rasters were generated from the source SVGs at the listed sizes, with image smoothing disabled at 16 / 32 px for pixel-perfect favicon rendering.

## Assets

### `icon.svg` (master)
- ViewBox `0 0 100 100`, full-bleed (no baked-in corner radius — platforms apply their own mask).
- Calm teal field + a subtle top-to-bottom gloss gradient (`url(#g)`, ±10% black/white at 8–10% opacity) that adds depth on large surfaces and is invisible below ~64 px.
- Three candlesticks at integer-aligned coordinates so they don't blur under platform scaling.

### `icon-maskable.svg` and `icon-maskable-512.png`
- Same composition as `icon.svg` but the candles are scaled to **80%** of the canvas (centered), giving Android the safe-zone padding required for adaptive icons (circle / squircle / round mask). Background fills the full bleed.

### `favicon.svg` (pixel-tuned, **not** identical to `icon.svg`)
- ViewBox `0 0 16 16` with `shape-rendering="crispEdges"`.
- **No wicks** — at 16 px a 1-unit wick disappears under sub-pixel rounding. Bars only.
- Bars at integer x/y/width/height so each one lands on whole pixels. Three ascending heights: 4 / 7 / 10 units.

### `apple-touch-icon.png` (180×180)
- Single size covers iPhone 12 (180), modern iPad (152/167 — iOS scales 180 down cleanly). Per the scope rules above, we are deliberately not shipping separate 152 and 167 files.

### `icon-192.png`, `icon-512.png`
- The two sizes required by `manifest.webmanifest`'s `icons` array for installable PWAs. 512 also serves as the splash-screen seed.

### `icon-maskable-512.png`
- Android adaptive-icon source. The 80% safe-zone is baked in so the launcher's circular crop never clips the candles.

### `favicon-32.png`, `favicon-16.png`
- Raster fallbacks for browsers that don't honor the SVG favicon (rare but real — older Edge, some embedded contexts).

## Verification

Once wired:

1. **Tab in Chrome / Safari / Firefox** — favicon should show three crisp white bars on teal. If you see a blurry shape, the browser is still picking the master icon — confirm `<link rel="icon" type="image/svg+xml" href="…/favicon.svg" />` is present and ordered before the PNG fallbacks.
2. **iOS Add-to-Home-Screen** — should produce the full Trio tile with rounded iOS corners applied automatically.
3. **Android Chrome → Install** — adaptive icon should show the candles within the launcher mask (circle on Pixel, squircle on Samsung) with no clipping.
4. **Lighthouse PWA audit** — "Manifest has a maskable icon" should pass.

## Files in this bundle

```
design_handoff_app_icon/
├── README.md                       ← you are here
├── assets/                         ← drop into frontend/public/
│   ├── icon.svg
│   ├── icon-maskable.svg
│   ├── icon-192.png
│   ├── icon-512.png
│   ├── icon-maskable-512.png
│   ├── apple-touch-icon.png
│   ├── favicon.svg
│   ├── favicon-32.png
│   └── favicon-16.png
├── snippets/
│   ├── index.html.diff             ← change to apply to frontend/index.html
│   └── manifest.webmanifest        ← new file, copy to frontend/public/
└── reference/
    ├── Icon Concepts.html          ← original design exploration (read-only)
    └── icons.jsx                   ← React component source for the six concepts
```
