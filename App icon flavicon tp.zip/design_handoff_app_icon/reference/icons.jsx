// All 6 icon concepts as pure React/SVG components. Each takes a `size` in
// CSS px and renders into a 100x100 viewBox so they scale crisply from
// 1024px hero tiles down to the 16px favicon ladder.
//
// Colors come from the repo's Calm v2 tokens:
//   --accent  = oklch(46% 0.07 200)  (calm teal)
//   --pos     = oklch(48% 0.11 155)  (stocks green)
//   --bg      = #f7f6f4              (warm paper)
//
// "variant" lets each concept render on either a teal field (the
// recommended PWA tile look) or a paper field (alternate / favicon‑on‑light).

const TEAL = 'oklch(46% 0.07 200)';
const TEAL_DK = 'oklch(34% 0.06 200)';
const PAPER = '#f7f6f4';
const PAPER_DEEP = '#efedea';
const INK = '#161a22';
const POS = 'oklch(48% 0.11 155)';
const CB = 'oklch(60% 0.17 290)';
const WHITE = '#ffffff';

// iOS continuous-corner squircle radius is ~22.37% of side.
const R = 22;

// Shared <defs> block — a soft inner highlight + a subtle bottom shadow
// that gives the teal tile depth at large sizes without registering as a
// gradient at small sizes.
function TileGlossDefs({ id }) {
  return (
    <defs>
      <linearGradient id={`tileGloss-${id}`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#fff" stopOpacity="0.08" />
        <stop offset="1" stopColor="#000" stopOpacity="0.10" />
      </linearGradient>
    </defs>
  );
}

// ─────────────────────────────────────────────────────────────────────
// A. TAPE — a horizontal "ticker tape" with a single printed pip.
//    The most reduced "trading" mark possible. At 16px it's still a
//    line + a dot, which the eye reads as a tick on a tape.
// ─────────────────────────────────────────────────────────────────────
function Tape({ size = 128, variant = 'teal' }) {
  const onTeal = variant === 'teal';
  const fill = onTeal ? TEAL : PAPER;
  const mark = onTeal ? WHITE : TEAL;
  const accent = onTeal ? 'rgba(255,255,255,.55)' : POS;
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} style={{ display: 'block' }}>
      <TileGlossDefs id={`tape-${variant}`} />
      <rect width="100" height="100" fill={fill} rx={R} />
      {onTeal && <rect width="100" height="100" fill={`url(#tileGloss-tape-${variant})`} rx={R} />}
      {/* horizontal tape line */}
      <rect x="12" y="46" width="76" height="8" rx="4" fill={mark} />
      {/* the printed tick — small vertical pip crossing the line */}
      <rect x="55" y="34" width="8" height="32" rx="4" fill={mark} />
      {/* accent dot — the "last print" */}
      <circle cx="59" cy="74" r="4" fill={accent} />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────
// B. CANDLE — a single candlestick, the universal markets glyph.
//    Hollow body so you can see the wick run through it; at 16px the
//    silhouette collapses to a vertical bar, which still reads.
// ─────────────────────────────────────────────────────────────────────
function Candle({ size = 128, variant = 'teal' }) {
  const onTeal = variant === 'teal';
  const fill = onTeal ? TEAL : PAPER;
  const mark = onTeal ? WHITE : TEAL;
  const hollow = onTeal ? TEAL : PAPER;
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} style={{ display: 'block' }}>
      <TileGlossDefs id={`candle-${variant}`} />
      <rect width="100" height="100" fill={fill} rx={R} />
      {onTeal && <rect width="100" height="100" fill={`url(#tileGloss-candle-${variant})`} rx={R} />}
      {/* wick */}
      <rect x="47" y="14" width="6" height="72" rx="3" fill={mark} />
      {/* body — drawn as a stroked rect so it reads "hollow up candle" */}
      <rect
        x="32"
        y="32"
        width="36"
        height="40"
        rx="4"
        fill={hollow}
        stroke={mark}
        strokeWidth="6"
      />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────
// C. TRIO — three ascending candlesticks. The clearest "this is a
//    trading app" mark of the set. Reads as a tiny market profile.
//    At 16px the silhouette collapses to three rising vertical bars,
//    which still reads as trend-up.
// ─────────────────────────────────────────────────────────────────────
function Trio({ size = 128, variant = 'teal' }) {
  const onTeal = variant === 'teal';
  const fill = onTeal ? TEAL : PAPER;
  const mark = onTeal ? WHITE : TEAL;
  const accent = onTeal ? WHITE : POS;
  // 3 candles. Each has body + wick. Ascending heights to read as trend-up.
  // Bodies are filled (the 1st two) and the last is highlighted in the gain
  // color when on paper so the rising close has visual punch.
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} style={{ display: 'block' }}>
      <TileGlossDefs id={`trio-${variant}`} />
      <rect width="100" height="100" fill={fill} rx={R} />
      {onTeal && <rect width="100" height="100" fill={`url(#tileGloss-trio-${variant})`} rx={R} />}

      {/* candle 1 — short, lowest */}
      <rect x="22" y="42" width="4" height="38" rx="2" fill={mark} />
      <rect x="18" y="52" width="12" height="22" rx="2" fill={mark} />

      {/* candle 2 — middle */}
      <rect x="48" y="30" width="4" height="42" rx="2" fill={mark} />
      <rect x="44" y="38" width="12" height="26" rx="2" fill={mark} />

      {/* candle 3 — tallest, highest close. Accent-colored to mark the rise. */}
      <rect x="74" y="16" width="4" height="46" rx="2" fill={accent} />
      <rect x="70" y="22" width="12" height="30" rx="2" fill={accent} />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────
// D. APEX — an upward chevron. Read as "up tick". Anchored by a small
//    pip below it so the chevron has a base to spring from, otherwise
//    it floats. Calm but confident.
// ─────────────────────────────────────────────────────────────────────
function Apex({ size = 128, variant = 'teal' }) {
  const onTeal = variant === 'teal';
  const fill = onTeal ? TEAL : PAPER;
  const mark = onTeal ? WHITE : TEAL;
  const dot = onTeal ? 'rgba(255,255,255,.55)' : POS;
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} style={{ display: 'block' }}>
      <TileGlossDefs id={`apex-${variant}`} />
      <rect width="100" height="100" fill={fill} rx={R} />
      {onTeal && <rect width="100" height="100" fill={`url(#tileGloss-apex-${variant})`} rx={R} />}
      <path
        d="M 20 64 L 50 30 L 80 64"
        stroke={mark}
        strokeWidth="11"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <circle cx="50" cy="78" r="5" fill={dot} />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────
// E. CROSSOVER — two moving averages crossing (a "golden cross"). A
//    fast line cutting up through a slower one. The crossover dot in
//    the gain color is the focal point. Most explicitly "chart" of the
//    six, but kept to two strokes so it stays calm.
// ─────────────────────────────────────────────────────────────────────
function Crossover({ size = 128, variant = 'teal' }) {
  const onTeal = variant === 'teal';
  const fill = onTeal ? TEAL : PAPER;
  const slow = onTeal ? 'rgba(255,255,255,0.45)' : 'rgba(22,26,34,0.30)';
  const fast = onTeal ? WHITE : TEAL;
  const dot = onTeal ? WHITE : POS;
  const dotRing = onTeal ? POS : 'rgba(255,255,255,0.85)';
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} style={{ display: 'block' }}>
      <TileGlossDefs id={`cross-${variant}`} />
      <rect width="100" height="100" fill={fill} rx={R} />
      {onTeal && <rect width="100" height="100" fill={`url(#tileGloss-cross-${variant})`} rx={R} />}

      {/* slow MA — long, gentle slope */}
      <path
        d="M 12 56 Q 36 52 50 50 T 88 44"
        stroke={slow}
        strokeWidth="6"
        strokeLinecap="round"
        fill="none"
      />
      {/* fast MA — steeper, cuts up through the slow line */}
      <path
        d="M 12 74 Q 30 68 42 58 T 88 22"
        stroke={fast}
        strokeWidth="8"
        strokeLinecap="round"
        fill="none"
      />
      {/* the cross — a small ring at the intersection */}
      <circle cx="50" cy="50" r="7" fill={dot} />
      <circle cx="50" cy="50" r="3.2" fill={dotRing} />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────
// F. PULSE — a single sparkline curve ending in a green endpoint dot.
//    Closest to a literal "chart icon", but with a Calm hand: just one
//    stroke, one accent, no clutter.
// ─────────────────────────────────────────────────────────────────────
function Pulse({ size = 128, variant = 'paper' }) {
  const onTeal = variant === 'teal';
  const fill = onTeal ? TEAL : PAPER;
  const stroke = onTeal ? WHITE : TEAL;
  const dot = onTeal ? WHITE : POS;
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} style={{ display: 'block' }}>
      <TileGlossDefs id={`pulse-${variant}`} />
      <rect width="100" height="100" fill={fill} rx={R} />
      {onTeal && <rect width="100" height="100" fill={`url(#tileGloss-pulse-${variant})`} rx={R} />}
      {/* baseline grid hint — two faint horizontal rules */}
      {!onTeal && (
        <g opacity="0.35">
          <line x1="14" y1="48" x2="86" y2="48" stroke="#cfc8be" strokeWidth="1" />
          <line x1="14" y1="72" x2="86" y2="72" stroke="#cfc8be" strokeWidth="1" />
        </g>
      )}
      <path
        d="M 14 72 Q 26 72 32 60 T 50 50 Q 60 50 64 40 T 86 22"
        stroke={stroke}
        strokeWidth="8"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <circle cx="86" cy="22" r="7.5" fill={dot} />
      {onTeal && <circle cx="86" cy="22" r="3" fill={POS} />}
    </svg>
  );
}

// Registry the canvas iterates over.
const CONCEPTS = [
  {
    id: 'tape',
    title: 'A · Tape',
    blurb: 'The mark reduced to its essence: one printed tick on a tape. Strongest favicon legibility at 16px — a horizontal line + a dot survives every size.',
    Icon: Tape,
    favicon: (s) => <Tape size={s} variant="teal" />,
  },
  {
    id: 'candle',
    title: 'B · Candle',
    blurb: 'Single hollow candlestick — the universal markets glyph. Hollow body to feel less "trader-bro" than a solid filled candle. At 16px collapses to a clean vertical bar.',
    Icon: Candle,
    favicon: (s) => <Candle size={s} variant="teal" />,
  },
  {
    id: 'trio',
    title: 'C · Trio',
    blurb: 'Three ascending candlesticks — a tiny market profile. Most legibly "this is a trading app" of the six. The closing candle picks up the gain color so the trend reads instantly. At 16px collapses to three rising bars, still trend-up.',
    Icon: Trio,
    favicon: (s) => <Trio size={s} variant="teal" />,
  },
  {
    id: 'apex',
    title: 'D · Apex',
    blurb: 'Up-chevron, anchored by a base pip. Reads as "up tick" instantly. Most directional / optimistic of the six — risks reading as a generic finance icon if not paired tightly with the wordmark.',
    Icon: Apex,
    favicon: (s) => <Apex size={s} variant="teal" />,
  },
  {
    id: 'crossover',
    title: 'E · Crossover',
    blurb: 'Two moving averages crossing — a "golden cross" with the crossover ring as the focal point. The most explicitly chart-shaped mark of the set, but pared to two strokes + a ring so it stays Calm, not noisy.',
    Icon: Crossover,
    favicon: (s) => <Crossover size={s} variant="teal" />,
  },
  {
    id: 'pulse',
    title: 'F · Pulse',
    blurb: 'Single sparkline + green endpoint. Closest to a literal chart icon but kept to one stroke, with the gain color as the only accent. Tropey if heavy-handed; minimal here.',
    Icon: Pulse,
    favicon: (s) => <Pulse size={s} variant="teal" />,
  },
];

Object.assign(window, {
  Tape, Candle, Trio, Apex, Crossover, Pulse,
  CONCEPTS, TEAL, TEAL_DK, PAPER, PAPER_DEEP, INK, POS, CB, WHITE,
});
