// Presentation frames — show each icon in its real context.
//
//   <IosTile>          rounded squircle with caption underneath
//   <Maskable>         circular crop (Android adaptive) preview
//   <BrowserTabs>      a faux Chrome/Safari tab strip with the favicon
//   <PixelLadder>      same icon at 48 / 32 / 24 / 16 px
//   <SpecimenSheet>    the full per-concept layout the canvas drops in

function IosTile({ Icon, caption = 'Trading', size = 200, dock = false }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
      <div
        style={{
          width: size,
          height: size,
          borderRadius: size * 0.2237,
          overflow: 'hidden',
          boxShadow:
            '0 1px 0 rgba(255,255,255,0.5) inset, 0 18px 40px -10px rgba(20,22,28,0.30), 0 4px 12px rgba(20,22,28,0.12)',
        }}
      >
        <Icon size={size} variant="teal" />
      </div>
      <div
        style={{
          fontSize: 13,
          fontWeight: 500,
          color: dock ? '#fff' : '#1a1a1a',
          textShadow: dock ? '0 1px 2px rgba(0,0,0,0.4)' : 'none',
          letterSpacing: '-0.01em',
        }}
      >
        {caption}
      </div>
    </div>
  );
}

function Maskable({ Icon, size = 130 }) {
  // Android adaptive icons crop a circle out of the inner 80% safe zone.
  // We render the icon at full size then clip a centered circle of 80%
  // so you can see what survives the crop.
  const safe = size * 0.8;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
      <div
        style={{
          width: size,
          height: size,
          position: 'relative',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {/* checker bg to show the crop boundary */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background:
              'repeating-conic-gradient(#e8e6e2 0 25%, #f0eee9 0 50%) 50% / 12px 12px',
            borderRadius: 8,
            opacity: 0.6,
          }}
        />
        <div
          style={{
            width: safe,
            height: safe,
            borderRadius: '50%',
            overflow: 'hidden',
            boxShadow: '0 6px 18px rgba(20,22,28,0.18)',
          }}
        >
          {/* render the icon larger than the circle so the center fills */}
          <div
            style={{
              width: safe,
              height: safe,
              transform: 'scale(1.25)',
              transformOrigin: 'center',
            }}
          >
            <Icon size={safe} variant="teal" />
          </div>
        </div>
      </div>
      <div style={{ fontSize: 10, color: '#6e6a62', letterSpacing: 0.4, textTransform: 'uppercase' }}>
        Maskable (Android)
      </div>
    </div>
  );
}

// A faux Chrome tab row. Three tabs, the active one is "Trading Platform"
// showing the favicon at native 16px. The others are dimmer tabs that
// frame the active one so it feels like a real browser context.
function BrowserTabs({ Icon, faviconRender }) {
  const renderFav = (px) =>
    faviconRender ? (
      faviconRender(px)
    ) : (
      <Icon size={px} variant="teal" />
    );

  const tabBase = {
    height: 36,
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    padding: '0 12px 0 12px',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    fontSize: 12,
    fontWeight: 500,
    color: '#5b6068',
    fontFamily: 'Inter, sans-serif',
    minWidth: 0,
    flex: '1 1 0',
    overflow: 'hidden',
    whiteSpace: 'nowrap',
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
      <div
        style={{
          display: 'flex',
          alignItems: 'flex-end',
          gap: 2,
          padding: '8px 8px 0 8px',
          background: '#dee0e3',
          borderTopLeftRadius: 12,
          borderTopRightRadius: 12,
        }}
      >
        {/* inactive tab */}
        <div style={{ ...tabBase, background: 'transparent', maxWidth: 130 }}>
          <div style={{ width: 14, height: 14, borderRadius: 3, background: '#bcbec3' }} />
          <span style={{ textOverflow: 'ellipsis', overflow: 'hidden' }}>Alpaca · Paper</span>
        </div>
        {/* ACTIVE tab — our favicon goes here */}
        <div
          style={{
            ...tabBase,
            background: '#f7f6f4',
            color: '#161a22',
            fontWeight: 600,
            boxShadow: '0 -1px 0 rgba(20,22,28,0.04) inset',
            maxWidth: 220,
            flex: '0 1 220px',
          }}
        >
          <div
            style={{
              width: 16,
              height: 16,
              flex: '0 0 16px',
              borderRadius: 3,
              overflow: 'hidden',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {renderFav(16)}
          </div>
          <span style={{ textOverflow: 'ellipsis', overflow: 'hidden' }}>
            Trading Platform
          </span>
          <div style={{ marginLeft: 'auto', color: '#9a9ea4', fontSize: 14, paddingLeft: 6 }}>×</div>
        </div>
        {/* inactive tab */}
        <div style={{ ...tabBase, background: 'transparent', maxWidth: 140 }}>
          <div style={{ width: 14, height: 14, borderRadius: 3, background: '#bcbec3' }} />
          <span style={{ textOverflow: 'ellipsis', overflow: 'hidden' }}>TradingView</span>
        </div>
      </div>
      {/* address bar stub */}
      <div
        style={{
          background: '#f7f6f4',
          padding: '8px 12px 10px 12px',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
        }}
      >
        <div style={{ display: 'flex', gap: 6, color: '#9a9ea4', fontSize: 14 }}>
          <span>‹</span><span>›</span><span style={{ fontSize: 12 }}>⟳</span>
        </div>
        <div
          style={{
            flex: 1,
            height: 22,
            background: '#eceae5',
            borderRadius: 11,
            fontSize: 11,
            color: '#6e6a62',
            display: 'flex',
            alignItems: 'center',
            padding: '0 10px',
            fontFamily: 'IBM Plex Mono, monospace',
          }}
        >
          <span style={{ color: '#9a9ea4', marginRight: 6 }}>🔒</span>
          trading-platform.vercel.app
        </div>
      </div>
    </div>
  );
}

function PixelLadder({ Icon, faviconRender }) {
  const sizes = [48, 32, 24, 16];
  const renderFav = (px) =>
    faviconRender ? faviconRender(px) : <Icon size={px} variant="teal" />;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14 }}>
        {sizes.map((s) => (
          <div
            key={s}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 6,
            }}
          >
            <div
              style={{
                width: s,
                height: s,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                /* crisp at integer pixel sizes — disable AA scaling */
                imageRendering: 'pixelated',
              }}
            >
              {renderFav(s)}
            </div>
            <div
              style={{
                fontSize: 9.5,
                color: '#6e6a62',
                fontFamily: 'IBM Plex Mono, monospace',
                letterSpacing: 0.3,
              }}
            >
              {s}
            </div>
          </div>
        ))}
      </div>
      <div
        style={{
          fontSize: 10,
          color: '#9a9189',
          letterSpacing: 0.4,
          textTransform: 'uppercase',
        }}
      >
        Favicon ladder
      </div>
    </div>
  );
}

// Whole-card layout for one concept. Renders inside a DCArtboard.
function SpecimenSheet({ concept }) {
  const { Icon, blurb, favicon } = concept;
  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        display: 'grid',
        gridTemplateColumns: '300px 1fr',
        gridTemplateRows: 'auto 1fr',
        gap: 28,
        padding: 32,
        background: '#fbfaf7',
        fontFamily: 'Inter, sans-serif',
        boxSizing: 'border-box',
      }}
    >
      {/* LEFT — iOS tile on a soft wallpaper */}
      <div
        style={{
          gridRow: '1 / 3',
          background:
            'radial-gradient(circle at 30% 20%, #e8eef0, #d6dfe3 60%, #c8d3d8)',
          borderRadius: 18,
          padding: 28,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 28,
          boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.5), 0 2px 8px rgba(0,0,0,0.04)',
        }}
      >
        <IosTile Icon={Icon} size={196} />
        <Maskable Icon={Icon} size={130} />
      </div>

      {/* TOP RIGHT — browser tab strip + ladder */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 200px',
          gap: 24,
          alignItems: 'start',
        }}
      >
        <div
          style={{
            border: '1px solid #dcd9d4',
            borderRadius: 12,
            overflow: 'hidden',
            boxShadow: '0 2px 8px rgba(20,22,28,0.04)',
          }}
        >
          <BrowserTabs Icon={Icon} faviconRender={favicon} />
        </div>
        <div
          style={{
            padding: '14px 16px',
            background: '#fff',
            border: '1px solid #dcd9d4',
            borderRadius: 12,
            boxShadow: '0 2px 8px rgba(20,22,28,0.04)',
          }}
        >
          <PixelLadder Icon={Icon} faviconRender={favicon} />
        </div>
      </div>

      {/* BOTTOM RIGHT — paper-trading rationale + scale variations */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 16,
        }}
      >
        {/* alt variants strip */}
        <div
          style={{
            padding: '18px 18px 16px 18px',
            background: '#fff',
            border: '1px solid #dcd9d4',
            borderRadius: 12,
            display: 'flex',
            alignItems: 'center',
            gap: 18,
            boxShadow: '0 2px 8px rgba(20,22,28,0.04)',
          }}
        >
          <div
            style={{
              fontSize: 10,
              color: '#9a9189',
              letterSpacing: 0.4,
              textTransform: 'uppercase',
              width: 88,
              lineHeight: 1.5,
            }}
          >
            Variant
            <br />
            studies
          </div>
          <div
            style={{
              width: 1,
              alignSelf: 'stretch',
              background: '#e8e5df',
            }}
          />
          <ScaleStrip Icon={Icon} />
        </div>
        {/* notes */}
        <div
          style={{
            flex: 1,
            padding: '16px 18px',
            background: '#fff',
            border: '1px solid #dcd9d4',
            borderRadius: 12,
            fontSize: 13,
            lineHeight: 1.55,
            color: '#3c4049',
            textWrap: 'pretty',
            boxShadow: '0 2px 8px rgba(20,22,28,0.04)',
          }}
        >
          <div
            style={{
              fontSize: 10,
              color: '#9a9189',
              letterSpacing: 0.4,
              textTransform: 'uppercase',
              marginBottom: 6,
            }}
          >
            Notes
          </div>
          {blurb}
        </div>
      </div>
    </div>
  );
}

// Five small studies: teal tile, paper tile, dark tile, dock-style on dark
// wallpaper, and a circle ("safari pinned tab" style monochrome).
function ScaleStrip({ Icon }) {
  return (
    <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
      <Mini Icon={Icon} variant="teal" label="Teal" />
      <Mini Icon={Icon} variant="paper" label="Paper" />
      <MiniDark Icon={Icon} />
      <MiniCircle Icon={Icon} />
    </div>
  );
}

function Mini({ Icon, variant, label }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
      <div
        style={{
          width: 64,
          height: 64,
          borderRadius: 14,
          overflow: 'hidden',
          boxShadow: '0 4px 10px rgba(20,22,28,0.10)',
          border: variant === 'paper' ? '1px solid #e3e0db' : 'none',
        }}
      >
        <Icon size={64} variant={variant} />
      </div>
      <div style={{ fontSize: 10, color: '#6e6a62' }}>{label}</div>
    </div>
  );
}

function MiniDark({ Icon }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
      <div
        style={{
          width: 64,
          height: 64,
          borderRadius: 14,
          overflow: 'hidden',
          background: '#0a0c10',
          padding: 6,
          boxSizing: 'border-box',
          boxShadow: '0 4px 10px rgba(20,22,28,0.30)',
        }}
      >
        <Icon size={52} variant="teal" />
      </div>
      <div style={{ fontSize: 10, color: '#6e6a62' }}>On dark</div>
    </div>
  );
}

function MiniCircle({ Icon }) {
  // Safari pinned-tab style — circular mono mask.
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
      <div
        style={{
          width: 64,
          height: 64,
          borderRadius: '50%',
          overflow: 'hidden',
          background: '#f7f6f4',
          border: '1px solid #e3e0db',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Icon size={64} variant="paper" />
      </div>
      <div style={{ fontSize: 10, color: '#6e6a62' }}>Pinned tab</div>
    </div>
  );
}

Object.assign(window, {
  IosTile,
  Maskable,
  BrowserTabs,
  PixelLadder,
  SpecimenSheet,
  ScaleStrip,
});
