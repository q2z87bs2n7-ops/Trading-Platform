// Top-level app — lays out a header artboard + one specimen sheet per
// concept inside a DesignCanvas. Each artboard is 1180×640 which fits
// the iOS tile on the left and the tab/ladder/notes column on the right
// at a comfortable reading size.

const { DesignCanvas, DCSection, DCArtboard } = window;

function HeroIntro() {
  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        boxSizing: 'border-box',
        padding: '44px 52px',
        background:
          'linear-gradient(135deg, #f7f6f4 0%, #efedea 60%, #e5e3df 100%)',
        display: 'grid',
        gridTemplateColumns: '1fr auto',
        gap: 48,
        alignItems: 'center',
        fontFamily: 'Inter, sans-serif',
      }}
    >
      <div>
        <div
          style={{
            fontSize: 11,
            letterSpacing: 1.4,
            textTransform: 'uppercase',
            color: '#828680',
            fontFamily: 'IBM Plex Mono, monospace',
            marginBottom: 14,
          }}
        >
          Trading Platform · v0.70.0 · Calm v2
        </div>
        <h1
          style={{
            margin: '0 0 18px 0',
            fontSize: 44,
            lineHeight: 1.05,
            fontWeight: 600,
            letterSpacing: '-0.025em',
            color: '#161a22',
            textWrap: 'balance',
          }}
        >
          App icon & favicon — six directions
        </h1>
        <p
          style={{
            margin: 0,
            fontSize: 16,
            lineHeight: 1.55,
            maxWidth: 720,
            color: '#3c4049',
            textWrap: 'pretty',
          }}
        >
          The current placeholder (a blue gradient T with a line-chart polyline) reads as a
          generic fintech mark. These six explore the same brief from different angles, all
          drawn from the Calm v2 tokens already in the repo —{' '}
          <span style={{ fontFamily: 'IBM Plex Mono, monospace', color: '#1a1a1a' }}>
            --accent
          </span>{' '}
          teal, warm paper, IBM Plex Mono — with the
          stocks-green appearing only as a single accent dot where it earns its place. Each card
          shows the PWA tile, the Android maskable crop, the live browser-tab favicon, and a
          pixel ladder down to 16 px so you can verify it survives every size.
        </p>
        <div
          style={{
            display: 'flex',
            gap: 22,
            marginTop: 26,
            flexWrap: 'wrap',
          }}
        >
          {[
            ['A', 'Tape', '#2f5e6a'],
            ['B', 'Candle', '#2f5e6a'],
            ['C', 'Trio', '#2f5e6a'],
            ['D', 'Apex', '#2f5e6a'],
            ['E', 'Crossover', '#2f5e6a'],
            ['F', 'Pulse', '#2f5e6a'],
          ].map(([letter, name, color]) => (
            <div key={letter} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span
                style={{
                  fontFamily: 'IBM Plex Mono, monospace',
                  fontWeight: 600,
                  fontSize: 13,
                  color,
                  width: 18,
                  height: 18,
                  borderRadius: 4,
                  background: 'rgba(47,94,106,0.10)',
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                {letter}
              </span>
              <span style={{ fontSize: 13.5, fontWeight: 500, color: '#161a22' }}>{name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* current vs proposed sample */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 16,
          alignItems: 'center',
        }}
      >
        <div
          style={{
            fontSize: 10,
            letterSpacing: 1.2,
            textTransform: 'uppercase',
            color: '#9a9189',
            fontFamily: 'IBM Plex Mono, monospace',
          }}
        >
          Today → Direction
        </div>
        <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
          <div
            style={{
              width: 110,
              height: 110,
              borderRadius: 26,
              overflow: 'hidden',
              boxShadow: '0 8px 22px rgba(20,22,28,0.18)',
            }}
          >
            <CurrentIcon size={110} />
          </div>
          <div style={{ color: '#9a9189', fontSize: 22, fontWeight: 300 }}>→</div>
          <div
            style={{
              width: 110,
              height: 110,
              borderRadius: 26,
              overflow: 'hidden',
              boxShadow: '0 8px 22px rgba(20,22,28,0.18)',
            }}
          >
            <window.Tape size={110} variant="teal" />
          </div>
        </div>
        <div
          style={{
            fontSize: 11,
            color: '#828680',
            fontFamily: 'IBM Plex Mono, monospace',
          }}
        >
          placeholder · 1 of 6 below
        </div>
      </div>
    </div>
  );
}

// Faithful reproduction of frontend/public/icon.svg from the repo, so the
// "before" sample on the hero card is honest.
function CurrentIcon({ size = 110 }) {
  return (
    <svg viewBox="0 0 192 192" width={size} height={size}>
      <defs>
        <linearGradient id="cur-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3b82f6" />
          <stop offset="100%" stopColor="#1e40af" />
        </linearGradient>
      </defs>
      <rect width="192" height="192" fill="url(#cur-grad)" />
      <text
        x="96"
        y="120"
        fontSize="80"
        fontWeight="bold"
        textAnchor="middle"
        fill="white"
        fontFamily="Arial, sans-serif"
      >
        T
      </text>
      <polyline
        points="40,140 60,100 80,120 100,80 120,110 140,90 160,60"
        stroke="white"
        strokeWidth="4"
        fill="none"
        strokeLinecap="round"
      />
    </svg>
  );
}

function App() {
  return (
    <DesignCanvas>
      <DCSection
        id="intro"
        title="Brief"
        subtitle="Replace placeholder · PWA + favicon · Calm v2 tokens"
      >
        <DCArtboard id="hero" label="Overview" width={1180} height={500}>
          <HeroIntro />
        </DCArtboard>
      </DCSection>

      <DCSection
        id="concepts"
        title="Concepts"
        subtitle="Six directions, all in one document — drag to reorder, click a card to focus"
      >
        {window.CONCEPTS.map((c) => (
          <DCArtboard
            key={c.id}
            id={c.id}
            label={c.title}
            width={1180}
            height={640}
          >
            <window.SpecimenSheet concept={c} />
          </DCArtboard>
        ))}
      </DCSection>

      <DCSection
        id="lineup"
        title="Side-by-side"
        subtitle="All six at PWA tile size, then all six as 16-px favicons"
      >
        <DCArtboard
          id="tiles"
          label="PWA tile lineup"
          width={1180}
          height={300}
        >
          <Lineup mode="tile" />
        </DCArtboard>
        <DCArtboard
          id="favicons"
          label="16-px favicon lineup"
          width={1180}
          height={220}
        >
          <Lineup mode="fav" />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

function Lineup({ mode }) {
  const isTile = mode === 'tile';
  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        padding: 28,
        boxSizing: 'border-box',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-around',
        gap: 24,
        background: isTile
          ? 'linear-gradient(180deg, #f0eee9, #e3e0db)'
          : '#f7f6f4',
        fontFamily: 'Inter, sans-serif',
      }}
    >
      {window.CONCEPTS.map((c) => (
        <div
          key={c.id}
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: isTile ? 14 : 10,
          }}
        >
          {isTile ? (
            <>
              <div
                style={{
                  width: 168,
                  height: 168,
                  borderRadius: 38,
                  overflow: 'hidden',
                  boxShadow:
                    '0 1px 0 rgba(255,255,255,0.5) inset, 0 14px 30px -8px rgba(20,22,28,0.28)',
                }}
              >
                <c.Icon size={168} variant="teal" />
              </div>
              <div style={{ fontSize: 12, color: '#3c4049', fontWeight: 500 }}>
                {c.title}
              </div>
            </>
          ) : (
            <>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 18,
                  padding: '14px 18px',
                  background: '#fff',
                  border: '1px solid #dcd9d4',
                  borderRadius: 10,
                  boxShadow: '0 2px 6px rgba(20,22,28,0.04)',
                }}
              >
                <div
                  style={{
                    width: 16,
                    height: 16,
                    borderRadius: 3,
                    overflow: 'hidden',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {c.favicon(16)}
                </div>
                <div
                  style={{
                    fontSize: 13,
                    color: '#161a22',
                    fontWeight: 500,
                  }}
                >
                  Trading Platform
                </div>
              </div>
              <div
                style={{
                  fontSize: 11,
                  color: '#6e6a62',
                  fontFamily: 'IBM Plex Mono, monospace',
                }}
              >
                {c.title}
              </div>
            </>
          )}
        </div>
      ))}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
