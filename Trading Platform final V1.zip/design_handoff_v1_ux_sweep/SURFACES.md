# Surfaces — implementation specs

Detailed per-surface guidance to read alongside the canvas. Open
`canvas/index.html` and pan to the named section.

---

## Splash & Hub

**Canvas section:** `#splash`. Open `canvas/splash.jsx` if you want to
look at the proposed structure in code form.

### Today's behaviour
- `AssetClassSplash.tsx` mounts on first load AND on every brand-click.
- Two huge cards (Stocks / Crypto), 1.5 px coloured borders + 3 px outer rings, inner filled CTAs, equity hero in accent colour.

### Proposed behaviour
- **First session only by default.** Subsequent loads skip the splash and land on the last-used silo's Discover.
- **Brand mark in TopBar becomes the hub-open button.** Real button, with ▾ chevron, silo name in the headline, version on a secondary line. Tapping it re-opens the hub.
- **Cards become summary cards** — 1 px borders, whole card is the affordance, no inner CTA, equity as content.

### Visual spec (proposed desktop)
- Layout: vertically centred. BrandMark + small uppercase "PAPER TRADING" eyebrow at top.
- Heading: "Pick a market to step into." — 26 px / 600 / `-0.02em` / centred.
- Two cards side-by-side, gap 18 px:
  - Card: `var(--panel)` bg, `1px solid var(--border)`, `var(--r)` radius, `var(--shadow-sm)`, padding `18px 22px`, min-width 280 px.
  - Inside: 6 px silo dot (Stocks → `--pos`, Crypto → `--accent`) + silo name (14/600) + position count (10.5/`--mute`).
  - Equity: mono / 24 / 600 / `-0.02em`.
  - Subline: `Day +1.24% · Open until 16:00` (stocks) or `Day −0.84% · 24/7` (crypto). 11.5 px / `--mute`.
- Footer: 11.5 px `--mute` text — *"Switch any time from the brand mark · ⌘K to ask anything"*.

### iPad portrait
Same layout, cards stack vertically (full-width up to 460 px max), gap 12 px.

### iPhone 12
BrandMark + eyebrow centred at top. Heading wraps to 2 lines. Cards stack
vertically, gap 10 px. Each card a slimmer version of the desktop card
(20 px equity, 13 px silo title). Footer: *"Tap the brand mark to switch any time."*

### Files to touch
- `frontend/src/components/AssetClassSplash.tsx` — strip the loud chrome, swap to summary cards.
- `frontend/src/App.tsx` — make the brand area in the desktop top row a real `<button>` that re-opens the splash. Remove the asset-class pill.
- `frontend/src/components/MobileHeader.tsx` — the hamburger trigger here can also re-open the splash via a drawer item.

---

## App shell · TopBar

**Canvas section:** `#shell`.

### Today's behaviour
- **Row 1** in `App.tsx`: BrandMark · v-pill · stocks/crypto toggle · 4-pill ModePill · AskPill · ThemeToggle · SettingsMenu.
- **Row 2** in `TopBar.tsx` (desktop): `OPEN/CLOSED · Polling · Equity ▾ · Day P/L · BP`.

### Proposed (desktop)
Single row, CSS grid `auto 1fr auto`, padding `14px 24px`, panel bg, 1 px bottom border.

**LEFT zone — Identity:**
- Brand button = BrandMark + `Stocks ▾` (14/600) + small `paper · 1.4.2` (10.5/mono/`--mute`) below.
- Inline OPEN status to the right of the brand button, separated by a 1 px hairline divider: 7 px `--pos` dot + `Open` (11/`--text-2`) + `until 16:00` (11/mono/`--mute`).
- The asset-class pill is **removed**. The brand button is how you switch silos.

**CENTRE zone — Mode:**
- ModePill (Discover / Portfolio / Chart / Workspace), centred via `justify-self: center`.

**RIGHT zone — Account & actions:**
- Equity readout: two-line stack, right-aligned. Top: `$124,316.42` (mono / 14 / 600). Bottom: `+$1,532.18 · +1.24% today` (mono / 11.5 / 600 / `--pos`).
- 1 px hairline right border separates the readout from actions.
- `✦ Ask · ⌘K` (accent outline button, ⌘K hint).
- Ghost-icon buttons: ☾ theme, ⚙ settings.

**Status row deletes entirely.** Polling chip becomes a yellow dot
overlapping the silo dot in the brand-button identity area, only
rendered when actually polling. BP moves to the Portfolio hero (see #8).

### iPad portrait
Same three-zone layout, gap 10 px. Ask pill shrinks to icon + ⌘K only.
Equity readout shrinks: top line is the dollar, bottom line is just the
%. Theme glyph removed (drawer-only). Wraps if needed.

### iPhone 12
Single strip, 3-col grid: ☰ · page-name+status / equity-pill.
- Centre column: page name (14/600) + inline `● Open · until 16:00` (10.5/`--mute`).
- Right column: equity pill — `$124,316` (mono/12/600) + small `+1.24%` chip (`--pos-bg`).
- ✦ Ask moves to a floating launcher (44×44, bottom-right, `--accent` bg, `--shadow`).

### Files to touch
- `frontend/src/App.tsx` — the top row.
- `frontend/src/components/TopBar.tsx` — collapses to a small helper for the equity readout / desktop strip → delete strip, keep the formatting helpers.
- `frontend/src/components/MobileHeader.tsx` — merge with `MobileStatusStrip`.
- `frontend/src/components/IconButton.tsx` — likely a new ghost variant for ☾/⚙.

---

## Discover

**Canvas section:** `#discover`. The iPad design is the model — desktop
inherits its density.

### Proposed layout (desktop, 1280 wide)
1. **Hero card** — 60/40 grid, full width.
   - **Left 60%**: eyebrow `Equity · stocks · paper`. Equity (mono/36/600). Day chip + `Day · vs market open` caption. Window switcher (1D / 1W / 1M / YTD / ALL — segmented control in `--panel-2`, active is `--panel` with shadow-sm). ~80 px area-filled PnL sparkline beneath.
   - **Right 40%**: 1 px hairline left border, eyebrow `Allocation`, 120 px donut (20 px thickness) on the left, legend on the right with row format `● symbol — %` (8 px dot in token colour, symbol bold, % mono mute right-aligned).
2. **MarketSummary card** — `border-left: 3px solid var(--cb-accent)`, ✦ glyph in `--cb-accent`, title `Mid-day update`, refresh link in corner (mono/`--mute`).
3. **Watchlist heading row** — `SectionHeading size="lg"` "Watchlist · 6 symbols · streaming", right-side sort dropdown.
4. **Watchlist grid** — 3 columns on desktop, 2 on iPad, 2 on iPhone (with smaller cards). Cards are `var(--panel)` + 1 px border + `var(--r)`, padding `14px 16px`:
   - Top row: symbol (14/600) + name (10.5/`--mute`) on the left, price (mono/16/600) on the right.
   - 48 px sparkline with 12% area fill underneath.
   - Bottom row: PLChip (sm) on the left, `Vol 32M · $3.4T` (mono/10.5/`--mute`) on the right.
5. **Add-symbol** — last grid cell is a dashed-outline `+ Add a symbol` ghost card. Persistent affordance, not separate UI.

### Spec — sparkline
- Stroke 1.5 px. Area fill at 13% opacity.
- Pos green (`--pos`) for `day >= 0`, red (`--neg`) otherwise.
- Use the existing `sparkPath` utility; add area-fill option.

### Disabled-AI MarketSummary
Render the AiDisabledNotice in-place but **keep the violet left rail and ✦ glyph**. Body becomes "Turn on" CTA + cost explainer. Don't drop the visual identity.

### Files to touch
- `frontend/src/components/DiscoverPage.tsx` — restructure the grid.
- `frontend/src/components/discover/BalanceCard.tsx` — merge with `AllocationCard` for the new hero. Or split into `DiscoverHero` and remove the side rail entirely.
- `frontend/src/components/discover/SparkCard.tsx` — denser layout, add area fill.
- `frontend/src/components/discover/util.ts` — `sparkPath` gets area-fill option.
- `frontend/src/components/MarketSummaryCard.tsx` — violet rail.
- `frontend/src/components/AiDisabledNotice.tsx` — keep host's colour identity (prop-driven).

---

## Portfolio

**Canvas section:** `#portfolio`.

### Proposed hero
Card, padding `20px 22px`. Grid `1.4fr 1fr`, gap 24 px:

**Left (1.4fr):**
- Eyebrow `Equity · stocks · paper`.
- Equity: mono / 38 / 600 / `-0.02em`.
- PLChip + caption "Day · vs market open".
- Window switcher (segmented; `1D 1W 1M YTD ALL`).
- ~70 px area-filled PnL sparkline using `usePnlHistory`.

**Right (1fr), with 1 px left hairline + 22 px left padding:**
- 2×2 grid of stats — Cash · Buying Power · Total P/L · Realised today.
- Each stat: 10.5 px uppercase eyebrow (`--mute`), then 18 px mono / 600 value.
- Total P/L and Realised use `--pos` / `--neg` colouring.

### Section hierarchy
- `SectionHeading` gets a `size` prop: `"sm" | "md" | "lg"`. Default `"md"` (14 px). `"lg"` = 18 px.
- **Positions** uses `size="lg"`. Right-side ctxRight is "+ Add manual lot" (ghost link, `--mute`).
- **Open orders + Recent activity** drop to a 2-col row below Positions. Both use `size="md"`.

### Orders (the inline cancel)
Replace the existing `window.confirm()` for cancel-all with an inline
confirm-row that appears in place of the section header:
- On cancel-all tap, the header `Open orders · 1 working · cancel all` swaps to: `Cancel all 1 working order?` + two buttons: `Yes, cancel` (red, ghost) and `Keep them` (default).

### Activity pagination
Add a `View all →` footer link inside the card. Implement: stops at 8
fills and shows the link. "View all" pushes a full-page Activity route
or opens a modal (existing pattern dependent — confirm with team).

### iPad / iPhone
- iPad: same hero layout, just smaller (30 px equity, 56 px sparkline). Stats drop to 3-col below the curve, inside the hero.
- iPhone: equity-only hero (26 px), 48 px sparkline, 3-col mini-stats below a hairline. Positions become individual cards (no table). Orders and Activity stay as compact lists below.

### Files to touch
- `frontend/src/components/PortfolioHero.tsx` — full rewrite of the layout.
- `frontend/src/components/SectionHeading.tsx` — add `size` prop.
- `frontend/src/components/Positions.tsx` — wrap with the new heading.
- `frontend/src/components/Orders.tsx` — inline cancel-all confirm + 2-col grid sibling layout in `Portfolio.tsx` (or wherever the sections are composed).
- `frontend/src/components/Activities.tsx` — "View all" footer.

---

## TradeBar & OrderSheet

**Canvas section:** `#trade`.

### Proposed sheet structure (mobile + desktop share)
- Drag handle (36×4 px pill, `--border-2`).
- **Header chip** identical in shape to the TradeBar dock chip — `display: inline-flex; gap: 5px; padding: 4px 9px; background: var(--panel-2); border-radius: 6px;` containing the symbol bold. Beside it: mono live price + PLChip.
- **Side picker** — segmented control inside a 1 px border + `var(--r)` radius. Active face is filled with the side colour (`--pos` for Buy, `--neg` for Sell), 13 px / 600. Inactive face is transparent, 13 px / 500 / `--text-2`. The face that's active on open matches what the user tapped on the dock-bar.
- **Field grid** — 2-col. Qty + Type as 1-col cells; TIF as a full-width row underneath. Each cell: 1 px border, `var(--r)` radius, padding `8px 10px`. Inside: 10 px uppercase eyebrow + mono/14/600 value.
- **Estimated cost pill** — full-width, padding `10px 12px`, `var(--r)` radius, background = `--pos-bg` for Buy / `--neg-bg` for Sell. Left side: 11 px `--text-2` caption "Est. cost · @ market". Right side: mono / 15 / 600, coloured = side colour.
- **Primary CTA** — full-width, 12 px padding, `var(--r)` radius, side colour bg, white text 14 px / 600. Label reads the trade back: `"Buy 10 AAPL · $2,248.30"` or `"Sell 10 AAPL · $2,248.30"`.

### Crypto path
When `isCrypto(symbol)` is true:
- TIF defaults to `GTC` and the dropdown only shows `GTC` / `IOC`. (Already enforced server-side; this is just the UI matching reality.)
- *Hide the "cancels at 16:00" caption.*
- Symbol chip and side colour are the same as stocks — that consistency is the point.
- (See annotation on canvas — keep the inline 12-word constraint explainer if there's room.)

### Continuity transition
The TradeBar's symbol chip should visibly become the sheet's header chip
when the sheet opens. Options:
- **A** — FLIP transition: measure both elements, animate transform.
- **B** — Cheaper: the sheet's enter animation slides up from the dock-bar's height, and the chip's position is identical at start (effectively, sheet enters from y = dock-bar-top). 200 ms / ease-out.

Pick B unless you've already done FLIP elsewhere in the app.

### Files to touch
- `frontend/src/components/trade/TradeBar.tsx` — symbol chip + opened-side state passes through to sheet.
- `frontend/src/components/trade/OrderSheet.tsx` — full restructure (this is also where the code-split priority #11 lives).

---

## Chart & ChartBot

**Canvas section:** `#chart`. TradingView's chrome (dark drawing rail,
header, y-axis) stays — we wrap it.

### Collapsed state — vertical rail
- 36 px wide, full height.
- Background: `oklch(60% 0.17 290 / 0.18)` (low-opacity `--cb-accent`).
- Left border: 1 px `oklch(60% 0.17 290 / 0.4)`.
- Content stacked vertically with `space-between`:
  - Top: 17 px ✦ glyph in `--cb-accent`.
  - Middle: rotated `-90deg` label "CHARTBOT" — 10 px / mono / `0.18em` letter-spacing / white / 0.7 opacity / no-wrap.
  - Bottom: a `‹` chevron in `--cb-accent` at 0.5 opacity.
- Tapping anywhere on the rail expands the panel.

### Expanded state — header
Panel: 380 px wide on desktop, ~28% of viewport on iPad (capped at 380),
full-bleed sheet on iPhone (existing behaviour).

Header:
- Padding `10px 14px`, `var(--bg)` background, 1 px bottom border.
- Row 1: ✦ in `--cb-accent` + `ChartBot` (13/600) + spacer + ⋯ + `›` (collapse).
- Row 2: small symbol chip (1 px border, `var(--panel)` bg, padding `2px 7px`, 11/600) + caption `5m · NASDAQ · streaming` (10.5/`--mute`).

The symbol + timeframe come from TradingView's active chart. There's
already a bridge to TV; subscribe to symbol-change events and update the
header.

### Empty-state chips
- `ChatEmptyState.tsx` becomes a chip wrap.
- Each chip: `background: var(--cb-accent-soft); color: var(--cb-accent); border: 0; border-radius: 99px; padding: 5px 9px; font-size: 11; display: inline-flex; gap: 4; align-items: center;`.
- Content: bold leading verb + body text. e.g. `<b>Draw</b> support at yesterday's low`.

### Footer convention hint
At the bottom of the chat input area, 9.5 px italic `--mute` text:
`Violet — cloud AI · ~3-5 s`. Dismissible after first 2-3 opens (track
in localStorage `chartbot_hint_seen` count).

### Files to touch
- `frontend/src/components/chat/ChatPanel.tsx` — collapsed = vertical rail (currently a circle stub).
- `frontend/src/components/chat/ChatHeader.tsx` — add symbol-context row, move "clear" to ⋯ overflow.
- `frontend/src/components/chat/ChatEmptyState.tsx` — chip layout.

---

## Workspace

**Canvas section:** `#workspace`.

### Proposed toolbar
CSS grid `auto 1fr auto`, padding `10px 18px`, panel bg, 1 px bottom border.

**LEFT — Named layouts:**
- `▦ Trader ▾` button. `var(--panel)` bg, 1 px border, `var(--r)` radius — looks like a stateful selector, not a generic dropdown.
- Small `save as…` ghost link beside it.

**CENTRE — Channels (centrepiece):**
- Wrap container: padding `5px 14px`, `var(--bg)` bg (lighter than panel), 1 px border, 10 px radius. Visually a "channels box."
- Eyebrow `CHANNELS` on the left (9.5/600/uppercase/`--mute`), separated by 1 px hairline.
- Active channel chips: `var(--panel)` bg + 1 px border + 7 px radius + `var(--shadow-sm)` + padding `5px 10px`. Contents: 8 px channel-colour dot + symbol bold (12) + secondary `main · 2 widgets` (9.5/`--mute`).
- Empty channels: dashed 1 px border + transparent bg. Contents: 8 px channel-colour dot at 40 % opacity + `+ green` / `+ amber`. Tappable — opens a "Bind to a symbol" picker.

**RIGHT — quiet actions:**
- `+ Widget` (12/`--text-2`/ghost button, no border).
- `⛶` fullscreen icon.

### Channel → tile relationship
Each Dockview widget tile already knows which channel it's bound to.
**Render the channel-colour as a 7 px dot in the tile's header**, leftmost,
before the title. Subtle but powerful — the user can scan the canvas and
see at a glance which tile is on which channel.

### Empty state
Centred:
- Uppercase eyebrow `EMPTY WORKSPACE` (11/`--mute`).
- Heading "Build your first canvas." (24/600/`-0.02em`).
- Subtext "Three ways to get going." (13/`--text-2`).
- Three buttons in a row, gap 10 px:
  - `+ Add widget` — primary accent.
  - `▦ Browse layouts` — secondary outline.
  - `✦ Ask AI to build one` — violet outline (`--cb-accent` border + colour), 600 weight.
- Italic caption below: *e.g. "watch the 7 largest semis with charts, fundamentals and news"*.

### Files to touch
- `frontend/src/components/Workspace.tsx` — the toolbar component near the top of the file.
- Widget tile headers in the same file (or wherever the Dockview tile wrapper lives) — add the channel dot.
- The empty-state component — add the third button + caption.

---

## Mobile additive layer

**Canvas section:** mobile-specific variants live in each surface's
section, marked `iPhone 12 · Proposed`.

Cross-cutting changes:

### One header strip
Merged from `MobileHeader` + `MobileStatusStrip`. See #9.

### Floating ✦ Ask launcher
- 44×44 px circle, bottom-right offset (right: 14 px, bottom: 70 px to clear TradeBar).
- `var(--accent)` bg, white ✦, `var(--shadow)`.
- Position: fixed.

### Sheet handle component
Extract the 36×4 `--border-2` rounded pill into `SheetHandle.tsx`. Use
in `EquitySheet`, `OrderSheet`, `BalanceSheet`, `AddToWatchlistSheet`.
Add real swipe-to-dismiss (gesture lib or hand-rolled).

### Drawer surfaces theme + AI toggles
`MobileNavDrawer.tsx` — under the mode-nav items, add a settings block
with theme toggle and the three AI toggles in a single dense list.
Don't make them dig through Settings.
