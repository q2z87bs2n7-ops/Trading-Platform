# Prompts for Claude Code

Copy-paste prompts to run in Claude Code, one per priority. Each
prompt assumes Claude Code has the repo + this handoff folder open.

---

## Boilerplate (prepend to every prompt)

```
You're implementing a UX-polish pass for our paper-trading platform.
The handoff bundle is at design_handoff_v1_ux_sweep/. Read the
following before writing code:

1. design_handoff_v1_ux_sweep/README.md  ← overview
2. design_handoff_v1_ux_sweep/PRIORITIES.md  ← this priority's row
3. design_handoff_v1_ux_sweep/SURFACES.md  ← detailed spec for this surface
4. design_handoff_v1_ux_sweep/TOKENS.md  ← design tokens (already in codebase)
5. design_handoff_v1_ux_sweep/canvas/<file>.jsx  ← visual reference for this surface

Code rules:
- Use existing Calm v2 CSS variables from frontend/src/index.css. Don't add new tokens.
- Match the established codebase pattern in each file you touch (utility classes vs hand-styled spans — follow what's already there in that component).
- Tailwind preflight is OFF; don't assume browser-default resets.
- All numeric values use IBM Plex Mono + font-variant-numeric: tabular-nums.
- Mobile = ≤640 px (useMobile hook). iPad / desktop share the desktop branch unless noted.
- Don't paste CSS values from the canvas .jsx files — they're inline-styled sketches. Use the codebase's vocabulary.
- After implementing, run the existing test suite + lint and verify the dev server starts clean.

Now implement priority {N}: {NAME}.
```

---

## #1 · TopBar → one row, three zones

```
Implement priority #1: collapse the desktop top bar into one row with
three zones (Identity · Mode · Account & actions).

Detailed spec: design_handoff_v1_ux_sweep/SURFACES.md → "App shell · TopBar".
Visual reference: design_handoff_v1_ux_sweep/canvas/topbar.jsx
  - TopBarProposedDesktop, TopBarProposedIpad, TopBarProposedPhone are the targets.

Files to touch:
- frontend/src/App.tsx (the top row)
- frontend/src/components/TopBar.tsx (delete the status strip; keep formatting helpers if reused)
- frontend/src/components/MobileHeader.tsx (merge with MobileStatusStrip for mobile)
- frontend/src/components/IconButton.tsx (likely need a ghost variant)

Important callouts:
- The AssetClassToggle pill goes away. Switching silo is the brand button's job.
- The polling chip becomes a dot overlapping the silo dot — only rendered when polling.
- BP moves to the Portfolio hero (don't try to relocate it in this PR; leave a TODO).
- On mobile, ✦ Ask moves to a floating launcher (44×44, bottom-right). Don't ship the launcher in this priority unless trivial — track separately.

Ship this priority by itself in a PR. Pairs naturally with #4 (brand-button-as-hub).
```

## #2 · TradeBar → OrderSheet continuity

```
Implement priority #2: make the TradeBar and OrderSheet feel like one
continuous flow.

Detailed spec: design_handoff_v1_ux_sweep/SURFACES.md → "TradeBar & OrderSheet".
Visual reference: design_handoff_v1_ux_sweep/canvas/trade.jsx
  - TradeProposedPhone, TradeProposedPhoneSell, TradeProposedPhoneCrypto, TradeProposedDesktop are the targets.

Files to touch:
- frontend/src/components/trade/TradeBar.tsx — chip becomes the handoff element; pass opened-side state to the sheet.
- frontend/src/components/trade/OrderSheet.tsx — restructure (do NOT do the code split yet; that's priority #11).

Three concrete changes:
1. The sheet's header chip uses the same visual shape as the TradeBar's symbol chip. Either FLIP-animate the handoff or just slide the sheet up from the TradeBar's position so the chip appears continuous.
2. Side picker is pre-set to whichever face the user tapped (Buy/Sell). The face is filled with the side colour. Tapping the other face flips the primary CTA colour.
3. Estimated cost is a coloured pill (--pos-bg / --neg-bg) matching the side. Primary CTA reads the trade back: "Buy 10 AAPL · $2,248.30".

Crypto path: TIF defaults to GTC, dropdown shows only GTC / IOC, no "cancels at 16:00" caption. Use the existing isCrypto helper.
```

## #3 · Desktop Discover hero + 2-col cards

```
Implement priority #3: restructure the desktop Discover layout.

Detailed spec: design_handoff_v1_ux_sweep/SURFACES.md → "Discover".
Visual reference: design_handoff_v1_ux_sweep/canvas/discover.jsx
  - DiscoverProposedDesktop is the target. Also see DiscoverProposedIpad and DiscoverProposedPhone for the responsive variants.

Files to touch:
- frontend/src/components/DiscoverPage.tsx — restructure the grid.
- frontend/src/components/discover/BalanceCard.tsx — fold into the new hero (or replace with DiscoverHero).
- frontend/src/components/discover/AllocationCard.tsx — promote into the hero's right side.
- frontend/src/components/discover/SparkCard.tsx — denser layout, area fill.
- frontend/src/components/discover/util.ts — add area-fill option to sparkPath.
- frontend/src/components/MarketSummaryCard.tsx — 3 px violet left rail.
- frontend/src/components/AiDisabledNotice.tsx — accept a prop for the host's accent so it keeps colour identity when disabled.

Hero spec:
- 60/40 grid. Left: equity (mono/36/600) + day chip + window switcher + ~80 px PnL sparkline (use usePnlHistory hook). Right: 1 px hairline left border, 120 px donut + labelled legend.
- Window switcher uses 1D/1W/1M/YTD/ALL as segmented control in --panel-2.

Watchlist grid: 3 cols desktop, 2 iPad, 2 iPhone. Each card has name + market cap + volume + 48 px sparkline with area fill + PLChip. Last grid cell is a persistent "+ Add a symbol" dashed-outline ghost card on every viewport.
```

## #4 · Calm the splash, promote the brand button

```
Implement priority #4: rework AssetClassSplash and the TopBar brand area.

Detailed spec: design_handoff_v1_ux_sweep/SURFACES.md → "Splash & Hub".
Visual reference: design_handoff_v1_ux_sweep/canvas/splash.jsx
  - SplashProposedDesktop, SplashProposedIpad, SplashProposedPhone.

Files to touch:
- frontend/src/components/AssetClassSplash.tsx — strip the loud chrome, swap to summary cards.
- frontend/src/App.tsx — make the brand area in the TopBar a real <button> that re-opens the splash.

Splash behaviour change (CONFIRM WITH CRAIG BEFORE LANDING):
- First-session: still show on first load.
- After first session: dismiss; subsequent loads land on last-used silo.
- Brand button re-opens the splash at any time.

Card spec:
- 1 px borders, var(--r) radius, var(--shadow-sm).
- 6 px silo dot (Stocks → --pos, Crypto → --accent) + silo name + position count.
- Equity in mono/24/600.
- Subline: "Day +1.24% · Open until 16:00" (stocks) or "Day -0.84% · 24/7" (crypto). Pull the day-pct from useAccount per silo.
```

## #5 · Workspace channels-as-centrepiece

```
Implement priority #5: rework the Workspace toolbar.

Detailed spec: design_handoff_v1_ux_sweep/SURFACES.md → "Workspace".
Visual reference: design_handoff_v1_ux_sweep/canvas/workspace.jsx
  - WorkspaceProposedDesktop and WorkspaceEmptyProposed are the targets.

Files to touch:
- frontend/src/components/Workspace.tsx — toolbar (near top of file).
- The same file — widget tile headers; add channel-colour dot.
- Workspace empty state component — add the "Ask AI to build one" third button.

Toolbar layout (grid auto 1fr auto):
- Left: named-layout selector "▦ Trader ▾" + "save as…" ghost link.
- Centre: "channels box" — padding 5px 14px, var(--bg) background (lighter than the toolbar's panel), 1 px border, 10 px radius. Inside: CHANNELS eyebrow + 1 px hairline + active channel chips + dashed-outline empty-channel "+ green / + amber" buttons.
- Right: "+ Widget" (quiet, no border) + fullscreen ⛶.

Tile headers: add a 7 px channel-colour dot before the title.

Empty state: third button "✦ Ask AI to build one" with violet outline (--cb-accent border + colour). Don't say "Claude" — keep AI references generic.
```

## #6 · ChartBot rail + chip empty state

```
Implement priority #6: restructure the chat panel rail + header + empty state.

Detailed spec: design_handoff_v1_ux_sweep/SURFACES.md → "Chart & ChartBot".
Visual reference: design_handoff_v1_ux_sweep/canvas/chart.jsx
  - ChartProposedDesktopRail (collapsed) and ChartProposedDesktopExpanded.

Files to touch:
- frontend/src/components/chat/ChatPanel.tsx — collapsed state is a full-height vertical rail (36 px wide).
- frontend/src/components/chat/ChatHeader.tsx — add the symbol-context row. Move "clear" to a ⋯ overflow menu (destructive, shouldn't be one-click).
- frontend/src/components/chat/ChatEmptyState.tsx — chip layout instead of vertical text.

Rail spec:
- Background: oklch(60% 0.17 290 / 0.18) — low-opacity --cb-accent.
- Left border: 1 px oklch(60% 0.17 290 / 0.4).
- Content stack: ✦ at top, rotated -90deg "CHARTBOT" label in the middle, ‹ chevron at bottom.

Empty-state chips: background --cb-accent-soft, color --cb-accent, border 0, radius 99 px. Leading bold verb ("Draw", "Add", "Mark", "Summarise") + body. Use the existing prompt list.

Symbol context comes from TradingView's active chart. There's already a bridge — subscribe to symbol-change events and update ChatHeader.

Footer hint: "Violet — cloud AI · ~3-5 s". 9.5 px italic --mute. Track count in localStorage; hide after 2-3 opens.
```

## #7 · AI disabled-state CTA + first-open hints

```
Implement priority #7: rework AiDisabledNotice and add first-open convention hints.

Detailed spec: design_handoff_v1_ux_sweep/SURFACES.md (AI surfaces section in PRIORITIES.md).
Visual reference: footer hint in design_handoff_v1_ux_sweep/canvas/chart.jsx → ChartProposedDesktopExpanded.

Files to touch:
- frontend/src/components/AiDisabledNotice.tsx — accept an `accent` prop (--accent for teal, --cb-accent for violet).
- frontend/src/components/MarketSummaryCard.tsx — pass --cb-accent.
- frontend/src/components/chat/ChatPanel.tsx — pass --cb-accent when AI is disabled.
- frontend/src/components/ask/AskBar.tsx — pass --accent when AI is disabled.
- frontend/src/components/SettingsMenu.tsx — accept a deep-link target so the notice's CTA can scroll the right toggle into view.

AiDisabledNotice changes:
- 3 px left rail in the host's accent token.
- Title: "{Surface name}" (e.g. "Market summary"). Subtitle: "off" chip on right.
- Body: what the surface does + cost caveat ("~$0.001 per generation" for violet; "free, instant" for teal).
- CTA: "Turn on" button in the host's accent. Onclick → SettingsMenu deep-link.

First-open hints (separate from AiDisabledNotice — these are when AI is ON):
- AskBar footer: "Teal — instant local parse · free · always on."
- ChartPanel footer: "Violet — cloud AI · ~3-5 s."
- Both: 9.5 px italic --mute, dismissible, hide after 3 opens (localStorage counter).
```

## #8 · Portfolio hierarchy

```
Implement priority #8: rework Portfolio with proper section hierarchy.

Detailed spec: design_handoff_v1_ux_sweep/SURFACES.md → "Portfolio".
Visual reference: design_handoff_v1_ux_sweep/canvas/portfolio.jsx
  - PortfolioProposedDesktop, PortfolioProposedIpad, PortfolioProposedPhone.

Files to touch:
- frontend/src/components/PortfolioHero.tsx — full rewrite.
- frontend/src/components/SectionHeading.tsx — add a `size` prop ("sm" | "md" | "lg"; default "md").
- frontend/src/components/Positions.tsx — wrap section with size="lg".
- frontend/src/components/Orders.tsx — inline confirm row for cancel-all (replace window.confirm).
- frontend/src/components/Activities.tsx — "View all →" footer.
- Wherever Portfolio composes the four sections — Orders + Activity drop to a 2-col grid below Positions.

Hero spec: see SURFACES.md → "Proposed hero". Uses usePnlHistory for the curve, useAccount for the inline stats (Cash / BP / Total P/L / Realised today).

Inline cancel-all: when user taps "cancel all", swap the section header to a confirm row: "Cancel all 1 working order? · [Yes, cancel] [Keep them]". No native confirm dialog.
```

## #9 · One mobile header strip

```
Implement priority #9: merge MobileHeader and MobileStatusStrip into one strip.

Detailed spec: design_handoff_v1_ux_sweep/SURFACES.md → "Mobile additive layer".
Visual reference: design_handoff_v1_ux_sweep/canvas/topbar.jsx → TopBarProposedPhone.
Floating ✦ launcher: design_handoff_v1_ux_sweep/canvas/discover.jsx → DiscoverProposedPhone.

Files to touch:
- frontend/src/components/MobileHeader.tsx — merge MobileStatusStrip into here.
- frontend/src/components/TopBar.tsx — delete MobileStatusStrip export.
- frontend/src/App.tsx (or wherever the floating Ask button lives) — add a fixed ✦ launcher.

Strip layout (CSS grid auto 1fr auto):
- Left: hamburger.
- Centre: page name (14/600) on row 1; "● Open · until 16:00" (10.5/--mute, 5 px --pos dot) on row 2.
- Right: equity pill button — "$124,316" (mono/12/600) + small "+1.24%" --pos-bg chip.

Floating ✦ Ask launcher: 44×44 circle, position fixed, right: 14 px, bottom: 70 px (clears TradeBar). --accent bg, white ✦, --shadow. Opens the AskBar bottom sheet.
```

## #10 · The polish nits (top 8)

```
Implement priority #10: pick 4-8 nits from the list below. Each is small.
Detailed list in design_handoff_v1_ux_sweep/PRIORITIES.md → "#10".

Highest-value picks:
1. Theme glyph — App.tsx ThemeToggle, swap to ☀ in dark / ☾ in light.
2. SettingsMenu grouping — AI / Account / System with thin separators.
3. Loading skeletons — 4-line shimmer on cards at first load. Reuse one component.
4. Toaster spacing + max-3 + overflow count.
5. Dark-mode --pos lightness — bump to ~62%. Verify positive P/L rows don't read as "selected".
6. SheetHandle component extraction + real swipe-to-dismiss.
7. ChartBot "clear" → ⋯ menu (destructive guard).
8. AssetSearch active row 2 px --accent left rail.

Pick by impact-per-hour. Verify each in light + dark.
```

## #11 · Split OrderSheet.tsx

```
Implement priority #11: refactor OrderSheet.tsx into four files. NO VISUAL CHANGE.

Current: frontend/src/components/trade/OrderSheet.tsx (1,390 lines).

Target structure:
- frontend/src/components/trade/OrderSheet.tsx — shell + dialog + side-picker (~250 lines).
- frontend/src/components/trade/OrderSheetFields.tsx — Qty / Type / TIF / Limit price / Stop price / Trailing fields, branched by order type + asset class (~400 lines).
- frontend/src/components/trade/OrderSheetConfirm.tsx — review step + place button + error states (~250 lines).
- frontend/src/components/trade/useOrderTicket.ts — state, est-cost compute, crypto guards, fractional logic (~400 lines).

Constraints:
- Pixel-identical rendering before and after. Diff a screenshot if uncertain.
- Crypto guards from docs/landmines.md must remain — TIF (gtc/ioc only), no trailing_stop, non_marginable_buying_power for BP.
- All Alpaca order types still work: market, limit, stop, stop_limit, trailing_stop.
- The existing OrderSheet test suite must pass without changes.

Suggested order:
1. Extract useOrderTicket first (state lives there); verify the existing OrderSheet still works using the hook.
2. Extract OrderSheetFields (pure presentation, hooked into useOrderTicket).
3. Extract OrderSheetConfirm.
4. The remaining OrderSheet.tsx should be ≤300 lines.
```

## #12 · Tailwind preflight migration

```
Implement priority #12: enable Tailwind preflight (or ship a minimal reset).

Current: frontend/tailwind.config.js has corePlugins.preflight: false.

Option A — full migration (recommended after the demo):
1. Set corePlugins.preflight: true.
2. Grep for browser-default reliances in components/: bare <button>, <ul>, <input>, <fieldset>, <h1-6>.
3. Fix each regression with utility classes or explicit styles.

Option B — minimal reset (recommended before the demo):
1. Create frontend/src/app-reset.css with just:
   - button { background: none; border: 0; padding: 0; font: inherit; color: inherit; cursor: pointer; }
   - ul, ol { list-style: none; padding: 0; margin: 0; }
   - fieldset { border: 0; margin: 0; padding: 0; }
   - h1, h2, h3, h4, h5, h6 { font: inherit; margin: 0; }
2. Import it after index.css.
3. Fix the small handful of regressions this causes (mostly inside ChatPanel message bullet styling).

For the demo, do B. After the demo, do A.
```
