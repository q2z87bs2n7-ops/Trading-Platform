# Design tokens — reference

All tokens already exist in `frontend/src/index.css` (Calm v2). This
file is a quick lookup. **Don't introduce new tokens.** If a value
isn't here, derive it from these.

---

## Surfaces

| Token | Value | Use |
|---|---|---|
| `--bg` | `#f7f6f4` | Page background (warm off-white). |
| `--panel` | `#ffffff` | Card / panel surface. |
| `--panel-2` | `#efedea` | Recessed surface — segmented control background, eyebrow chips, table-header rows. |
| `--panel-3` | `#e5e3df` | Quieter still — donut "remainder" segments, ghost placeholders. |
| `--border` | `#dcd9d4` | Primary borders. |
| `--border-2` | `#b8b5af` | Secondary borders / drag-handle pills. |
| `--hairline` | `rgba(20, 22, 28, 0.06)` | Section-level dividers inside cards. |

## Text

| Token | Value | Use |
|---|---|---|
| `--text` | `#161a22` | Primary text. |
| `--text-2` | `#4a505c` | Body copy / readable secondary. |
| `--mute` | `#828680` | Captions, eyebrows, metadata. |

## Accents — semantic

| Token | Value | Use |
|---|---|---|
| `--accent` | `oklch(46% 0.07 200)` | App accent. **Default = crypto blue.** |
| `--accent-2` | `oklch(34% 0.06 200)` | Hover / pressed variant. |
| `--accent-bg` | `oklch(46% 0.07 200 / 0.09)` | Accent chip backgrounds. |
| `--accent-soft` | `oklch(95% 0.02 200)` | Selected-row backgrounds. |
| `--pos` | `oklch(48% 0.11 155)` | Positive P/L. **Also = stocks silo accent.** |
| `--neg` | `oklch(52% 0.18 25)` | Negative P/L / destructive. |
| `--pos-bg` | `oklch(48% 0.11 155 / 0.09)` | Pos chip bg. |
| `--neg-bg` | `oklch(52% 0.18 25 / 0.09)` | Neg chip bg. |
| `--warn` | `oklch(70% 0.13 75)` | Polling / amber states. |
| `--warn-bg` | `oklch(70% 0.13 75 / 0.15)` | Warn chip bg. |

## ChartBot / cloud-AI surfaces

| Token | Value | Use |
|---|---|---|
| `--cb-accent` | `oklch(60% 0.17 290)` | ChartBot violet — credit-spending AI surfaces only. |
| `--cb-accent-soft` | `oklch(94% 0.04 290)` | Empty-state prompt chip backgrounds. |

### Convention
- **Teal/blue accent** (`--accent`) = local intent parser (free, instant). Ask anything bar.
- **Violet** (`--cb-accent`) = real cloud AI (credits, ~3–5 s). Market summary, ChartBot.

Don't mix. Don't introduce a third AI colour.

---

## Shadows

| Token | Value | Use |
|---|---|---|
| `--shadow-sm` | `0 1px 1px rgba(20,22,28,0.04), 0 1px 2px rgba(20,22,28,0.03)` | Cards (default). |
| `--shadow` | `0 4px 24px rgba(20,22,28,0.05)` | TradeBar, raised dock surfaces. |
| `--shadow-lg` | `0 24px 60px rgba(20,22,28,0.16)` | Modals (the value reads as smudge on warm bg — consider trimming to `0 12px 32px rgba(20,22,28,0.10)`). |

---

## Radii

| Token | Value | Use |
|---|---|---|
| `--r` | `10px` | Cards. |
| `--r-lg` | `14px` | Dialogs / sheets. |
| `--r-xl` | `18px` | Full-bleed sheets (top corners only). |

Note: `--r` and `--r-lg` are visually close (10 vs 14). If you have time
in the polish pass, widen to 10 / 16 / 22 — the rhythm becomes
intentional. Not required for the demo.

---

## Type

| Family | Use |
|---|---|
| `--font-sans` (Inter) | UI text. |
| `--font-mono` (IBM Plex Mono) | All numerics (price, equity, percent, time, vol). |

**Every price / equity / percent must use `font-variant-numeric:
tabular-nums`.** This is non-negotiable — it's the single biggest
visual signal that this app is for traders.

### Scale (no formal scale exists yet; these are the values in use)

| Size | Use |
|---|---|
| 10–10.5 px | Eyebrow / metadata captions. |
| 11–11.5 px | Secondary labels, chip text. |
| 12–13 px | Body. |
| 13–14 px | Card headings, dense table rows. |
| 16–18 px | Section headings (lg variant — see #8). |
| 20–24 px | iPhone hero equity. |
| 26–30 px | iPad hero equity. |
| 32–38 px | Desktop hero equity. |

---

## Spacing

No spacing scale defined as tokens. The codebase uses ad-hoc px values.
Stick to a **4 px base** (4 / 6 / 8 / 10 / 12 / 14 / 18 / 22 / 24) — most
existing code already does. Don't introduce 5 / 7 / 11 / 13.

---

## Dark mode

Dark variant under `html[data-theme="dark"]`. Same token names, different
values. One known issue: `--pos` in dark is close enough to active-row
backgrounds that positive P/L rows can look "selected." Bumping dark
`--pos` to ~62% lightness fixes it. See priority #10.

---

## Per-silo accent override

The CSS rule already exists:

```css
.silo-stocks {
  --accent: var(--pos);
  --accent-2: var(--pos);
  --accent-bg: var(--pos-bg);
}
```

Apply `silo-stocks` (or `silo-crypto`, default) at the App root depending
on the active silo. Every accent in the tree shifts to green for stocks,
stays blue for crypto.

**Don't** override AI tokens this way — `--cb-accent` stays violet
across silos.
