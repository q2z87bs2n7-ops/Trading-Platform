/* ─────────────────────────────────────────────────────────────────
   Portfolio surface. Hero · Positions · Orders · Activity.
   Today: 4 equal sections. Proposed: anchored hierarchy.
   ───────────────────────────────────────────────────────────────── */

/* shared header */
function PageHeader({ proposed = false }) {
  return (
    <div style={{
      display: proposed ? "grid" : "flex",
      gridTemplateColumns: proposed ? "auto 1fr auto" : undefined,
      alignItems: "center", justifyContent: proposed ? undefined : "space-between",
      columnGap: 24,
      padding: "12px 24px",
      background: "var(--panel)", borderBottom: "1px solid var(--border)",
    }}>
      {proposed ? (
        <>
          <button style={{ display: "inline-flex", alignItems: "center", gap: 10, background: "transparent", border: 0, padding: 0, cursor: "pointer" }}>
            <BrandMark />
            <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15, alignItems: "flex-start" }}>
              <span style={{ fontSize: 14, fontWeight: 600 }}>Stocks <span style={{ fontSize: 10, color: "var(--mute)" }}>▾</span></span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 10.5, color: "var(--mute)" }}>
                <span style={{ width: 5, height: 5, borderRadius: 99, background: "var(--pos)" }} />
                Open · until 16:00
              </span>
            </div>
          </button>
          <div style={{ justifySelf: "center" }}><ModePill active="Portfolio" /></div>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 12 }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", lineHeight: 1.15 }}>
              <span className="mono" style={{ fontSize: 13, fontWeight: 600 }}>{FMT.money(124316.42)}</span>
              <span className="mono pos" style={{ fontSize: 11, fontWeight: 600 }}>+1.24% today</span>
            </div>
            <IconBtn style={{ borderColor: "var(--accent)", color: "var(--accent)" }}>
              <span style={{ color: "var(--accent)" }}>✦</span><span>Ask</span>
            </IconBtn>
            <IconBtn ghost style={{ width: 30, height: 30, justifyContent: "center" }}>⚙</IconBtn>
          </div>
        </>
      ) : (
        <>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <BrandMark size={24} />
            <span style={{ fontSize: 13, color: "var(--mute)" }} className="mono">stocks · v1.4.2</span>
          </div>
          <ModePill active="Portfolio" />
        </>
      )}
    </div>
  );
}

/* positions row */
function PosRow({ p, dense = false }) {
  const up = p.pl >= 0;
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "minmax(70px, 1fr) 60px 80px 100px 80px 100px auto",
      gap: 12, alignItems: "center",
      padding: dense ? "8px 14px" : "10px 14px",
      borderBottom: "1px solid var(--hairline)",
      fontSize: 12.5,
    }}>
      <span style={{ fontWeight: 600 }}>{p.sym}</span>
      <span className="mono" style={{ color: "var(--mute)" }}>{p.qty}</span>
      <span className="mono">${p.avg.toFixed(2)}</span>
      <span className="mono">${p.last.toFixed(2)}</span>
      <span className="mono" style={{ fontWeight: 600 }}>${p.mv.toLocaleString()}</span>
      <span className={up ? "mono pos" : "mono neg"} style={{ fontWeight: 600 }}>{up ? "+" : ""}{p.pl.toFixed(2)} ({(p.plpc*100).toFixed(2)}%)</span>
      <span style={{ color: "var(--mute)", fontSize: 11, justifySelf: "end" }}>⋯</span>
    </div>
  );
}
function PosHead({ dense = false }) {
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "minmax(70px, 1fr) 60px 80px 100px 80px 100px auto",
      gap: 12, alignItems: "center",
      padding: dense ? "6px 14px" : "8px 14px",
      borderBottom: "1px solid var(--border)",
      background: "var(--panel-2)",
      fontSize: 10.5, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--mute)",
    }}>
      <span>Symbol</span><span>Qty</span><span>Avg</span><span>Last</span><span>Mkt Value</span><span>P/L</span><span />
    </div>
  );
}

/* ── Today ─────────────────────────────────────────────────── */
function PortfolioTodayDesktop() {
  const a = window.MOCK.account, pos = window.MOCK.positions;
  return (
    <div className="silo-stocks artboard-app">
      <PageHeader />
      <div style={{ flex: 1, overflow: "auto", padding: 20 }}>
        {/* Hero (small) */}
        <Card p="14px 16px">
          <Eyebrow>Equity</Eyebrow>
          <div className="mono" style={{ fontSize: 26, fontWeight: 600, marginTop: 4 }}>{FMT.money(a.equity)}</div>
          <div style={{ marginTop: 6 }}><PLChip value={a.day_pl} pct={a.day_pct} /></div>
        </Card>
        {/* Positions */}
        <div style={{ marginTop: 18 }}>
          <SectionHeading label="Positions" ctx={`${pos.length} open`} />
          <Card p="0">
            <PosHead /><div>{pos.map(p => <PosRow key={p.sym} p={p} />)}</div>
          </Card>
        </div>
        {/* Orders */}
        <div style={{ marginTop: 18 }}>
          <SectionHeading label="Orders" ctx="1 open" />
          <Card p="0">
            <div style={{ padding: "10px 14px", fontSize: 12.5, borderBottom: "1px solid var(--hairline)", display: "flex", justifyContent: "space-between" }}>
              <span><b>NVDA</b> · Limit Buy 50 @ $115.00</span>
              <span style={{ color: "var(--mute)" }}>DAY · 14:08 · <span style={{ color: "var(--neg)" }}>cancel</span></span>
            </div>
          </Card>
        </div>
        {/* Activity */}
        <div style={{ marginTop: 18 }}>
          <SectionHeading label="Activity" ctx="recent fills" />
          <Card p="0">
            {[
              { sym: "TSLA", side: "Buy", qty: 25, px: 374.10, t: "13:42" },
              { sym: "AAPL", side: "Buy", qty: 20, px: 222.18, t: "11:08" },
              { sym: "AMZN", side: "Sell", qty: 10, px: 214.92, t: "09:34" },
            ].map(r => (
              <div key={r.t} style={{ padding: "8px 14px", fontSize: 12, borderBottom: "1px solid var(--hairline)", display: "flex", justifyContent: "space-between" }}>
                <span><span style={{ color: r.side==="Buy"?"var(--pos)":"var(--neg)", fontWeight: 600 }}>{r.side}</span> · <b>{r.sym}</b> · {r.qty} @ <span className="mono">${r.px.toFixed(2)}</span></span>
                <span style={{ color: "var(--mute)" }} className="mono">{r.t}</span>
              </div>
            ))}
          </Card>
        </div>
      </div>
      <Annotations notes={[
        { x: 28, y: 90, n: 1, side: "right", label: "Hero card is small — no breathing room. Day P/L treatment same as a chip on any other card." },
        { x: 28, y: 240, n: 2, side: "right", label: "All four sections use identical SectionHeading. Positions reads no bigger than Activity." },
        { x: 28, y: 510, n: 3, side: "right", label: "Orders has only 1 row but takes full width; Activity has 3 fills, same width. Two-column rail wasted." },
      ]} />
    </div>
  );
}

/* ── Proposed ──────────────────────────────────────────────── */
function PortfolioProposedDesktop() {
  const a = window.MOCK.account, pos = window.MOCK.positions;
  return (
    <div className="silo-stocks artboard-app">
      <PageHeader proposed />
      <div style={{ flex: 1, overflow: "auto", padding: "20px 24px" }}>
        {/* Hero — promoted */}
        <Card p="20px 22px">
          <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 24 }}>
            <div>
              <Eyebrow>Equity · stocks · paper</Eyebrow>
              <div className="mono" style={{ fontSize: 38, fontWeight: 600, letterSpacing: "-0.02em", marginTop: 4 }}>{FMT.money(a.equity)}</div>
              <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 8 }}>
                <PLChip value={a.day_pl} pct={a.day_pct} />
                <span style={{ fontSize: 11, color: "var(--mute)" }}>Day · vs market open</span>
              </div>
              <div style={{ display: "inline-flex", gap: 4, padding: 3, marginTop: 12, background: "var(--panel-2)", border: "1px solid var(--border)", borderRadius: 8 }}>
                {["1D","1W","1M","YTD","ALL"].map((p,i)=>(
                  <span key={p} style={{ fontSize: 11, padding: "4px 9px", background: i===0?"var(--panel)":"transparent", color: i===0?"var(--text)":"var(--text-2)", fontWeight: i===0?600:500, borderRadius: 6, boxShadow: i===0?"var(--shadow-sm)":"none" }}>{p}</span>
                ))}
              </div>
              <div style={{ marginTop: 12, height: 70 }}>
                <Spark data={window.MOCK.pnlCurve} color="var(--pos)" fill stroke={1.75} />
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18, paddingLeft: 22, borderLeft: "1px solid var(--hairline)" }}>
              {[
                { l: "Cash", v: FMT.money(a.cash) },
                { l: "Buying power", v: FMT.money(a.buying_power) },
                { l: "Total P/L", v: "+$11,840.22", color: "var(--pos)" },
                { l: "Realised today", v: "+$418.30", color: "var(--pos)" },
              ].map(s => (
                <div key={s.l}>
                  <div style={{ fontSize: 10.5, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--mute)" }}>{s.l}</div>
                  <div className="mono" style={{ fontSize: 18, fontWeight: 600, marginTop: 2, color: s.color || "var(--text)" }}>{s.v}</div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Positions — primary, big heading */}
        <div style={{ marginTop: 22 }}>
          <SectionHeading size="lg" label="Positions" ctx={`${pos.length} open · sorted by market value`}
            ctxRight={<span style={{ fontSize: 11, color: "var(--mute)" }}>+ Add manual lot</span>} />
          <Card p="0">
            <PosHead /><div>{pos.map(p => <PosRow key={p.sym} p={p} />)}</div>
          </Card>
        </div>

        {/* Orders + Activity — secondary, 2-col */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginTop: 22 }}>
          <div>
            <SectionHeading label="Open orders" ctx="1 working"
              ctxRight={<span style={{ fontSize: 11, color: "var(--mute)" }}>cancel all</span>} />
            <Card p="0">
              <div style={{ padding: "10px 14px", fontSize: 12.5, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div><b>NVDA</b> · <span style={{ color: "var(--pos)" }}>Buy</span> 50 @ <span className="mono">$115.00</span></div>
                  <div style={{ fontSize: 10.5, color: "var(--mute)" }}>Limit · DAY · placed 14:08</div>
                </div>
                <button style={{ background: "transparent", border: "1px solid var(--border)", color: "var(--neg)", fontSize: 11, padding: "3px 8px", borderRadius: 5 }}>Cancel</button>
              </div>
            </Card>
          </div>
          <div>
            <SectionHeading label="Recent activity" ctx="last 24 h · 12 fills" />
            <Card p="0">
              {[
                { sym: "TSLA", side: "Buy", qty: 25, px: 374.10, t: "13:42" },
                { sym: "AAPL", side: "Buy", qty: 20, px: 222.18, t: "11:08" },
                { sym: "AMZN", side: "Sell", qty: 10, px: 214.92, t: "09:34" },
              ].map(r => (
                <div key={r.t} style={{ padding: "8px 14px", fontSize: 12, borderBottom: "1px solid var(--hairline)", display: "flex", justifyContent: "space-between" }}>
                  <span><span style={{ color: r.side==="Buy"?"var(--pos)":"var(--neg)", fontWeight: 600 }}>{r.side}</span> · <b>{r.sym}</b> · {r.qty} @ <span className="mono">${r.px.toFixed(2)}</span></span>
                  <span style={{ color: "var(--mute)" }} className="mono">{r.t}</span>
                </div>
              ))}
              <div style={{ padding: "8px 14px", fontSize: 11, color: "var(--accent)", textAlign: "center" }}>View all →</div>
            </Card>
          </div>
        </div>
      </div>
      <Annotations notes={[
        { x: 40, y: 90, n: "A", side: "right", label: "Hero is promoted: 38 px equity + window switcher + 70 px PnL curve (uses your usePnlHistory hook). Cash · BP · Total P/L · Realised live INSIDE the hero — the status strip dies." },
        { x: 40, y: 310, n: "B", side: "right", label: "Positions gets the big SectionHeading variant — primary in the visual hierarchy." },
        { x: 40, y: 480, n: "C", side: "right", label: "Orders + Activity drop to a secondary two-column row. Orders rows are still actionable (inline Cancel button) — Activity becomes an archive that paginates." },
      ]} />
    </div>
  );
}

/* ── iPad ──────────────────────────────────────────────────── */
function PortfolioTodayIpad() {
  const a = window.MOCK.account, pos = window.MOCK.positions;
  return (
    <div className="silo-stocks artboard-app">
      <PageHeader />
      <div style={{ flex: 1, overflow: "auto", padding: 16 }}>
        <Card p="12px 14px"><Eyebrow>Equity</Eyebrow><div className="mono" style={{ fontSize: 24, fontWeight: 600, marginTop: 4 }}>{FMT.money(a.equity)}</div><div style={{ marginTop: 6 }}><PLChip value={a.day_pl} pct={a.day_pct} /></div></Card>
        <div style={{ marginTop: 16 }}><SectionHeading label="Positions" ctx="3 open" /><Card p="0"><PosHead dense /><div>{pos.map(p => <PosRow key={p.sym} p={p} dense />)}</div></Card></div>
        <div style={{ marginTop: 16 }}><SectionHeading label="Orders" ctx="1 open" /><Card p="0"><div style={{ padding: "8px 12px", fontSize: 11.5, display: "flex", justifyContent: "space-between" }}><span><b>NVDA</b> · Limit Buy 50 @ $115</span><span style={{ color: "var(--neg)" }}>cancel</span></div></Card></div>
        <div style={{ marginTop: 16 }}><SectionHeading label="Activity" ctx="recent fills" /><Card p="0"><div style={{ padding: "8px 12px", fontSize: 11.5 }}>TSLA · Buy 25 @ $374.10 · 13:42</div></Card></div>
      </div>
    </div>
  );
}
function PortfolioProposedIpad() {
  const a = window.MOCK.account, pos = window.MOCK.positions;
  return (
    <div className="silo-stocks artboard-app">
      <PageHeader proposed />
      <div style={{ flex: 1, overflow: "auto", padding: 16 }}>
        <Card p="16px 18px">
          <Eyebrow>Equity</Eyebrow>
          <div className="mono" style={{ fontSize: 30, fontWeight: 600, marginTop: 4 }}>{FMT.money(a.equity)}</div>
          <div style={{ marginTop: 6 }}><PLChip value={a.day_pl} pct={a.day_pct} /></div>
          <div style={{ marginTop: 10, height: 56 }}><Spark data={window.MOCK.pnlCurve} color="var(--pos)" fill stroke={1.5} /></div>
          <div style={{ display: "inline-flex", gap: 4, padding: 3, marginTop: 8, background: "var(--panel-2)", border: "1px solid var(--border)", borderRadius: 8 }}>
            {["1D","1W","1M","YTD","ALL"].map((p,i)=>(<span key={p} style={{ fontSize: 10, padding: "3px 8px", background: i===0?"var(--panel)":"transparent", color: i===0?"var(--text)":"var(--text-2)", fontWeight: i===0?600:500, borderRadius: 5, boxShadow: i===0?"var(--shadow-sm)":"none" }}>{p}</span>))}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14, marginTop: 12, paddingTop: 12, borderTop: "1px solid var(--hairline)" }}>
            <div><div style={{ fontSize: 10, color: "var(--mute)", textTransform: "uppercase", letterSpacing: "0.06em" }}>Cash</div><div className="mono" style={{ fontSize: 14, fontWeight: 600 }}>{FMT.short(a.cash)}</div></div>
            <div><div style={{ fontSize: 10, color: "var(--mute)", textTransform: "uppercase", letterSpacing: "0.06em" }}>BP</div><div className="mono" style={{ fontSize: 14, fontWeight: 600 }}>{FMT.short(a.buying_power)}</div></div>
            <div><div style={{ fontSize: 10, color: "var(--mute)", textTransform: "uppercase", letterSpacing: "0.06em" }}>Total P/L</div><div className="mono pos" style={{ fontSize: 14, fontWeight: 600 }}>+$11,840</div></div>
          </div>
        </Card>
        <div style={{ marginTop: 18 }}><SectionHeading size="lg" label="Positions" ctx={`${pos.length} open`} /><Card p="0"><PosHead dense /><div>{pos.map(p => <PosRow key={p.sym} p={p} dense />)}</div></Card></div>
        <div style={{ marginTop: 18, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          <div><SectionHeading label="Open orders" ctx="1" /><Card p="0"><div style={{ padding: "8px 12px", fontSize: 11.5 }}><b>NVDA</b> · Buy 50 @ $115</div></Card></div>
          <div><SectionHeading label="Activity" ctx="recent" /><Card p="0"><div style={{ padding: "8px 12px", fontSize: 11.5 }}>TSLA · Buy 25 @ $374</div></Card></div>
        </div>
      </div>
    </div>
  );
}

/* ── iPhone ───────────────────────────────────────────────── */
function PortfolioTodayPhone() {
  const a = window.MOCK.account, pos = window.MOCK.positions;
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ height: 22 }} />
      <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}><span style={{ fontSize: 18 }}>☰</span><span style={{ fontSize: 14, fontWeight: 600 }}>Portfolio</span><span style={{ width: 28 }} /></div>
      <div style={{ flex: 1, padding: 12, overflow: "auto" }}>
        <Card><Eyebrow>Equity</Eyebrow><div className="mono" style={{ fontSize: 24, fontWeight: 600 }}>{FMT.money(a.equity)}</div><div style={{ marginTop: 4 }}><PLChip value={a.day_pl} pct={a.day_pct} sm /></div></Card>
        <div style={{ marginTop: 12, fontSize: 12, fontWeight: 600 }}>Positions</div>
        <div style={{ marginTop: 6 }}>{pos.map(p => (<Card key={p.sym} p="10px 12px" style={{ marginBottom: 6 }}><div style={{ display: "flex", justifyContent: "space-between" }}><b>{p.sym}</b><span className={p.pl>=0?"mono pos":"mono neg"}>{p.pl>=0?"+":""}{p.pl.toFixed(2)}</span></div><div style={{ fontSize: 11, color: "var(--mute)" }} className="mono">{p.qty} sh · ${p.last.toFixed(2)}</div></Card>))}</div>
        <div style={{ marginTop: 10, fontSize: 12, fontWeight: 600 }}>Orders</div>
        <Card p="10px 12px" style={{ marginTop: 6 }}><div style={{ fontSize: 12 }}><b>NVDA</b> · Buy 50 @ $115</div></Card>
        <div style={{ marginTop: 10, fontSize: 12, fontWeight: 600 }}>Activity</div>
        <Card p="10px 12px" style={{ marginTop: 6 }}><div style={{ fontSize: 11.5 }}>TSLA · Buy 25 @ $374 · 13:42</div></Card>
      </div>
    </div>
  );
}
function PortfolioProposedPhone() {
  const a = window.MOCK.account, pos = window.MOCK.positions;
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ height: 22 }} />
      <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", columnGap: 10, alignItems: "center", padding: "10px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <span style={{ fontSize: 18 }}>☰</span>
        <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Portfolio</span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 10.5, color: "var(--mute)" }}><span style={{ width: 5, height: 5, borderRadius: 99, background: "var(--pos)" }} />Open · until 16:00</span>
        </div>
        <button style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 9px", background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 8 }}>
          <span className="mono" style={{ fontWeight: 600, fontSize: 12 }}>$124,316</span>
          <Chip color="var(--pos)" bg="var(--pos-bg)" sm>+1.24%</Chip>
        </button>
      </div>
      <div style={{ flex: 1, padding: 12, overflow: "auto" }}>
        <Card>
          <Eyebrow>Equity</Eyebrow>
          <div className="mono" style={{ fontSize: 26, fontWeight: 600 }}>{FMT.money(a.equity)}</div>
          <div style={{ marginTop: 4 }}><PLChip value={a.day_pl} pct={a.day_pct} sm /></div>
          <div style={{ marginTop: 8, height: 48 }}><Spark data={window.MOCK.pnlCurve} color="var(--pos)" fill stroke={1.5} /></div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginTop: 8, paddingTop: 8, borderTop: "1px solid var(--hairline)" }}>
            <div><div style={{ fontSize: 9, color: "var(--mute)", textTransform: "uppercase", letterSpacing: "0.06em" }}>Cash</div><div className="mono" style={{ fontSize: 12, fontWeight: 600 }}>{FMT.short(a.cash)}</div></div>
            <div><div style={{ fontSize: 9, color: "var(--mute)", textTransform: "uppercase", letterSpacing: "0.06em" }}>BP</div><div className="mono" style={{ fontSize: 12, fontWeight: 600 }}>{FMT.short(a.buying_power)}</div></div>
            <div><div style={{ fontSize: 9, color: "var(--mute)", textTransform: "uppercase", letterSpacing: "0.06em" }}>Total P/L</div><div className="mono pos" style={{ fontSize: 12, fontWeight: 600 }}>+$11.8k</div></div>
          </div>
        </Card>
        <div style={{ marginTop: 14, display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Positions</span>
          <span style={{ fontSize: 10.5, color: "var(--mute)" }}>{pos.length} · by MV</span>
        </div>
        <div style={{ marginTop: 6 }}>{pos.map(p => (
          <Card key={p.sym} p="10px 12px" style={{ marginBottom: 6 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
              <div><b>{p.sym}</b> <span style={{ fontSize: 10.5, color: "var(--mute)" }} className="mono">{p.qty} sh</span></div>
              <span className="mono" style={{ fontSize: 13, fontWeight: 600 }}>${p.mv.toLocaleString()}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
              <span style={{ fontSize: 10.5, color: "var(--mute)" }} className="mono">@ ${p.last.toFixed(2)}</span>
              <span className={p.pl>=0?"mono pos":"mono neg"} style={{ fontSize: 11, fontWeight: 600 }}>{p.pl>=0?"+":""}${p.pl.toFixed(2)} ({(p.plpc*100).toFixed(2)}%)</span>
            </div>
          </Card>
        ))}</div>
        <div style={{ marginTop: 12, display: "flex", justifyContent: "space-between", alignItems: "baseline" }}><span style={{ fontSize: 13, fontWeight: 600 }}>Open orders</span><span style={{ fontSize: 10, color: "var(--mute)" }}>1 working</span></div>
        <Card p="10px 12px" style={{ marginTop: 6 }}><div style={{ fontSize: 12 }}><b>NVDA</b> · Buy 50 @ $115</div><div style={{ fontSize: 10, color: "var(--mute)" }}>DAY · 14:08</div></Card>
      </div>
    </div>
  );
}

Object.assign(window, {
  PortfolioTodayDesktop, PortfolioProposedDesktop,
  PortfolioTodayIpad, PortfolioProposedIpad,
  PortfolioTodayPhone, PortfolioProposedPhone,
});
