/* Mock data shared by every artboard.
   Keep this tiny — just enough realism that the designs look real.
*/
window.MOCK = {
  account: {
    equity: 124316.42,
    cash: 32840.10,
    portfolio_value: 91476.32,
    buying_power: 48250.00,
    equity_at_market_open: 122784.24,
    day_pl: 1532.18,
    day_pct: 0.01248,
  },
  clock: {
    is_open: true,
    next_close: "16:00",
  },
  positions: [
    { sym: "AAPL", qty: 50, avg: 218.42, last: 224.83, mv: 11241.50, pl: 320.50, plpc: 0.0124 },
    { sym: "NVDA", qty: 100, avg: 122.04, last: 118.41, mv: 11841.00, pl: -363.00, plpc: -0.0032 },
    { sym: "TSLA", qty: 25, avg: 374.10, last: 381.20, mv: 9530.00, pl: 177.50, plpc: 0.0218 },
  ],
  // sparkline data is a path-friendly array of normalised y values 0..1
  watchlist: [
    { sym: "AAPL", name: "Apple Inc.",        last: 224.83, day: 0.0124,  vol: "32M",  cap: "$3.4T", spark: [.55,.50,.48,.42,.44,.36,.30,.28,.22,.18,.14,.10] },
    { sym: "NVDA", name: "NVIDIA Corp.",      last: 118.41, day: -0.0032, vol: "248M", cap: "$2.9T", spark: [.20,.24,.30,.32,.38,.42,.46,.50,.54,.58,.62,.66] },
    { sym: "TSLA", name: "Tesla, Inc.",       last: 381.20, day: 0.0218,  vol: "84M",  cap: "$1.2T", spark: [.70,.62,.55,.52,.42,.40,.30,.28,.20,.14,.10,.06] },
    { sym: "MSFT", name: "Microsoft Corp.",   last: 432.18, day: 0.0042,  vol: "21M",  cap: "$3.2T", spark: [.50,.48,.46,.40,.42,.38,.36,.34,.32,.30,.28,.26] },
    { sym: "GOOGL",name: "Alphabet Inc.",     last: 178.92, day: -0.0091, vol: "18M",  cap: "$2.2T", spark: [.30,.32,.34,.40,.42,.46,.50,.54,.58,.60,.64,.68] },
    { sym: "AMZN", name: "Amazon.com",        last: 215.50, day: 0.0083,  vol: "34M",  cap: "$2.3T", spark: [.60,.55,.52,.48,.44,.40,.36,.32,.30,.26,.24,.20] },
  ],
  // 60-point P/L curve for the hero
  pnlCurve: [
    .50,.51,.49,.48,.50,.52,.51,.49,.47,.46,.45,.47,.48,.49,.52,.54,.55,.56,.54,.53,
    .52,.50,.48,.45,.43,.42,.40,.38,.40,.42,.44,.46,.45,.43,.41,.40,.42,.44,.46,.48,
    .50,.52,.54,.55,.57,.58,.60,.62,.64,.65,.66,.68,.70,.72,.74,.75,.77,.78,.80,.82,
  ],
};

window.FMT = {
  money: (n) => n.toLocaleString("en-US", { style: "currency", currency: "USD" }),
  short: (n) => n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }),
  pct: (n, signed = true) => (signed && n >= 0 ? "+" : "") + (n * 100).toFixed(2) + "%",
  signed: (n) => (n >= 0 ? "+" : "−") + Math.abs(n).toLocaleString("en-US", { style: "currency", currency: "USD" }),
};
