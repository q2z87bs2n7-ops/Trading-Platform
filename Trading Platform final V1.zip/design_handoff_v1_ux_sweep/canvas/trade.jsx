/* ─────────────────────────────────────────────────────────────────
   Trade flow — TradeBar (dock) + OrderSheet, current vs proposed
   ───────────────────────────────────────────────────────────────── */

function TradeBarCurrent() {
  return (
    <div style={{
      position: "absolute", left: 14, right: 14, bottom: 14,
      background: "var(--panel)", border: "1px solid var(--border)",
      borderRadius: "var(--r-lg)",
      padding: "10px 12px",
      display: "flex", alignItems: "center", gap: 10,
      boxShadow: "var(--shadow)",
    }}>
      <div style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "4px 9px", background: "var(--panel-2)", borderRadius: 6 }}>
        <span style={{ fontSize: 12, fontWeight: 600 }}>AAPL</span>
        <span style={{ fontSize: 10, color: "var(--mute)" }}>▾</span>
      </div>
      <span className="mono" style={{ fontSize: 13, fontWeight: 600 }}>$224.83</span>
      <Chip color="var(--pos)" bg="var(--pos-bg)" sm>+1.24%</Chip>
      <div style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
        <button style={{ fontSize: 12, padding: "6px 14px", background: "var(--pos)", color: "#fff", border: 0, borderRadius: 7, fontWeight: 600 }}>Buy</button>
        <button style={{ fontSize: 12, padding: "6px 14px", background: "var(--neg)", color: "#fff", border: 0, borderRadius: 7, fontWeight: 600 }}>Sell</button>
      </div>
    </div>
  );
}

function OrderSheetCurrent() {
  return (
    <>
      <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 4 }} />
      <div style={{
        position: "absolute", left: 0, right: 0, bottom: 0, zIndex: 5,
        background: "var(--panel)",
        borderTopLeftRadius: "var(--r-xl)", borderTopRightRadius: "var(--r-xl)",
        padding: "16px 16px 22px",
      }}>
        <div style={{ width: 40, height: 4, background: "var(--border-2)", borderRadius: 99, margin: "0 auto 12px" }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <div style={{ fontSize: 15, fontWeight: 600 }}>New order</div>
          <span style={{ color: "var(--mute)", fontSize: 18 }}>✕</span>
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          <button style={{ flex: 1, fontSize: 13, padding: 10, background: "var(--panel-2)", border: "1px solid var(--border)", borderRadius: 8, fontWeight: 600 }}>Buy AAPL</button>
          <button style={{ flex: 1, fontSize: 13, padding: 10, background: "transparent", border: "1px solid var(--border)", borderRadius: 8, color: "var(--text-2)" }}>Sell</button>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 12 }}>
          <div style={{ border: "1px solid var(--border)", borderRadius: 8, padding: "10px 12px", fontSize: 13, display: "flex", justifyContent: "space-between" }}>
            <span style={{ color: "var(--mute)" }}>Qty</span><span className="mono" style={{ fontWeight: 600 }}>10</span>
          </div>
          <div style={{ border: "1px solid var(--border)", borderRadius: 8, padding: "10px 12px", fontSize: 13, display: "flex", justifyContent: "space-between" }}>
            <span style={{ color: "var(--mute)" }}>Type</span><span style={{ fontWeight: 600 }}>Market ▾</span>
          </div>
          <div style={{ border: "1px solid var(--border)", borderRadius: 8, padding: "10px 12px", fontSize: 13, display: "flex", justifyContent: "space-between" }}>
            <span style={{ color: "var(--mute)" }}>TIF</span><span style={{ fontWeight: 600 }}>DAY ▾</span>
          </div>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "var(--text-2)", marginBottom: 12 }}>
          <span>Est. cost</span><span className="mono" style={{ fontWeight: 600 }}>$2,248.30</span>
        </div>
        <button style={{ width: "100%", fontSize: 14, padding: 12, background: "var(--pos)", color: "#fff", border: 0, borderRadius: 10, fontWeight: 600 }}>
          Review &amp; place
        </button>
      </div>
    </>
  );
}

function TradeCurrentPhone() {
  return (
    <div className="silo-stocks artboard-app" style={{ position: "relative" }}>
      <div style={{ height: 22, background: "var(--panel)" }} />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <span style={{ fontSize: 18 }}>☰</span>
        <span style={{ fontSize: 14, fontWeight: 600 }}>AAPL</span>
        <span style={{ width: 30, height: 30 }} />
      </div>
      {/* faded content underneath */}
      <div style={{ flex: 1, padding: 12, opacity: 0.5 }}>
        <Card p="12px 14px">
          <Eyebrow>Apple Inc.</Eyebrow>
          <div className="mono" style={{ fontSize: 22, fontWeight: 600, marginTop: 2 }}>$224.83</div>
          <PLChip value={2.75} pct={0.0124} sm />
        </Card>
      </div>
      <OrderSheetCurrent />
      <Annotations notes={[
        { x: 14, y: 240, n: 1, side: "right", small: true, label: "Sheet has its OWN Buy/Sell picker — re-doing the bar's decision. CTA is neutral green even though user might have tapped Sell." },
        { x: 14, y: 460, n: 2, side: "right", small: true, label: "'Review & place' is generic. Doesn't read the order back." },
      ]} />
    </div>
  );
}

/* ─── Proposed ──────────────────────────────────────── */
function TradeBarProposed({ side = "buy" }) {
  const isBuy = side === "buy";
  return (
    <div style={{
      position: "absolute", left: 14, right: 14, bottom: 14,
      background: "var(--panel)", border: "1px solid var(--border)",
      borderRadius: "var(--r-lg)",
      padding: "10px 12px",
      display: "flex", alignItems: "center", gap: 10,
      boxShadow: "var(--shadow)",
    }}>
      <div style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "4px 9px", background: "var(--panel-2)", borderRadius: 6 }}>
        <span style={{ fontSize: 12, fontWeight: 600 }}>AAPL</span>
        <span style={{ fontSize: 10, color: "var(--mute)" }}>▾</span>
      </div>
      <span className="mono" style={{ fontSize: 13, fontWeight: 600 }}>$224.83</span>
      <Chip color="var(--pos)" bg="var(--pos-bg)" sm>+1.24%</Chip>
      <div style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
        <button style={{
          fontSize: 12, padding: "6px 14px",
          background: isBuy ? "var(--pos)" : "transparent",
          color: isBuy ? "#fff" : "var(--text-2)",
          border: isBuy ? 0 : "1px solid var(--border)",
          borderRadius: 7, fontWeight: 600,
        }}>Buy</button>
        <button style={{
          fontSize: 12, padding: "6px 14px",
          background: !isBuy ? "var(--neg)" : "transparent",
          color: !isBuy ? "#fff" : "var(--text-2)",
          border: !isBuy ? 0 : "1px solid var(--border)",
          borderRadius: 7, fontWeight: 600,
        }}>Sell</button>
      </div>
    </div>
  );
}

function OrderSheetProposed({ side = "buy", crypto = false }) {
  const isBuy = side === "buy";
  const accent = isBuy ? "var(--pos)" : "var(--neg)";
  const accentBg = isBuy ? "var(--pos-bg)" : "var(--neg-bg)";
  return (
    <>
      <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 4 }} />
      <div style={{
        position: "absolute", left: 0, right: 0, bottom: 0, zIndex: 5,
        background: "var(--panel)",
        borderTopLeftRadius: "var(--r-xl)", borderTopRightRadius: "var(--r-xl)",
        padding: "16px 16px 22px",
      }}>
        <div style={{ width: 40, height: 4, background: "var(--border-2)", borderRadius: 99, margin: "0 auto 12px" }} />
        {/* header chip — same shape as the bar's symbol chip, looks continuous */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "4px 9px", background: "var(--panel-2)", borderRadius: 6 }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>AAPL</span>
          </div>
          <span className="mono" style={{ fontSize: 14, fontWeight: 600 }}>$224.83</span>
          <Chip color="var(--pos)" bg="var(--pos-bg)" sm>+1.24%</Chip>
          <span style={{ marginLeft: "auto", fontSize: 10.5, color: "var(--mute)" }}>streaming</span>
        </div>

        {/* Side picker — pre-set, doesn't re-ask */}
        <div style={{ display: "flex", border: "1px solid var(--border)", borderRadius: 8, overflow: "hidden", marginBottom: 12 }}>
          <button style={{
            flex: 1, fontSize: 13, padding: 10,
            background: isBuy ? "var(--pos)" : "transparent",
            color: isBuy ? "#fff" : "var(--text-2)",
            border: 0, fontWeight: 600,
          }}>Buy</button>
          <button style={{
            flex: 1, fontSize: 13, padding: 10,
            background: !isBuy ? "var(--neg)" : "transparent",
            color: !isBuy ? "#fff" : "var(--text-2)",
            border: 0, fontWeight: 500,
          }}>Sell</button>
        </div>

        {/* fields */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 10 }}>
          <div style={{ border: "1px solid var(--border)", borderRadius: 8, padding: "8px 10px" }}>
            <div style={{ fontSize: 10, color: "var(--mute)" }}>Qty</div>
            <div className="mono" style={{ fontSize: 14, fontWeight: 600 }}>10</div>
          </div>
          <div style={{ border: "1px solid var(--border)", borderRadius: 8, padding: "8px 10px" }}>
            <div style={{ fontSize: 10, color: "var(--mute)" }}>Type</div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>Market ▾</div>
          </div>
          <div style={{ gridColumn: "span 2", border: "1px solid var(--border)", borderRadius: 8, padding: "8px 10px" }}>
            <div style={{ fontSize: 10, color: "var(--mute)" }}>Time in force</div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{crypto ? "GTC ▾" : "DAY ▾ — cancels at 16:00"}</div>
          </div>
        </div>

        {/* est cost in coloured pill */}
        <div style={{
          background: accentBg, borderRadius: 8, padding: "10px 12px",
          display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12,
        }}>
          <span style={{ fontSize: 11, color: "var(--text-2)" }}>Est. cost · @ market</span>
          <span className="mono" style={{ fontSize: 15, fontWeight: 600, color: accent }}>$2,248.30</span>
        </div>

        <button style={{
          width: "100%", fontSize: 14, padding: 12,
          background: accent, color: "#fff", border: 0, borderRadius: 10, fontWeight: 600,
        }}>
          {isBuy ? "Buy" : "Sell"} 10 AAPL · $2,248.30
        </button>
      </div>
    </>
  );
}

function TradeProposedPhone() {
  return (
    <div className="silo-stocks artboard-app" style={{ position: "relative" }}>
      <div style={{ height: 22, background: "var(--panel)" }} />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <span style={{ fontSize: 18 }}>☰</span>
        <span style={{ fontSize: 14, fontWeight: 600 }}>AAPL</span>
        <span style={{ width: 30, height: 30 }} />
      </div>
      <div style={{ flex: 1, padding: 12, opacity: 0.5 }}>
        <Card p="12px 14px">
          <Eyebrow>Apple Inc.</Eyebrow>
          <div className="mono" style={{ fontSize: 22, fontWeight: 600, marginTop: 2 }}>$224.83</div>
          <PLChip value={2.75} pct={0.0124} sm />
        </Card>
      </div>
      <OrderSheetProposed side="buy" />
      <Annotations notes={[
        { x: 14, y: 240, n: "A", side: "right", small: true, label: "Sheet header CHIP looks identical to the dock-bar's chip — visual continuity." },
        { x: 14, y: 305, n: "B", side: "right", small: true, label: "Side decision is pre-set. Sell stays tappable; tapping flips the primary CTA to red." },
        { x: 14, y: 420, n: "C", side: "right", small: true, label: "Est. cost lives in a coloured pill matching the side. Same readout vocabulary as the dock-bar quote chip." },
        { x: 14, y: 510, n: "D", side: "right", small: true, label: "Primary CTA reads the trade back — no generic 'Review & place'." },
      ]} />
    </div>
  );
}

function TradeProposedPhoneSell() {
  return (
    <div className="silo-stocks artboard-app" style={{ position: "relative" }}>
      <div style={{ height: 22, background: "var(--panel)" }} />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <span style={{ fontSize: 18 }}>☰</span>
        <span style={{ fontSize: 14, fontWeight: 600 }}>AAPL</span>
        <span style={{ width: 30, height: 30 }} />
      </div>
      <div style={{ flex: 1, padding: 12, opacity: 0.5 }} />
      <OrderSheetProposed side="sell" />
    </div>
  );
}

function TradeProposedPhoneCrypto() {
  return (
    <div className="artboard-app" style={{ position: "relative" }}>
      <div style={{ height: 22, background: "var(--panel)" }} />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <span style={{ fontSize: 18 }}>☰</span>
        <span style={{ fontSize: 14, fontWeight: 600 }}>BTC/USD</span>
        <span style={{ width: 30, height: 30 }} />
      </div>
      <div style={{ flex: 1, padding: 12, opacity: 0.5 }} />
      <OrderSheetProposed side="buy" crypto />
    </div>
  );
}

/* Desktop trade flow — TradeBar visible on Discover, sheet centered */
function TradeProposedDesktop() {
  return (
    <div className="silo-stocks artboard-app" style={{ position: "relative" }}>
      <div style={{ padding: "12px 24px", background: "var(--panel)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><BrandMark size={24} /><span style={{ fontSize: 13, fontWeight: 600 }}>Stocks ▾</span></div>
        <ModePill active="Portfolio" />
        <span style={{ fontSize: 12, color: "var(--mute)" }} className="mono">{FMT.money(124316.42)}</span>
      </div>
      <div style={{ flex: 1, padding: 20, opacity: 0.5 }}>
        <Card><Eyebrow>Apple Inc. · AAPL</Eyebrow><div className="mono" style={{ fontSize: 26, fontWeight: 600 }}>$224.83</div></Card>
      </div>

      {/* Centered desktop sheet */}
      <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.45)", zIndex: 4 }} />
      <div style={{
        position: "absolute", left: "50%", top: "50%", transform: "translate(-50%, -50%)",
        zIndex: 5, width: 420,
        background: "var(--panel)", borderRadius: "var(--r-xl)",
        padding: "20px 22px 24px", boxShadow: "var(--shadow-lg)",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "4px 9px", background: "var(--panel-2)", borderRadius: 6 }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>AAPL</span>
          </div>
          <span className="mono" style={{ fontSize: 15, fontWeight: 600 }}>$224.83</span>
          <Chip color="var(--pos)" bg="var(--pos-bg)" sm>+1.24%</Chip>
          <span style={{ marginLeft: "auto", fontSize: 11, color: "var(--mute)" }}>streaming · ⌘⏎ to place</span>
        </div>
        <div style={{ display: "flex", border: "1px solid var(--border)", borderRadius: 8, overflow: "hidden", marginBottom: 12 }}>
          <button style={{ flex: 1, fontSize: 13, padding: 10, background: "var(--pos)", color: "#fff", border: 0, fontWeight: 600 }}>Buy</button>
          <button style={{ flex: 1, fontSize: 13, padding: 10, background: "transparent", color: "var(--text-2)", border: 0, fontWeight: 500 }}>Sell</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 10 }}>
          <div style={{ border: "1px solid var(--border)", borderRadius: 8, padding: "8px 10px" }}>
            <div style={{ fontSize: 10, color: "var(--mute)" }}>Qty</div>
            <div className="mono" style={{ fontSize: 14, fontWeight: 600 }}>10</div>
          </div>
          <div style={{ border: "1px solid var(--border)", borderRadius: 8, padding: "8px 10px" }}>
            <div style={{ fontSize: 10, color: "var(--mute)" }}>Type</div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>Market ▾</div>
          </div>
          <div style={{ gridColumn: "span 2", border: "1px solid var(--border)", borderRadius: 8, padding: "8px 10px" }}>
            <div style={{ fontSize: 10, color: "var(--mute)" }}>Time in force</div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>DAY ▾ — cancels at 16:00</div>
          </div>
        </div>
        <div style={{ background: "var(--pos-bg)", borderRadius: 8, padding: "10px 12px", display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <span style={{ fontSize: 11, color: "var(--text-2)" }}>Est. cost · @ market</span>
          <span className="mono" style={{ fontSize: 16, fontWeight: 600, color: "var(--pos)" }}>$2,248.30</span>
        </div>
        <button style={{ width: "100%", fontSize: 14, padding: 12, background: "var(--pos)", color: "#fff", border: 0, borderRadius: 10, fontWeight: 600 }}>
          Buy 10 AAPL · $2,248.30
        </button>
      </div>
    </div>
  );
}

Object.assign(window, {
  TradeCurrentPhone, TradeProposedPhone,
  TradeProposedPhoneSell, TradeProposedPhoneCrypto,
  TradeProposedDesktop,
});
