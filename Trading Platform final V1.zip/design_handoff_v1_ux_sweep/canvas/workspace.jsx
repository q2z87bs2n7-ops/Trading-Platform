/* ─────────────────────────────────────────────────────────────────
   Workspace — the channels rework.
   Today: + Add widget · Layouts · Channels-as-row-of-chips, peer-level.
   Proposed: Channels become the toolbar centrepiece. + Widget drops to a
   quiet right action. Layouts becomes named-preset.
   ───────────────────────────────────────────────────────────────── */

/* a fake widget tile */
function Tile({ title, h = 140, children, ph = 12 }) {
  return (
    <div style={{
      background: "var(--panel)", border: "1px solid var(--border)",
      borderRadius: "var(--r)", boxShadow: "var(--shadow-sm)",
      display: "flex", flexDirection: "column", minHeight: h, overflow: "hidden",
    }}>
      <div style={{ padding: "6px 10px", background: "var(--panel-2)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 8, fontSize: 11 }}>
        <span style={{ fontWeight: 600 }}>{title}</span>
        <span style={{ marginLeft: "auto", color: "var(--mute)" }}>⋯</span>
      </div>
      <div style={{ flex: 1, padding: ph, fontSize: 11, color: "var(--text-2)" }}>{children}</div>
    </div>
  );
}

function ChartTile({ sym, color = "var(--pos)", channelDot }) {
  const data = window.MOCK.watchlist.find(w => w.sym === sym)?.spark || window.MOCK.pnlCurve;
  const last = window.MOCK.watchlist.find(w => w.sym === sym)?.last || 100;
  return (
    <div style={{
      background: "var(--panel)", border: "1px solid var(--border)",
      borderRadius: "var(--r)", boxShadow: "var(--shadow-sm)",
      display: "flex", flexDirection: "column", overflow: "hidden",
    }}>
      <div style={{ padding: "6px 10px", background: "var(--panel-2)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 8, fontSize: 11 }}>
        {channelDot && <span style={{ width: 7, height: 7, borderRadius: 99, background: channelDot }} />}
        <span style={{ fontWeight: 600 }}>{sym}</span>
        <span className="mono" style={{ fontSize: 10.5, color: "var(--mute)" }}>${last.toFixed(2)}</span>
        <span style={{ marginLeft: "auto", color: "var(--mute)" }}>⋯</span>
      </div>
      <div style={{ flex: 1, padding: 8, minHeight: 100 }}>
        <Spark data={data} color={color} fill stroke={1.4} />
      </div>
    </div>
  );
}

/* ── Today ──────────────────────────────────────────────────── */
function WorkspaceTodayDesktop() {
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ padding: "10px 18px", background: "var(--panel)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><BrandMark size={24} /><span style={{ fontSize: 13, color: "var(--mute)" }} className="mono">stocks · v1.4.2</span></div>
        <ModePill active="Workspace" />
      </div>
      {/* Toolbar */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <button style={{ fontSize: 12, padding: "6px 11px", background: "var(--accent)", color: "#fff", border: 0, borderRadius: 7, fontWeight: 600 }}>+ Add widget</button>
        <button style={{ fontSize: 12, padding: "6px 11px", background: "var(--panel-2)", border: "1px solid var(--border)", color: "var(--text-2)", borderRadius: 7 }}>Layouts ▾</button>
        <span style={{ fontSize: 9.5, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--mute)", marginLeft: 14 }}>Channels</span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "4px 9px", background: "var(--panel-2)", borderRadius: 6, fontSize: 11.5 }}>
          <span style={{ width: 8, height: 8, borderRadius: 99, background: "var(--text)" }} /><b>main</b><span>AAPL</span><span style={{ color: "var(--mute)" }}>·2</span>
        </span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "4px 9px", background: "var(--panel-2)", borderRadius: 6, fontSize: 11.5 }}>
          <span style={{ width: 8, height: 8, borderRadius: 99, background: "#4b8df8" }} /><b>blue</b><span>NVDA</span><span style={{ color: "var(--mute)" }}>·1</span>
        </span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "4px 9px", background: "var(--panel-2)", borderRadius: 6, fontSize: 11.5 }}>
          <span style={{ width: 8, height: 8, borderRadius: 99, background: "var(--pos)" }} /><b>green</b><span style={{ color: "var(--mute)" }}>·0</span>
        </span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "4px 9px", background: "var(--panel-2)", borderRadius: 6, fontSize: 11.5 }}>
          <span style={{ width: 8, height: 8, borderRadius: 99, background: "var(--warn)" }} /><b>amber</b><span style={{ color: "var(--mute)" }}>·0</span>
        </span>
        <span style={{ marginLeft: "auto", fontSize: 14, color: "var(--text-2)" }}>⛶</span>
      </div>
      {/* Canvas */}
      <div style={{ flex: 1, padding: 14, display: "grid", gridTemplateColumns: "2fr 1fr 1fr", gridTemplateRows: "1fr 1fr", gap: 10 }}>
        <ChartTile sym="AAPL" color="var(--pos)" />
        <Tile title="Order book · AAPL">
          {[["Bid", 224.81, 1200],["Bid", 224.80, 800],["Ask", 224.84, 600],["Ask", 224.85, 1800]].map((r,i)=>(<div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "2px 0", fontSize: 10.5 }}><span className={r[0]==="Bid"?"pos":"neg"}>{r[0]}</span><span className="mono">${r[1]}</span><span className="mono" style={{ color: "var(--mute)" }}>{r[2]}</span></div>))}
        </Tile>
        <Tile title="News · AAPL">
          <div style={{ fontSize: 10.5, lineHeight: 1.5 }}>Reuters · 14:08 — Apple supplier reports record Q3 orders…</div>
        </Tile>
        <ChartTile sym="NVDA" color="var(--neg)" />
        <Tile title="Fundamentals · NVDA">
          {[["P/E","58.4"],["EPS","$2.04"],["Mkt Cap","$2.9T"],["52w High","$153"]].map(r=>(<div key={r[0]} style={{ display: "flex", justifyContent: "space-between", padding: "2px 0", fontSize: 10.5 }}><span style={{ color: "var(--mute)" }}>{r[0]}</span><span className="mono">{r[1]}</span></div>))}
        </Tile>
        <Tile title="Positions">
          {window.MOCK.positions.map(p=>(<div key={p.sym} style={{ display: "flex", justifyContent: "space-between", padding: "2px 0", fontSize: 10.5 }}><span><b>{p.sym}</b> · {p.qty}</span><span className={p.pl>=0?"mono pos":"mono neg"}>{p.pl>=0?"+":""}{p.pl.toFixed(0)}</span></div>))}
        </Tile>
      </div>
      <Annotations notes={[
        { x: 30, y: 80, n: 1, side: "right", label: "'+ Add widget' is a primary accent CTA. Layouts is a secondary. Channels live RIGHT NEXT to them as equal peers." },
        { x: 350, y: 80, n: 2, side: "right", label: "'Channels' is a thin uppercase eyebrow that doesn't read as primary. Channel chips look like settings tags." },
        { x: 650, y: 80, n: 3, side: "left", label: "Empty channels (green ·0, amber ·0) just look broken — no affordance to bind a symbol." },
      ]} />
    </div>
  );
}

/* ── Today empty state ──────────────────────────────────────── */
function WorkspaceEmptyToday() {
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ padding: "10px 18px", background: "var(--panel)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><BrandMark size={24} /><span style={{ fontSize: 13, color: "var(--mute)" }} className="mono">stocks · v1.4.2</span></div>
        <ModePill active="Workspace" />
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <button style={{ fontSize: 12, padding: "6px 11px", background: "var(--accent)", color: "#fff", border: 0, borderRadius: 7, fontWeight: 600 }}>+ Add widget</button>
        <button style={{ fontSize: 12, padding: "6px 11px", background: "var(--panel-2)", border: "1px solid var(--border)", color: "var(--text-2)", borderRadius: 7 }}>Layouts ▾</button>
      </div>
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ textAlign: "center", maxWidth: 360 }}>
          <div style={{ fontSize: 13, color: "var(--mute)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Empty workspace</div>
          <div style={{ fontSize: 22, fontWeight: 600, marginTop: 8, letterSpacing: "-0.015em" }}>Build your first canvas.</div>
          <div style={{ display: "flex", justifyContent: "center", gap: 10, marginTop: 18 }}>
            <button style={{ fontSize: 12, padding: "9px 16px", background: "var(--accent)", color: "#fff", border: 0, borderRadius: 8, fontWeight: 600 }}>+ Add widget</button>
            <button style={{ fontSize: 12, padding: "9px 16px", background: "transparent", border: "1px solid var(--border)", borderRadius: 8 }}>Browse layouts</button>
          </div>
        </div>
      </div>
      <Annotations notes={[
        { x: 24, y: 280, n: 1, side: "right", label: "The single most impressive Workspace feature — letting AI build a layout for you — isn't here. It's hidden behind ⌘K." },
      ]} />
    </div>
  );
}

/* ── Proposed toolbar ───────────────────────────────────────── */
function WorkspaceProposedDesktop() {
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", columnGap: 24, alignItems: "center", padding: "10px 18px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <button style={{ display: "inline-flex", alignItems: "center", gap: 10, background: "transparent", border: 0, padding: 0 }}>
          <BrandMark size={24} />
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15, alignItems: "flex-start" }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>Stocks ▾</span>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 10.5, color: "var(--mute)" }}><span style={{ width: 5, height: 5, borderRadius: 99, background: "var(--pos)" }} />Open · until 16:00</span>
          </div>
        </button>
        <div style={{ justifySelf: "center" }}><ModePill active="Workspace" /></div>
        <span className="mono pos" style={{ fontSize: 12, fontWeight: 600 }}>+1.24%</span>
      </div>
      {/* New toolbar: layouts | channels | + widget */}
      <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", columnGap: 18, alignItems: "center", padding: "10px 18px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        {/* LEFT: named layout */}
        <div style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
          <button style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12, padding: "6px 11px", background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 7, fontWeight: 500 }}>
            <span>▦</span><b>Trader</b><span style={{ color: "var(--mute)", fontSize: 10 }}>▾</span>
          </button>
          <button style={{ fontSize: 11, padding: "5px 8px", background: "transparent", border: 0, color: "var(--mute)" }}>save as…</button>
        </div>
        {/* CENTRE: channels, primary */}
        <div style={{ justifySelf: "center", display: "inline-flex", alignItems: "center", gap: 10, padding: "5px 14px", background: "var(--bg)", border: "1px solid var(--border)", borderRadius: 10 }}>
          <span style={{ fontSize: 9.5, fontWeight: 600, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--mute)", paddingRight: 8, borderRight: "1px solid var(--hairline)" }}>CHANNELS</span>
          <button style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 10px", background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 7, fontSize: 12, fontWeight: 500, boxShadow: "var(--shadow-sm)" }}>
            <span style={{ width: 8, height: 8, borderRadius: 99, background: "var(--text)" }} />
            <b>AAPL</b>
            <span style={{ color: "var(--mute)", fontSize: 9.5 }}>main · 2 widgets</span>
          </button>
          <button style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 10px", background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 7, fontSize: 12, fontWeight: 500, boxShadow: "var(--shadow-sm)" }}>
            <span style={{ width: 8, height: 8, borderRadius: 99, background: "#4b8df8" }} />
            <b>NVDA</b>
            <span style={{ color: "var(--mute)", fontSize: 9.5 }}>blue · 1</span>
          </button>
          <button style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 10px", background: "transparent", border: "1px dashed var(--border)", borderRadius: 7, fontSize: 12, color: "var(--mute)" }}>
            <span style={{ width: 8, height: 8, borderRadius: 99, background: "var(--pos)", opacity: 0.4 }} />+ green
          </button>
          <button style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 10px", background: "transparent", border: "1px dashed var(--border)", borderRadius: 7, fontSize: 12, color: "var(--mute)" }}>
            <span style={{ width: 8, height: 8, borderRadius: 99, background: "var(--warn)", opacity: 0.4 }} />+ amber
          </button>
        </div>
        {/* RIGHT: quiet + widget */}
        <div style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
          <button style={{ fontSize: 12, padding: "5px 11px", background: "transparent", border: 0, color: "var(--text-2)" }}>+ Widget</button>
          <span style={{ fontSize: 14, color: "var(--mute)" }}>⛶</span>
        </div>
      </div>
      {/* Canvas — same content, but channels colour the tile headers */}
      <div style={{ flex: 1, padding: 14, display: "grid", gridTemplateColumns: "2fr 1fr 1fr", gridTemplateRows: "1fr 1fr", gap: 10 }}>
        <ChartTile sym="AAPL" color="var(--pos)" channelDot="var(--text)" />
        <Tile title="● Order book · AAPL">
          {[["Bid", 224.81, 1200],["Bid", 224.80, 800],["Ask", 224.84, 600],["Ask", 224.85, 1800]].map((r,i)=>(<div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "2px 0", fontSize: 10.5 }}><span className={r[0]==="Bid"?"pos":"neg"}>{r[0]}</span><span className="mono">${r[1]}</span><span className="mono" style={{ color: "var(--mute)" }}>{r[2]}</span></div>))}
        </Tile>
        <Tile title="News · AAPL">
          <div style={{ fontSize: 10.5, lineHeight: 1.5 }}>Reuters · 14:08 — Apple supplier reports record Q3 orders…</div>
        </Tile>
        <ChartTile sym="NVDA" color="var(--neg)" channelDot="#4b8df8" />
        <Tile title="Fundamentals · NVDA">
          {[["P/E","58.4"],["EPS","$2.04"],["Mkt Cap","$2.9T"]].map(r=>(<div key={r[0]} style={{ display: "flex", justifyContent: "space-between", padding: "2px 0", fontSize: 10.5 }}><span style={{ color: "var(--mute)" }}>{r[0]}</span><span className="mono">{r[1]}</span></div>))}
        </Tile>
        <Tile title="Positions">
          {window.MOCK.positions.map(p=>(<div key={p.sym} style={{ display: "flex", justifyContent: "space-between", padding: "2px 0", fontSize: 10.5 }}><span><b>{p.sym}</b> · {p.qty}</span><span className={p.pl>=0?"mono pos":"mono neg"}>{p.pl>=0?"+":""}{p.pl.toFixed(0)}</span></div>))}
        </Tile>
      </div>
      <Annotations notes={[
        { x: 24, y: 116, n: "A", side: "right", label: "Layouts becomes a NAMED preset — 'Trader ▾' — instead of a generic 'Layouts ▾'. Tells user what they currently have loaded." },
        { x: 370, y: 116, n: "B", side: "right", label: "Channels become the toolbar's CENTREPIECE — boxed, eyebrow-labelled, centred. Active channels show widget count; empty channels are dashed-outline '+ green / + amber' affordances." },
        { x: 950, y: 116, n: "C", side: "left", label: "'+ Widget' demoted to a quiet right-side action. It's how you build a workspace once, not what you do every day." },
        { x: 24, y: 220, n: "D", side: "right", label: "Channel dot bleeds into tile headers — visual feedback that a tile belongs to a channel." },
      ]} />
    </div>
  );
}

/* ── Proposed empty state ───────────────────────────────────── */
function WorkspaceEmptyProposed() {
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ padding: "10px 18px", background: "var(--panel)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><BrandMark size={24} /><span style={{ fontSize: 13, fontWeight: 600 }}>Stocks ▾</span></div>
        <ModePill active="Workspace" />
      </div>
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ textAlign: "center", maxWidth: 520, padding: "0 24px" }}>
          <div style={{ fontSize: 11, color: "var(--mute)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Empty workspace</div>
          <div style={{ fontSize: 24, fontWeight: 600, marginTop: 10, letterSpacing: "-0.02em" }}>Build your first canvas.</div>
          <div style={{ fontSize: 13, color: "var(--text-2)", marginTop: 8 }}>Three ways to get going.</div>
          <div style={{ display: "flex", justifyContent: "center", gap: 10, marginTop: 22, flexWrap: "wrap" }}>
            <button style={{ display: "inline-flex", alignItems: "center", gap: 8, fontSize: 12, padding: "10px 16px", background: "var(--accent)", color: "#fff", border: 0, borderRadius: 8, fontWeight: 600 }}>+ Add widget</button>
            <button style={{ display: "inline-flex", alignItems: "center", gap: 8, fontSize: 12, padding: "10px 16px", background: "transparent", border: "1px solid var(--border)", borderRadius: 8 }}>▦ Browse layouts</button>
            <button style={{ display: "inline-flex", alignItems: "center", gap: 8, fontSize: 12, padding: "10px 16px", background: "transparent", border: "1px solid var(--cb-accent)", color: "var(--cb-accent)", borderRadius: 8, fontWeight: 600 }}>
              <span>✦</span>Ask AI to build one
            </button>
          </div>
          <div style={{ marginTop: 18, fontSize: 11.5, color: "var(--mute)", fontStyle: "italic", lineHeight: 1.55 }}>
            e.g. <em>"watch the 7 largest semis with charts, fundamentals and news"</em>
          </div>
        </div>
      </div>
      <Annotations notes={[
        { x: 200, y: 260, n: "A", side: "right", label: "Third option (AI builds the layout) is the moment a reviewer says oh. Violet outline = credit-spending AI surface." },
        { x: 200, y: 380, n: "B", side: "right", label: "Inline example shows exactly what to type. Discoverability problem solved." },
      ]} />
    </div>
  );
}

Object.assign(window, {
  WorkspaceTodayDesktop, WorkspaceEmptyToday,
  WorkspaceProposedDesktop, WorkspaceEmptyProposed,
});
