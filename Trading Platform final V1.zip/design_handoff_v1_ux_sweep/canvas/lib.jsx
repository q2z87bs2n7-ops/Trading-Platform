/* Shared primitives. All exported to window so the surface files can use them. */

const { useState } = React;

function BrandMark({ size = 28 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: 8,
      background: "linear-gradient(135deg, var(--accent), var(--accent-2))",
      color: "#fff", display: "grid", placeItems: "center",
      fontWeight: 700, fontSize: size * 0.5,
    }}>◆</div>
  );
}

/** Pulled directly from sparkPath in the app — normalised 0..1 path, area fill optional */
function Spark({ data, color = "var(--pos)", w = 200, h = 60, fill = false, stroke = 1.5 }) {
  const n = data.length;
  const dx = w / (n - 1);
  const pts = data.map((y, i) => [i * dx, h - y * h]);
  const d = pts.map((p, i) => (i === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`)).join(" ");
  const area = fill ? `${d} L${w},${h} L0,${h} Z` : null;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{ width: "100%", height: "100%", display: "block" }}>
      {fill && <path d={area} fill={color} opacity="0.13" />}
      <path d={d} stroke={color} strokeWidth={stroke} fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Chip({ children, color = "var(--mute)", bg = "var(--panel-2)", sm = false }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      padding: sm ? "1px 6px" : "2px 8px",
      borderRadius: 5,
      fontSize: sm ? 10 : 11,
      fontWeight: 600,
      color, background: bg,
      fontVariantNumeric: "tabular-nums",
    }}>{children}</span>
  );
}

function PLChip({ value, pct, sm = false }) {
  const up = value >= 0;
  const color = up ? "var(--pos)" : "var(--neg)";
  const bg = up ? "var(--pos-bg)" : "var(--neg-bg)";
  return (
    <Chip color={color} bg={bg} sm={sm}>
      {up ? "+" : "−"}${Math.abs(value).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
      {pct != null && <span>({(up ? "+" : "") + (pct * 100).toFixed(2)}%)</span>}
    </Chip>
  );
}

/** SectionHeading clone from the app */
function SectionHeading({ label, ctx, ctxRight, size = "md" }) {
  const fs = size === "lg" ? 18 : size === "sm" ? 12 : 14;
  return (
    <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 10 }}>
      <div style={{ fontSize: fs, fontWeight: 600, letterSpacing: "-0.01em" }}>{label}</div>
      {ctx && <div style={{ fontSize: 11, color: "var(--mute)" }}>{ctx}</div>}
      <div style={{ marginLeft: "auto" }}>{ctxRight}</div>
    </div>
  );
}

function Card({ children, p = "14px 16px", style }) {
  return (
    <div style={{
      background: "var(--panel)",
      border: "1px solid var(--border)",
      borderRadius: "var(--r)",
      padding: p,
      boxShadow: "var(--shadow-sm)",
      ...style,
    }}>{children}</div>
  );
}

function Eyebrow({ children, style }) {
  return <div style={{
    fontSize: 10.5, fontWeight: 600, letterSpacing: "0.08em",
    textTransform: "uppercase", color: "var(--mute)", ...style,
  }}>{children}</div>;
}

function ModePill({ active }) {
  const modes = ["Discover", "Portfolio", "Chart", "Workspace"];
  return (
    <div style={{
      display: "inline-flex", gap: 2, padding: 3,
      background: "var(--panel-2)", border: "1px solid var(--border)",
      borderRadius: 10,
    }}>
      {modes.map(m => (
        <span key={m} style={{
          fontSize: 12, padding: "5px 12px",
          background: m === active ? "var(--panel)" : "transparent",
          color: m === active ? "var(--text)" : "var(--text-2)",
          fontWeight: m === active ? 600 : 500,
          borderRadius: 7,
          boxShadow: m === active ? "var(--shadow-sm)" : "none",
        }}>{m}</span>
      ))}
    </div>
  );
}

function IconBtn({ children, ghost = false, style }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "5px 9px",
      border: ghost ? "0" : "1px solid var(--border)",
      background: ghost ? "transparent" : "var(--panel)",
      borderRadius: 8,
      fontSize: 12,
      color: "var(--text-2)",
      ...style,
    }}>{children}</span>
  );
}

/** Tiny donut for allocation. parts: [{label,value,color}] */
function Donut({ parts, size = 72, thickness = 14 }) {
  const total = parts.reduce((s, p) => s + p.value, 0);
  const r = size / 2 - thickness / 2;
  const c = 2 * Math.PI * r;
  let off = 0;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} style={{ width: size, height: size, display: "block" }}>
      <g transform={`rotate(-90 ${size / 2} ${size / 2})`}>
        {parts.map((p, i) => {
          const frac = p.value / total;
          const len = frac * c;
          const el = <circle key={i} cx={size / 2} cy={size / 2} r={r}
            fill="none" stroke={p.color} strokeWidth={thickness}
            strokeDasharray={`${len} ${c - len}`}
            strokeDashoffset={-off}
          />;
          off += len;
          return el;
        })}
      </g>
    </svg>
  );
}

Object.assign(window, { BrandMark, Spark, Chip, PLChip, SectionHeading, Card, Eyebrow, ModePill, IconBtn, Donut });
