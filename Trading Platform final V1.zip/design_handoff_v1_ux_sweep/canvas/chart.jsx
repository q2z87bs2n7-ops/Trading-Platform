/* ─────────────────────────────────────────────────────────────────
   Chart + ChartBot — TradingView native chrome (kept) + our chrome
   around it. Today: panel stub reads as floating debris. Proposed:
   a vertical rail and a co-designed expanded panel header.
   ───────────────────────────────────────────────────────────────── */

/* TradingView-ish pane mock — dark grid + abstracted candles */
function TVPane({ children }) {
  return (
    <div style={{ flex: 1, background: "#161a22", position: "relative", overflow: "hidden", color: "#e9e9e6", fontFamily: "var(--font-mono)", fontSize: 11 }}>
      {/* TV native header */}
      <div style={{
        display: "flex", alignItems: "center", gap: 14, padding: "8px 12px",
        background: "#1d212b", borderBottom: "1px solid #2a2f3a",
      }}>
        <span style={{ fontWeight: 700, color: "#fff", fontSize: 12 }}>AAPL · NASDAQ</span>
        <span style={{ color: "#9aa2b1" }}>5m</span>
        <span style={{ color: "#9aa2b1" }}>Indicators</span>
        <span style={{ color: "#9aa2b1" }}>Compare</span>
        <span style={{ marginLeft: "auto", color: "#9aa2b1" }}>O224.10 H225.40 L223.80 C224.83</span>
      </div>
      <div style={{ display: "flex", flex: 1, minHeight: 0, height: "calc(100% - 36px)" }}>
        {/* drawing rail (TV) */}
        <div style={{ width: 32, background: "#1d212b", borderRight: "1px solid #2a2f3a", display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 8, gap: 8, color: "#9aa2b1" }}>
          <span>✦</span><span>＋</span><span>◊</span><span>↔</span><span>✎</span><span>⨯</span>
        </div>
        {/* main pane */}
        <div style={{ flex: 1, position: "relative" }}>
          <ChartCanvas />
        </div>
        {/* y-axis */}
        <div style={{ width: 50, background: "#1d212b", borderLeft: "1px solid #2a2f3a", padding: "10px 6px", color: "#9aa2b1", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
          <span>226</span><span>225</span><span>224</span><span>223</span><span>222</span>
        </div>
        {/* children = right rail / panel */}
        {children}
      </div>
    </div>
  );
}

function ChartCanvas() {
  // simple candle pattern
  const candles = Array.from({ length: 36 }, (_, i) => {
    const o = 50 + Math.sin(i * 0.35) * 18 + (i * 0.6);
    const c = o + (Math.sin(i * 0.7) * 10);
    const h = Math.max(o, c) + 4 + Math.random() * 3;
    const l = Math.min(o, c) - 4 - Math.random() * 3;
    return { o, c, h, l };
  });
  const w = 100 / candles.length;
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ width: "100%", height: "100%", display: "block" }}>
      {/* grid */}
      {[20, 40, 60, 80].map(y => <line key={y} x1="0" x2="100" y1={y} y2={y} stroke="#2a2f3a" strokeWidth="0.2" />)}
      {[20, 40, 60, 80].map(x => <line key={x} y1="0" y2="100" x1={x} x2={x} stroke="#2a2f3a" strokeWidth="0.2" />)}
      {candles.map((k, i) => {
        const x = i * w + w / 2;
        const up = k.c >= k.o;
        const color = up ? "#22c779" : "#e94d56";
        return (
          <g key={i}>
            <line x1={x} x2={x} y1={k.h} y2={k.l} stroke={color} strokeWidth="0.3" />
            <rect x={x - w*0.35} y={Math.min(k.o, k.c)} width={w*0.7} height={Math.abs(k.c - k.o) || 0.4} fill={color} />
          </g>
        );
      })}
    </svg>
  );
}

function TradeBarChart() {
  return (
    <div style={{
      position: "absolute", left: 12, right: 12, bottom: 12, zIndex: 3,
      background: "var(--panel)", border: "1px solid var(--border)",
      borderRadius: "var(--r-lg)", padding: "8px 10px",
      display: "flex", alignItems: "center", gap: 10,
      boxShadow: "var(--shadow)",
    }}>
      <div style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "3px 8px", background: "var(--panel-2)", borderRadius: 6 }}>
        <span style={{ fontSize: 12, fontWeight: 600 }}>AAPL</span>
        <span style={{ fontSize: 10, color: "var(--mute)" }}>▾</span>
      </div>
      <span className="mono" style={{ fontSize: 13, fontWeight: 600 }}>$224.83</span>
      <Chip color="var(--pos)" bg="var(--pos-bg)" sm>+1.24%</Chip>
      <div style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
        <button style={{ fontSize: 11.5, padding: "5px 12px", background: "var(--pos)", color: "#fff", border: 0, borderRadius: 6, fontWeight: 600 }}>Buy</button>
        <button style={{ fontSize: 11.5, padding: "5px 12px", background: "var(--neg)", color: "#fff", border: 0, borderRadius: 6, fontWeight: 600 }}>Sell</button>
      </div>
    </div>
  );
}

/* ── Today — chart with ChatPanel collapsed to a circle stub ───── */
function ChartTodayDesktop() {
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ padding: "10px 18px", background: "var(--panel)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><BrandMark size={24} /><span style={{ fontSize: 13, color: "var(--mute)" }} className="mono">stocks · v1.4.2</span></div>
        <ModePill active="Chart" />
      </div>
      <TVPane>
        {/* collapsed stub */}
        <button style={{
          position: "absolute", top: 12, right: 12, zIndex: 4,
          width: 38, height: 38, borderRadius: "50%",
          background: "var(--cb-accent)", color: "#fff",
          border: "2px solid #fff", fontSize: 15, fontWeight: 600,
          boxShadow: "0 4px 14px rgba(0,0,0,0.35)",
        }}>✦</button>
      </TVPane>
      <TradeBarChart />
      <Annotations notes={[
        { x: 24, y: 60, n: 1, side: "right", label: "TV's drawing rail + header + y-axis (the dark chrome) — keep, all of it." },
        { x: 990, y: 65, n: 2, side: "left", label: "Collapsed ChartBot stub. Reads as a floating chat-widget drop, not part of the UI. Lives on top of TV's pane like debris." },
        { x: 24, y: 480, n: 3, side: "right", label: "TradeBar floats with shadow + radius designed for light backgrounds — shadow disappears against TV's grid." },
      ]} />
    </div>
  );
}

/* ── Today — expanded ChatPanel ─────────────────────────────────── */
function ChartTodayDesktopExpanded() {
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ padding: "10px 18px", background: "var(--panel)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><BrandMark size={24} /><span style={{ fontSize: 13, color: "var(--mute)" }} className="mono">stocks · v1.4.2</span></div>
        <ModePill active="Chart" />
      </div>
      <TVPane>
        <div style={{ width: 360, background: "var(--panel)", borderLeft: "1px solid var(--border)", display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", alignItems: "center", padding: "10px 12px", borderBottom: "1px solid var(--border)" }}>
            <span style={{ color: "var(--cb-accent)", fontSize: 14, marginRight: 8 }}>✦</span>
            <span style={{ fontSize: 13, fontWeight: 600 }}>ChartBot</span>
            <span style={{ marginLeft: "auto", display: "flex", gap: 12, fontSize: 11.5, color: "var(--mute)" }}>
              <span>clear</span><span>×</span>
            </span>
          </div>
          {/* prompt suggestions as wall-of-text */}
          <div style={{ flex: 1, padding: 14 }}>
            <div style={{ fontSize: 12, color: "var(--text-2)", lineHeight: 1.6, paddingBottom: 10, borderBottom: "1px solid var(--hairline)" }}>Draw a support line at yesterday's low</div>
            <div style={{ fontSize: 12, color: "var(--text-2)", lineHeight: 1.6, padding: "10px 0", borderBottom: "1px solid var(--hairline)" }}>Add the 50-day moving average and an RSI</div>
            <div style={{ fontSize: 12, color: "var(--text-2)", lineHeight: 1.6, padding: "10px 0", borderBottom: "1px solid var(--hairline)" }}>Mark the last earnings beat / miss on the chart</div>
            <div style={{ fontSize: 12, color: "var(--text-2)", lineHeight: 1.6, paddingTop: 10 }}>Summarise this chart for me</div>
          </div>
          <div style={{ borderTop: "1px solid var(--border)", padding: 10, background: "var(--bg)" }}>
            <div style={{ background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 8, padding: "8px 10px", fontSize: 12, color: "var(--mute)" }}>Ask ChartBot…</div>
          </div>
        </div>
      </TVPane>
      <TradeBarChart />
      <Annotations notes={[
        { x: 730, y: 60, n: 1, side: "right", label: "Header is generic 'ChartBot · clear · ×'. Doesn't show the bot KNOWS what symbol you're looking at." },
        { x: 730, y: 200, n: 2, side: "right", label: "Empty-state prompts are wall-of-text. No visual shape, no leading verb, traders skim past." },
      ]} />
    </div>
  );
}

/* ── Proposed — collapsed vertical rail ─────────────────────────── */
function ChartProposedDesktopRail() {
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", columnGap: 24, alignItems: "center", padding: "10px 18px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <button style={{ display: "inline-flex", alignItems: "center", gap: 10, background: "transparent", border: 0, padding: 0, cursor: "pointer" }}>
          <BrandMark size={24} />
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15, alignItems: "flex-start" }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>Stocks ▾</span>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 10.5, color: "var(--mute)" }}>
              <span style={{ width: 5, height: 5, borderRadius: 99, background: "var(--pos)" }} />Open · until 16:00
            </span>
          </div>
        </button>
        <div style={{ justifySelf: "center" }}><ModePill active="Chart" /></div>
        <span className="mono pos" style={{ fontSize: 12, fontWeight: 600 }}>+1.24% today</span>
      </div>
      <TVPane>
        {/* vertical rail */}
        <div style={{
          width: 36, background: "oklch(60% 0.17 290 / 0.18)",
          borderLeft: "1px solid oklch(60% 0.17 290 / 0.4)",
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "space-between",
          padding: "14px 0", cursor: "pointer",
        }}>
          <span style={{ color: "var(--cb-accent)", fontSize: 17 }}>✦</span>
          <div style={{
            transform: "rotate(-90deg)", whiteSpace: "nowrap",
            fontFamily: "var(--font-mono)", fontSize: 10,
            letterSpacing: "0.18em", color: "#fff", opacity: 0.7,
          }}>CHARTBOT</div>
          <span style={{ color: "var(--cb-accent)", fontSize: 13, opacity: 0.5 }}>‹</span>
        </div>
      </TVPane>
      <TradeBarChart />
      <Annotations notes={[
        { x: 740, y: 65, n: "A", side: "left", label: "Collapsed ChartBot becomes a full-height vertical rail in low-opacity violet. ✦ at top, rotated 'CHARTBOT' label, expand-chevron at bottom." },
        { x: 740, y: 220, n: "B", side: "left", label: "Reads as a PERMANENT feature of the UI, not a floating button. The right edge of the app now has a clean joint with TV's chrome." },
      ]} />
    </div>
  );
}

/* ── Proposed — expanded with chip empty state ──────────────────── */
function ChartProposedDesktopExpanded() {
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", columnGap: 24, alignItems: "center", padding: "10px 18px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <button style={{ display: "inline-flex", alignItems: "center", gap: 10, background: "transparent", border: 0, padding: 0 }}>
          <BrandMark size={24} />
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15, alignItems: "flex-start" }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>Stocks ▾</span>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 10.5, color: "var(--mute)" }}><span style={{ width: 5, height: 5, borderRadius: 99, background: "var(--pos)" }} />Open · until 16:00</span>
          </div>
        </button>
        <div style={{ justifySelf: "center" }}><ModePill active="Chart" /></div>
        <span className="mono pos" style={{ fontSize: 12, fontWeight: 600 }}>+1.24%</span>
      </div>
      <TVPane>
        <div style={{ width: 360, background: "var(--panel)", borderLeft: "1px solid var(--border)", display: "flex", flexDirection: "column" }}>
          {/* Header — names the active chart context */}
          <div style={{ padding: "10px 14px", borderBottom: "1px solid var(--border)", background: "var(--bg)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ color: "var(--cb-accent)", fontSize: 14 }}>✦</span>
              <span style={{ fontSize: 13, fontWeight: 600 }}>ChartBot</span>
              <span style={{ marginLeft: "auto", display: "flex", gap: 12, fontSize: 11, color: "var(--mute)" }}>
                <span>⋯</span><span>›</span>
              </span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6 }}>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "2px 7px", background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 5, fontSize: 11, fontWeight: 600 }}>AAPL</span>
              <span style={{ fontSize: 10.5, color: "var(--mute)" }}>5m · NASDAQ · streaming</span>
            </div>
          </div>
          {/* Chip empty state */}
          <div style={{ flex: 1, padding: 14 }}>
            <div style={{ fontSize: 11, color: "var(--mute)", marginBottom: 10 }}>Ask anything about this chart, or try:</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {[
                ["Draw", "support at yesterday's low"],
                ["Add", "50-MA + RSI"],
                ["Mark", "earnings beats"],
                ["Summarise", "this chart"],
                ["Find", "similar setups in watchlist"],
              ].map(([v, body]) => (
                <button key={v} style={{
                  fontSize: 11, padding: "5px 9px",
                  background: "var(--cb-accent-soft)", color: "var(--cb-accent)",
                  border: 0, borderRadius: 99, cursor: "pointer",
                  display: "inline-flex", gap: 4, alignItems: "center",
                }}>
                  <b>{v}</b><span>{body}</span>
                </button>
              ))}
            </div>
          </div>
          <div style={{ borderTop: "1px solid var(--border)", padding: 12, background: "var(--bg)" }}>
            <div style={{ background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 8, padding: "8px 12px", fontSize: 12, color: "var(--mute)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span>Ask ChartBot…</span>
              <span style={{ fontSize: 9.5, color: "var(--mute)", fontStyle: "italic" }}>Violet — cloud AI · ~3–5 s</span>
            </div>
          </div>
        </div>
      </TVPane>
      <TradeBarChart />
      <Annotations notes={[
        { x: 730, y: 70, n: "A", side: "right", label: "Header now CARRIES the active chart context: AAPL chip + 5m · NASDAQ · streaming. The bot visibly KNOWS what you're looking at." },
        { x: 730, y: 200, n: "B", side: "right", label: "Empty-state prompts are chips with a leading verb. Reads in 0.5 s. Tappable, not skim-able-past." },
        { x: 730, y: 460, n: "C", side: "right", label: "Footer hint names the convention: 'Violet = cloud AI · 3–5 s'. One-shot dismissible first-load tooltip." },
      ]} />
    </div>
  );
}

/* ── iPad: most users won't run Chart mode on iPad — note that ── */
function ChartProposedIpad() {
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ padding: "10px 16px", background: "var(--panel)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 10 }}>
        <BrandMark size={24} /><span style={{ fontSize: 13, fontWeight: 600 }}>Stocks ▾</span>
        <span style={{ marginLeft: "auto" }}><ModePill active="Chart" /></span>
      </div>
      <TVPane>
        {/* iPad → narrower panel, 28% width */}
        <div style={{ width: 220, background: "var(--panel)", borderLeft: "1px solid var(--border)", display: "flex", flexDirection: "column" }}>
          <div style={{ padding: "8px 12px", borderBottom: "1px solid var(--border)", background: "var(--bg)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "var(--cb-accent)", fontSize: 13 }}>✦</span>
              <span style={{ fontSize: 12, fontWeight: 600 }}>ChartBot</span>
              <span style={{ marginLeft: "auto", fontSize: 11, color: "var(--mute)" }}>›</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 4 }}>
              <span style={{ display: "inline-flex", padding: "1px 6px", background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 4, fontSize: 10, fontWeight: 600 }}>AAPL</span>
              <span style={{ fontSize: 9.5, color: "var(--mute)" }}>5m · streaming</span>
            </div>
          </div>
          <div style={{ flex: 1, padding: 10 }}>
            <div style={{ fontSize: 10, color: "var(--mute)", marginBottom: 8 }}>Try:</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
              {[["Draw","support"],["Add","50-MA"],["Mark","earnings"],["Summarise","this"]].map(([v,b]) => (
                <button key={v} style={{ fontSize: 10, padding: "3px 7px", background: "var(--cb-accent-soft)", color: "var(--cb-accent)", border: 0, borderRadius: 99 }}><b>{v}</b> {b}</button>
              ))}
            </div>
          </div>
        </div>
      </TVPane>
      <TradeBarChart />
      <Annotations notes={[
        { x: 360, y: 60, n: "A", side: "left", small: true, label: "Panel narrows to 28% of viewport on iPad (vs fixed 380 px today). Same content, scaled." },
      ]} />
    </div>
  );
}

Object.assign(window, {
  ChartTodayDesktop, ChartTodayDesktopExpanded,
  ChartProposedDesktopRail, ChartProposedDesktopExpanded,
  ChartProposedIpad,
});
