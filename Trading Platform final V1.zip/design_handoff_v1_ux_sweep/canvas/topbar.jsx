/* ─────────────────────────────────────────────────────────────────
   TopBar surface — current state recreated and proposed redesign,
   at iPhone 12 (390 wide), iPad (834 wide portrait), and Desktop (1280).

   Today: TWO header rows
     row 1: BrandMark · v1.4.2 · stocks/crypto pill · Modes · Ask · ☾ · ⚙
     row 2: Polling chip · OPEN/CLOSED · Equity ▾ · Day P/L · BP

   Proposed: ONE header row, three zones
     left: Brand-button (silo + status inline) | centre: Modes | right: Equity / Day-% / actions
   ───────────────────────────────────────────────────────────────── */

function TopBarTodayDesktop() {
  const a = window.MOCK.account;
  return (
    <div className="silo-stocks artboard-app">
      {/* ── Row 1 ────────────────────────────────────────── */}
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        gap: 12, padding: "12px 24px",
        background: "var(--panel)", borderBottom: "1px solid var(--border)",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <BrandMark />
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15 }}>
            <span style={{ fontSize: 15, fontWeight: 600, letterSpacing: "-0.005em" }}>Trading Platform</span>
            <span style={{ fontSize: 11, color: "var(--mute)", fontFamily: "var(--font-mono)" }}>v1.4.2 · paper</span>
          </div>
          {/* asset-class toggle */}
          <div style={{ marginLeft: 8, display: "inline-flex", padding: 2, background: "var(--panel-2)", border: "1px solid var(--border)", borderRadius: 10 }}>
            <span style={{ fontSize: 11, padding: "4px 10px", background: "var(--accent)", color: "#fff", borderRadius: 8, fontWeight: 600 }}>stocks</span>
            <span style={{ fontSize: 11, padding: "4px 10px", color: "var(--text-2)", fontWeight: 600 }}>crypto</span>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <ModePill active="Discover" />
          <IconBtn style={{ borderColor: "var(--accent)", color: "var(--accent)" }}>
            <span style={{ color: "var(--accent)" }}>✦</span>
            <span style={{ fontWeight: 500 }}>Ask anything</span>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, padding: "1px 5px", border: "1px solid var(--border)", borderRadius: 4, color: "var(--mute)" }}>⌘K</span>
          </IconBtn>
          <IconBtn style={{ width: 30, height: 30, justifyContent: "center" }}>☾</IconBtn>
          <IconBtn style={{ width: 30, height: 30, justifyContent: "center" }}>⚙</IconBtn>
        </div>
      </div>

      {/* ── Row 2: status strip ────────────────────────── */}
      <div style={{
        display: "flex", alignItems: "center", gap: 24,
        padding: "10px 24px", fontSize: 13,
        background: "var(--panel)", borderBottom: "1px solid var(--border)",
      }}>
        <Chip color="var(--warn)" bg="var(--warn-bg)">
          <span style={{ width: 6, height: 6, borderRadius: 99, background: "var(--warn)" }} />
          Polling · stream off
        </Chip>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ width: 8, height: 8, borderRadius: 99, background: "var(--pos)" }} />
          <span style={{ fontWeight: 700, color: "var(--pos)" }}>OPEN</span>
          <span style={{ color: "var(--mute)" }} className="mono">until 16:00</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          <span style={{ color: "var(--mute)" }}>Equity</span>
          <span className="mono" style={{ fontWeight: 600 }}>{FMT.money(a.equity)}</span>
          <span style={{ color: "var(--mute)", fontSize: 11 }}>▾</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ color: "var(--mute)" }}>Day P/L</span>
          <span className="mono pos" style={{ fontWeight: 600 }}>+{FMT.money(a.day_pl)}</span>
          <span className="mono pos">(+1.24%)</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          <span style={{ color: "var(--mute)" }}>BP</span>
          <span className="mono" style={{ fontWeight: 600 }}>{FMT.money(a.buying_power)}</span>
        </div>
      </div>

      {/* canvas body — just a calm placeholder */}
      <div style={{ flex: 1, padding: 24, color: "var(--mute)", fontSize: 12 }}>
        — Discover content begins here —
      </div>

      {/* annotation overlay */}
      <Annotations notes={[
        { x: 32, y: 12, n: 1, side: "right", label: "Brand mark looks decorative, but it IS the hub-open button" },
        { x: 270, y: 12, n: 2, side: "right", label: "Asset-class toggle is the 3rd silo-switcher in 270 px" },
        { x: 920, y: 12, n: 3, side: "left", label: "Ask pill, theme, settings all the same priority weight" },
        { x: 32, y: 84, n: 4, side: "right", label: "Polling chip stays here even at idle — minor visual debt" },
        { x: 590, y: 84, n: 5, side: "left", label: "Equity (the most-watched number) reads 4th, on the SECOND row" },
        { x: 1080, y: 84, n: 6, side: "left", label: "BP isn't session status — it belongs in the Portfolio hero" },
      ]} />
    </div>
  );
}

function TopBarProposedDesktop() {
  const a = window.MOCK.account;
  return (
    <div className="silo-stocks artboard-app">
      <div style={{
        display: "grid", gridTemplateColumns: "auto 1fr auto",
        alignItems: "center", columnGap: 24, padding: "14px 24px",
        background: "var(--panel)", borderBottom: "1px solid var(--border)",
      }}>
        {/* LEFT — silo identity, status inline */}
        <button style={{
          display: "inline-flex", alignItems: "center", gap: 12,
          background: "transparent", border: 0, padding: "4px 8px",
          borderRadius: 10, cursor: "pointer",
        }}>
          <BrandMark />
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15, alignItems: "flex-start" }}>
            <span style={{ fontSize: 14, fontWeight: 600, letterSpacing: "-0.005em" }}>
              Stocks <span style={{ fontSize: 10, color: "var(--mute)", marginLeft: 4 }}>▾</span>
            </span>
            <span style={{ fontSize: 10.5, color: "var(--mute)", fontFamily: "var(--font-mono)" }}>paper · 1.4.2</span>
          </div>
          <span style={{
            marginLeft: 14, display: "inline-flex", alignItems: "center", gap: 6,
            paddingLeft: 14, borderLeft: "1px solid var(--hairline)",
          }}>
            <span style={{ width: 7, height: 7, borderRadius: 99, background: "var(--pos)" }} />
            <span style={{ fontSize: 11, color: "var(--text-2)" }}>Open</span>
            <span style={{ fontSize: 11, color: "var(--mute)" }} className="mono">until 16:00</span>
          </span>
        </button>

        {/* CENTRE — mode */}
        <div style={{ justifySelf: "center" }}>
          <ModePill active="Discover" />
        </div>

        {/* RIGHT — account + actions */}
        <div style={{ display: "inline-flex", alignItems: "center", gap: 14 }}>
          <div style={{
            display: "flex", flexDirection: "column", alignItems: "flex-end",
            lineHeight: 1.15, paddingRight: 14, borderRight: "1px solid var(--hairline)",
          }}>
            <span className="mono" style={{ fontSize: 14, fontWeight: 600 }}>{FMT.money(a.equity)}</span>
            <span className="mono pos" style={{ fontSize: 11.5, fontWeight: 600 }}>+$1,532.18 · +1.24% today</span>
          </div>
          <IconBtn style={{ borderColor: "var(--accent)", color: "var(--accent)" }}>
            <span style={{ color: "var(--accent)" }}>✦</span>
            <span style={{ fontWeight: 500 }}>Ask anything</span>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, padding: "1px 5px", border: "1px solid var(--border)", borderRadius: 4, color: "var(--mute)" }}>⌘K</span>
          </IconBtn>
          <IconBtn ghost style={{ width: 30, height: 30, justifyContent: "center" }}>☾</IconBtn>
          <IconBtn ghost style={{ width: 30, height: 30, justifyContent: "center" }}>⚙</IconBtn>
        </div>
      </div>

      <div style={{ flex: 1, padding: 24, color: "var(--mute)", fontSize: 12 }}>
        — Discover content begins here —
      </div>

      <Annotations notes={[
        { x: 32, y: 14, n: "A", side: "right", label: "Brand button = silo name + version. ONE tap-target. ▾ confirms it's tappable." },
        { x: 380, y: 14, n: "B", side: "right", label: "Session status inline with identity (Open / Until 16:00). No second row." },
        { x: 590, y: 14, n: "C", side: "left", label: "Mode pill centred — primacy by position, not chrome weight." },
        { x: 940, y: 14, n: "D", side: "left", label: "Equity + Day P/L as the right anchor. Reads FIRST when scanning right." },
      ]} />
    </div>
  );
}

/* ── iPad versions (834 portrait) ──────────────────────── */
function TopBarTodayIpad() {
  const a = window.MOCK.account;
  return (
    <div className="silo-stocks artboard-app">
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        gap: 10, padding: "12px 18px",
        background: "var(--panel)", borderBottom: "1px solid var(--border)",
        flexWrap: "wrap",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <BrandMark />
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15 }}>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Trading Platform</span>
            <span style={{ fontSize: 10, color: "var(--mute)", fontFamily: "var(--font-mono)" }}>v1.4.2</span>
          </div>
          <div style={{ display: "inline-flex", padding: 2, background: "var(--panel-2)", border: "1px solid var(--border)", borderRadius: 10 }}>
            <span style={{ fontSize: 11, padding: "4px 10px", background: "var(--accent)", color: "#fff", borderRadius: 8, fontWeight: 600 }}>stocks</span>
            <span style={{ fontSize: 11, padding: "4px 10px", color: "var(--text-2)", fontWeight: 600 }}>crypto</span>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <ModePill active="Discover" />
          <IconBtn style={{ borderColor: "var(--accent)", color: "var(--accent)" }}>
            <span style={{ color: "var(--accent)" }}>✦</span>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, padding: "1px 5px", border: "1px solid var(--border)", borderRadius: 4, color: "var(--mute)" }}>⌘K</span>
          </IconBtn>
          <IconBtn style={{ width: 30, height: 30, justifyContent: "center" }}>⚙</IconBtn>
        </div>
      </div>
      <div style={{
        display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap",
        padding: "10px 18px", fontSize: 12,
        background: "var(--panel)", borderBottom: "1px solid var(--border)",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ width: 7, height: 7, borderRadius: 99, background: "var(--pos)" }} />
          <span style={{ fontWeight: 700, color: "var(--pos)" }}>OPEN</span>
          <span style={{ color: "var(--mute)" }} className="mono">until 16:00</span>
        </div>
        <div><span style={{ color: "var(--mute)" }}>Equity </span><span className="mono" style={{ fontWeight: 600 }}>{FMT.money(a.equity)}</span></div>
        <div><span style={{ color: "var(--mute)" }}>Day P/L </span><span className="mono pos" style={{ fontWeight: 600 }}>+$1,532.18 (+1.24%)</span></div>
        <div><span style={{ color: "var(--mute)" }}>BP </span><span className="mono" style={{ fontWeight: 600 }}>{FMT.money(a.buying_power)}</span></div>
      </div>
      <div style={{ flex: 1, padding: 20, color: "var(--mute)", fontSize: 11 }}>— Discover —</div>
    </div>
  );
}

function TopBarProposedIpad() {
  const a = window.MOCK.account;
  return (
    <div className="silo-stocks artboard-app">
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        gap: 10, padding: "12px 18px",
        background: "var(--panel)", borderBottom: "1px solid var(--border)",
      }}>
        <button style={{
          display: "inline-flex", alignItems: "center", gap: 10,
          background: "transparent", border: 0, padding: 0, cursor: "pointer",
        }}>
          <BrandMark />
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15, alignItems: "flex-start" }}>
            <span style={{ fontSize: 13.5, fontWeight: 600 }}>Stocks <span style={{ fontSize: 10, color: "var(--mute)" }}>▾</span></span>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 10.5, color: "var(--mute)" }}>
              <span style={{ width: 5, height: 5, borderRadius: 99, background: "var(--pos)" }} />
              Open · until 16:00
            </span>
          </div>
        </button>
        <ModePill active="Discover" />
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", lineHeight: 1.15 }}>
            <span className="mono" style={{ fontSize: 13, fontWeight: 600 }}>{FMT.money(a.equity)}</span>
            <span className="mono pos" style={{ fontSize: 10.5, fontWeight: 600 }}>+1.24%</span>
          </div>
          <IconBtn style={{ borderColor: "var(--accent)", color: "var(--accent)" }}>
            <span style={{ color: "var(--accent)" }}>✦</span>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, padding: "1px 5px", border: "1px solid var(--border)", borderRadius: 4, color: "var(--mute)" }}>⌘K</span>
          </IconBtn>
          <IconBtn ghost style={{ width: 30, height: 30, justifyContent: "center" }}>⚙</IconBtn>
        </div>
      </div>
      <div style={{ flex: 1, padding: 20, color: "var(--mute)", fontSize: 11 }}>— Discover —</div>
    </div>
  );
}

/* ── iPhone 12 versions ───────────────────────────────── */
function TopBarTodayPhone() {
  const a = window.MOCK.account;
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ height: 22, background: "var(--panel)" }} />
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "10px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)",
      }}>
        <span style={{ fontSize: 18 }}>☰</span>
        <span style={{ fontSize: 14, fontWeight: 600 }}>Discover</span>
        <div style={{ display: "flex", gap: 8 }}>
          <IconBtn style={{ borderColor: "var(--accent)", color: "var(--accent)", width: 30, height: 30, justifyContent: "center" }}>✦</IconBtn>
          <IconBtn style={{ width: 30, height: 30, justifyContent: "center" }}>⚙</IconBtn>
        </div>
      </div>
      {/* status strip */}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        padding: "8px 14px", fontSize: 12,
        background: "var(--panel)", borderBottom: "1px solid var(--border)",
      }}>
        <span style={{ width: 7, height: 7, borderRadius: 99, background: "var(--warn)" }} />
        <span style={{ width: 7, height: 7, borderRadius: 99, background: "var(--pos)" }} />
        <span style={{ fontWeight: 700, color: "var(--pos)", fontSize: 11 }}>OPEN</span>
        <span style={{ color: "var(--mute)", fontSize: 10.5 }}>16:00</span>
        <button style={{
          marginLeft: "auto", display: "inline-flex", alignItems: "center", gap: 5,
          background: "transparent", border: 0, padding: 0, cursor: "pointer",
        }}>
          <span className="mono" style={{ fontWeight: 600, fontSize: 13 }}>$124,316</span>
          <Chip color="var(--pos)" bg="var(--pos-bg)" sm>+1.24%</Chip>
          <span style={{ color: "var(--mute)", fontSize: 10 }}>▾</span>
        </button>
      </div>
      <div style={{ flex: 1, padding: 16, color: "var(--mute)", fontSize: 11 }}>— Discover —</div>
      <Annotations notes={[
        { x: 14, y: 56, n: 1, side: "right", small: true, label: "Two horizontal strips before any content — eats ~28 pt." },
      ]} />
    </div>
  );
}

function TopBarProposedPhone() {
  const a = window.MOCK.account;
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ height: 22, background: "var(--panel)" }} />
      <div style={{
        display: "grid", gridTemplateColumns: "auto 1fr auto",
        alignItems: "center", columnGap: 10,
        padding: "10px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)",
      }}>
        <span style={{ fontSize: 18 }}>☰</span>
        <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Discover</span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 10.5, color: "var(--mute)" }}>
            <span style={{ width: 5, height: 5, borderRadius: 99, background: "var(--pos)" }} />
            Open · until 16:00
          </span>
        </div>
        <button style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          padding: "5px 9px", background: "var(--panel)", border: "1px solid var(--border)",
          borderRadius: 8, cursor: "pointer",
        }}>
          <span className="mono" style={{ fontWeight: 600, fontSize: 13 }}>$124,316</span>
          <Chip color="var(--pos)" bg="var(--pos-bg)" sm>+1.24%</Chip>
        </button>
      </div>
      <div style={{ flex: 1, padding: 16, color: "var(--mute)", fontSize: 11 }}>— Discover —</div>
      <Annotations notes={[
        { x: 14, y: 30, n: "A", side: "right", small: true, label: "One strip. Page name + session status combined. ✦ Ask moves to a small floating launcher (next surface). Polling indicator: only visible when polling, in the silo dot." },
      ]} />
    </div>
  );
}

/* ─── Annotation system ─────────────────────────────────
   Numbered red dot + a tethered label. Toggle on/off via state in the canvas.
   `notes`: [{x,y,n,side:'left'|'right',label,small}]
   Positions are pixel coords inside the artboard.
   ──────────────────────────────────────────────────────── */
function Annotations({ notes }) {
  const [show, setShow] = useState(true);
  return (
    <>
      <button
        onClick={() => setShow(s => !s)}
        style={{
          position: "absolute", bottom: 10, right: 10, zIndex: 30,
          background: "var(--panel)", border: "1px solid var(--border)",
          borderRadius: 99, padding: "4px 10px",
          fontSize: 11, color: "var(--mute)", cursor: "pointer",
        }}>
        {show ? "Hide notes" : "Show notes"}
      </button>
      {show && notes.map((n, i) => (
        <div key={i} style={{
          position: "absolute", left: n.x, top: n.y, zIndex: 20,
          display: "flex", alignItems: "center", gap: 8,
          flexDirection: n.side === "left" ? "row-reverse" : "row",
          pointerEvents: "none",
        }}>
          <span style={{
            width: 18, height: 18, borderRadius: 99, background: "var(--neg)",
            color: "#fff", fontSize: 10, fontWeight: 700,
            display: "grid", placeItems: "center",
            boxShadow: "0 0 0 3px rgba(255,255,255,0.7)",
            fontFamily: "var(--font-mono)",
          }}>{n.n}</span>
          <span style={{
            background: "#161a22", color: "#fff", padding: "5px 9px",
            borderRadius: 6, fontSize: n.small ? 10.5 : 11.5, fontWeight: 500,
            maxWidth: 280, lineHeight: 1.35,
          }}>{n.label}</span>
        </div>
      ))}
    </>
  );
}

Object.assign(window, {
  TopBarTodayDesktop, TopBarProposedDesktop,
  TopBarTodayIpad, TopBarProposedIpad,
  TopBarTodayPhone, TopBarProposedPhone,
  Annotations,
});
