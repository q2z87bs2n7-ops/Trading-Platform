/* Top-level canvas — all surfaces. */

const { DesignCanvas, DCSection, DCArtboard } = window;

function App() {
  return (
    <DesignCanvas
      title="Trading Platform · V1 UX sweep"
      subtitle="Current state vs proposed redesign · iPhone 12 · iPad · Desktop · using Calm v2 tokens"
    >
      <DCSection id="splash" title="Splash & Hub"
        subtitle="First screen every reviewer sees. Today's cards read as a Stripe-style 'pick your plan' landing. Proposed: calm summary cards, whole-card affordance, dismiss after first session and earn back via the brand-button hub.">
        <DCArtboard id="splash-d-now"  label="Desktop · Today"      width={1280} height={600}><SplashTodayDesktop /></DCArtboard>
        <DCArtboard id="splash-d-new"  label="Desktop · Proposed"   width={1280} height={600}><SplashProposedDesktop /></DCArtboard>
        <DCArtboard id="splash-i-now"  label="iPad · Today"         width={834}  height={760}><SplashTodayIpad /></DCArtboard>
        <DCArtboard id="splash-i-new"  label="iPad · Proposed"      width={834}  height={760}><SplashProposedIpad /></DCArtboard>
        <DCArtboard id="splash-p-now"  label="iPhone 12 · Today"    width={390}  height={720}><SplashTodayPhone /></DCArtboard>
        <DCArtboard id="splash-p-new"  label="iPhone 12 · Proposed" width={390}  height={720}><SplashProposedPhone /></DCArtboard>
      </DCSection>

      <DCSection id="shell" title="App shell — TopBar"
        subtitle="Two header rows collapse into one, three zones (Identity · Mode · Account & actions). Drops from 11 chrome surfaces to 7.">
        <DCArtboard id="shell-d-now"  label="Desktop · Today"      width={1280} height={560}><TopBarTodayDesktop /></DCArtboard>
        <DCArtboard id="shell-d-new"  label="Desktop · Proposed"   width={1280} height={560}><TopBarProposedDesktop /></DCArtboard>
        <DCArtboard id="shell-i-now"  label="iPad · Today"         width={834}  height={520}><TopBarTodayIpad /></DCArtboard>
        <DCArtboard id="shell-i-new"  label="iPad · Proposed"      width={834}  height={520}><TopBarProposedIpad /></DCArtboard>
        <DCArtboard id="shell-p-now"  label="iPhone 12 · Today"    width={390}  height={500}><TopBarTodayPhone /></DCArtboard>
        <DCArtboard id="shell-p-new"  label="iPhone 12 · Proposed" width={390}  height={500}><TopBarProposedPhone /></DCArtboard>
      </DCSection>

      <DCSection id="discover" title="Discover"
        subtitle="iPad is best-looking — desktop should follow that lead. Hero promoted, allocation donut out of the side rail, spark cards earn their density, MarketSummary keeps a violet identity.">
        <DCArtboard id="disc-d-now" label="Desktop · Today"      width={1280} height={780}><DiscoverTodayDesktop /></DCArtboard>
        <DCArtboard id="disc-d-new" label="Desktop · Proposed"   width={1280} height={780}><DiscoverProposedDesktop /></DCArtboard>
        <DCArtboard id="disc-i-now" label="iPad · Today"         width={834}  height={1024}><DiscoverTodayIpad /></DCArtboard>
        <DCArtboard id="disc-i-new" label="iPad · Proposed"      width={834}  height={1024}><DiscoverProposedIpad /></DCArtboard>
        <DCArtboard id="disc-p-now" label="iPhone 12 · Today"    width={390}  height={780}><DiscoverTodayPhone /></DCArtboard>
        <DCArtboard id="disc-p-new" label="iPhone 12 · Proposed" width={390}  height={780}><DiscoverProposedPhone /></DCArtboard>
      </DCSection>

      <DCSection id="portfolio" title="Portfolio"
        subtitle="Hero · Positions · Orders · Activity. Today: 4 equal sections — no hierarchy. Proposed: hero promoted with PnL curve + window switcher + cash/BP/total-PL inline; Positions as the primary block; Orders + Activity drop to a secondary 2-col row.">
        <DCArtboard id="port-d-now" label="Desktop · Today"      width={1280} height={900}><PortfolioTodayDesktop /></DCArtboard>
        <DCArtboard id="port-d-new" label="Desktop · Proposed"   width={1280} height={900}><PortfolioProposedDesktop /></DCArtboard>
        <DCArtboard id="port-i-now" label="iPad · Today"         width={834}  height={1024}><PortfolioTodayIpad /></DCArtboard>
        <DCArtboard id="port-i-new" label="iPad · Proposed"      width={834}  height={1024}><PortfolioProposedIpad /></DCArtboard>
        <DCArtboard id="port-p-now" label="iPhone 12 · Today"    width={390}  height={820}><PortfolioTodayPhone /></DCArtboard>
        <DCArtboard id="port-p-new" label="iPhone 12 · Proposed" width={390}  height={820}><PortfolioProposedPhone /></DCArtboard>
      </DCSection>

      <DCSection id="trade" title="TradeBar → OrderSheet"
        subtitle="Today the dock-bar and the sheet look like two unrelated tools. Proposed: continuous chip, sticky side decision, est-cost as a coloured pill, CTA reads the trade back. Crypto path surfaces the constraint inline.">
        <DCArtboard id="trade-p-now"        label="iPhone 12 · Today (sheet from Buy)" width={390} height={780}><TradeCurrentPhone /></DCArtboard>
        <DCArtboard id="trade-p-new-buy"    label="iPhone 12 · Proposed (Buy path)"     width={390} height={780}><TradeProposedPhone /></DCArtboard>
        <DCArtboard id="trade-p-new-sell"   label="iPhone 12 · Proposed (Sell path)"    width={390} height={780}><TradeProposedPhoneSell /></DCArtboard>
        <DCArtboard id="trade-p-new-crypto" label="iPhone 12 · Proposed (Crypto path)"  width={390} height={780}><TradeProposedPhoneCrypto /></DCArtboard>
        <DCArtboard id="trade-d-new"        label="Desktop · Proposed"                  width={1280} height={760}><TradeProposedDesktop /></DCArtboard>
      </DCSection>

      <DCSection id="chart" title="Chart & ChartBot"
        subtitle="TV's chrome stays — our chrome around it changes. Collapsed panel becomes a full-height violet rail; expanded panel header CARRIES the active symbol; empty-state prompts become tappable verb-chips.">
        <DCArtboard id="chart-d-now-collapsed" label="Desktop · Today (collapsed stub)"  width={1280} height={780}><ChartTodayDesktop /></DCArtboard>
        <DCArtboard id="chart-d-now-expanded"  label="Desktop · Today (expanded)"        width={1280} height={780}><ChartTodayDesktopExpanded /></DCArtboard>
        <DCArtboard id="chart-d-new-rail"      label="Desktop · Proposed (rail)"         width={1280} height={780}><ChartProposedDesktopRail /></DCArtboard>
        <DCArtboard id="chart-d-new-expanded"  label="Desktop · Proposed (expanded)"     width={1280} height={780}><ChartProposedDesktopExpanded /></DCArtboard>
        <DCArtboard id="chart-i-new"           label="iPad · Proposed"                    width={1024} height={768}><ChartProposedIpad /></DCArtboard>
      </DCSection>

      <DCSection id="workspace" title="Workspace"
        subtitle="Channels are the killer idea — promote them visually. Toolbar today stacks Add / Layouts / Channels as peers. Proposed: channels become the centrepiece, '+ Widget' drops to a quiet right action, Layouts becomes a NAMED preset.">
        <DCArtboard id="ws-d-now"        label="Desktop · Today (toolbar + canvas)"   width={1280} height={780}><WorkspaceTodayDesktop /></DCArtboard>
        <DCArtboard id="ws-d-new"        label="Desktop · Proposed (toolbar + canvas)" width={1280} height={780}><WorkspaceProposedDesktop /></DCArtboard>
        <DCArtboard id="ws-empty-now"    label="Desktop · Today (empty state)"        width={1280} height={600}><WorkspaceEmptyToday /></DCArtboard>
        <DCArtboard id="ws-empty-new"    label="Desktop · Proposed (empty state)"     width={1280} height={600}><WorkspaceEmptyProposed /></DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
