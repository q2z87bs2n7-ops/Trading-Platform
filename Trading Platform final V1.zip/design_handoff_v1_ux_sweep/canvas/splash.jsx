/* ─────────────────────────────────────────────────────────────────
   Splash + Hub surface. The first thing every reviewer sees.
   Today: two huge cards w/ accent rings, inner CTAs, equity hero in each.
   Proposed: quiet summary cards, whole-card affordance, dismiss-after-first-load.
   ───────────────────────────────────────────────────────────────── */

/* ── Desktop ───────────────────────────────────────────────── */
function SplashTodayDesktop() {
  return (
    <div className="artboard-app">
      <div style={{ flex: 1, display: "flex", flexDirection: "column", padding: "32px 48px", gap: 18 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <BrandMark />
          <div>
            <div style={{ fontSize: 16, fontWeight: 600 }}>Trading Platform</div>
            <div style={{ fontSize: 11, color: "var(--mute)", fontFamily: "var(--font-mono)" }}>paper · v1.4.2</div>
          </div>
        </div>
        <div style={{ fontSize: 24, fontWeight: 600, letterSpacing: "-0.02em", marginTop: 8 }}>Where would you like to trade?</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, flex: 1, minHeight: 0 }}>
          {/* Stocks card — loud */}
          <div style={{
            background: "var(--panel)",
            border: "1.5px solid var(--pos)",
            boxShadow: "0 0 0 3px oklch(48% 0.11 155 / 0.13), var(--shadow-sm)",
            borderRadius: "var(--r-lg)", padding: 32,
            display: "flex", flexDirection: "column", gap: 12,
          }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: "var(--pos)", letterSpacing: "0.04em", textTransform: "uppercase" }}>Stocks</div>
            <div className="mono" style={{ fontSize: 42, fontWeight: 600, color: "var(--pos)", letterSpacing: "-0.02em" }}>$124,316.42</div>
            <div style={{ fontSize: 13, color: "var(--text-2)" }}>3 positions · Day P/L <b className="pos">+$1,532.18 (+1.24%)</b></div>
            <div style={{ marginTop: "auto", alignSelf: "flex-start" }}>
              <button style={{ background: "var(--pos)", color: "#fff", border: 0, padding: "10px 18px", borderRadius: 8, fontSize: 13, fontWeight: 600 }}>Enter Stocks →</button>
            </div>
          </div>
          {/* Crypto card — loud */}
          <div style={{
            background: "var(--panel)",
            border: "1.5px solid var(--accent)",
            boxShadow: "0 0 0 3px oklch(46% 0.07 200 / 0.13), var(--shadow-sm)",
            borderRadius: "var(--r-lg)", padding: 32,
            display: "flex", flexDirection: "column", gap: 12,
          }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: "var(--accent)", letterSpacing: "0.04em", textTransform: "uppercase" }}>Crypto</div>
            <div className="mono" style={{ fontSize: 42, fontWeight: 600, color: "var(--accent)", letterSpacing: "-0.02em" }}>$8,402.10</div>
            <div style={{ fontSize: 13, color: "var(--text-2)" }}>2 positions · 24/7 markets</div>
            <div style={{ marginTop: "auto", alignSelf: "flex-start" }}>
              <button style={{ background: "var(--accent)", color: "#fff", border: 0, padding: "10px 18px", borderRadius: 8, fontSize: 13, fontWeight: 600 }}>Enter Crypto →</button>
            </div>
          </div>
        </div>
      </div>
      <Annotations notes={[
        { x: 48, y: 110, n: 1, side: "right", label: "Stripe-style 'pick your plan' visual weight: 1.5 px coloured border + 3 px coloured ring." },
        { x: 48, y: 240, n: 2, side: "right", label: "Equity hero is in the card title — but the card IS the equity preview. Number on number." },
        { x: 48, y: 420, n: 3, side: "right", label: "Inner CTA repeats the affordance — the whole card is already tappable." },
      ]} />
    </div>
  );
}

function SplashProposedDesktop() {
  return (
    <div className="artboard-app">
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 48, gap: 32 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <BrandMark />
          <div style={{ fontSize: 11.5, color: "var(--mute)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Paper trading</div>
        </div>
        <div style={{ fontSize: 26, fontWeight: 600, letterSpacing: "-0.02em", textAlign: "center", maxWidth: "30ch", lineHeight: 1.3 }}>
          Pick a market to step into.
        </div>
        <div style={{ display: "flex", gap: 18 }}>
          {/* Stocks summary */}
          <button style={{
            display: "flex", flexDirection: "column", alignItems: "flex-start",
            gap: 8, padding: "18px 22px", minWidth: 280,
            background: "var(--panel)", border: "1px solid var(--border)",
            borderRadius: "var(--r)", boxShadow: "var(--shadow-sm)",
            textAlign: "left", cursor: "pointer",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ width: 7, height: 7, borderRadius: 99, background: "var(--pos)" }} />
              <span style={{ fontSize: 14, fontWeight: 600 }}>Stocks</span>
              <span style={{ fontSize: 10.5, color: "var(--mute)", marginLeft: 6 }}>3 positions</span>
            </div>
            <div className="mono" style={{ fontSize: 24, fontWeight: 600, letterSpacing: "-0.02em" }}>$124,316.42</div>
            <div style={{ fontSize: 11.5, color: "var(--mute)" }}>Day <span className="pos" style={{ fontWeight: 600 }}>+1.24%</span> · Open until 16:00</div>
          </button>
          {/* Crypto */}
          <button style={{
            display: "flex", flexDirection: "column", alignItems: "flex-start",
            gap: 8, padding: "18px 22px", minWidth: 280,
            background: "var(--panel)", border: "1px solid var(--border)",
            borderRadius: "var(--r)", boxShadow: "var(--shadow-sm)",
            textAlign: "left", cursor: "pointer",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ width: 7, height: 7, borderRadius: 99, background: "var(--accent)" }} />
              <span style={{ fontSize: 14, fontWeight: 600 }}>Crypto</span>
              <span style={{ fontSize: 10.5, color: "var(--mute)", marginLeft: 6 }}>2 positions</span>
            </div>
            <div className="mono" style={{ fontSize: 24, fontWeight: 600, letterSpacing: "-0.02em" }}>$8,402.10</div>
            <div style={{ fontSize: 11.5, color: "var(--mute)" }}>Day <span className="neg" style={{ fontWeight: 600 }}>−0.84%</span> · 24/7</div>
          </button>
        </div>
        <div style={{ fontSize: 11.5, color: "var(--mute)", marginTop: 8, textAlign: "center" }}>
          Switch any time from the brand mark · <span className="mono">⌘K</span> to ask anything
        </div>
      </div>
      <Annotations notes={[
        { x: 240, y: 220, n: "A", side: "right", label: "Calm summary cards. Whole card = affordance. No accent rings, no inner CTAs." },
        { x: 240, y: 300, n: "B", side: "right", label: "Equity is content, not a billboard. Reads as 'here's where you left things' not 'sign up here'." },
        { x: 200, y: 410, n: "C", side: "right", label: "Footnote tells the user how to come back — proposed brand-button hub-open ▾." },
      ]} />
    </div>
  );
}

/* ── iPad ─────────────────────────────────────────────────── */
function SplashTodayIpad() {
  return (
    <div className="artboard-app">
      <div style={{ flex: 1, display: "flex", flexDirection: "column", padding: 24, gap: 14 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><BrandMark size={24} /><span style={{ fontSize: 13, fontWeight: 600 }}>Trading Platform</span></div>
        <div style={{ fontSize: 18, fontWeight: 600 }}>Where would you like to trade?</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 14, flex: 1 }}>
          {[
            { label: "Stocks", color: "var(--pos)", value: "$124,316.42", sub: "3 positions · Day +1.24%" },
            { label: "Crypto", color: "var(--accent)", value: "$8,402.10", sub: "2 positions · 24/7" },
          ].map((c) => (
            <div key={c.label} style={{
              flex: 1, background: "var(--panel)",
              border: `1.5px solid ${c.color}`,
              boxShadow: `0 0 0 3px ${c.color === "var(--pos)" ? "oklch(48% 0.11 155 / 0.13)" : "oklch(46% 0.07 200 / 0.13)"}`,
              borderRadius: "var(--r-lg)", padding: 22,
              display: "flex", flexDirection: "column", gap: 10,
            }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: c.color, letterSpacing: "0.04em", textTransform: "uppercase" }}>{c.label}</div>
              <div className="mono" style={{ fontSize: 32, fontWeight: 600, color: c.color, letterSpacing: "-0.02em" }}>{c.value}</div>
              <div style={{ fontSize: 12, color: "var(--text-2)" }}>{c.sub}</div>
              <div style={{ marginTop: "auto", alignSelf: "flex-start" }}>
                <button style={{ background: c.color, color: "#fff", border: 0, padding: "8px 14px", borderRadius: 8, fontSize: 12, fontWeight: 600 }}>Enter {c.label} →</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function SplashProposedIpad() {
  return (
    <div className="artboard-app">
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 24, gap: 26 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}><BrandMark /><span style={{ fontSize: 11, color: "var(--mute)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Paper trading</span></div>
        <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em", textAlign: "center" }}>Pick a market to step into.</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12, width: "100%", maxWidth: 460 }}>
          <button style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 6, padding: "16px 18px", background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 10, boxShadow: "var(--shadow-sm)", textAlign: "left", cursor: "pointer" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}><span style={{ width: 7, height: 7, borderRadius: 99, background: "var(--pos)" }} /><span style={{ fontSize: 14, fontWeight: 600 }}>Stocks</span><span style={{ fontSize: 10.5, color: "var(--mute)", marginLeft: 4 }}>3 positions</span></div>
            <div className="mono" style={{ fontSize: 22, fontWeight: 600 }}>$124,316.42</div>
            <div style={{ fontSize: 11, color: "var(--mute)" }}>Day <span className="pos" style={{ fontWeight: 600 }}>+1.24%</span> · Open until 16:00</div>
          </button>
          <button style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 6, padding: "16px 18px", background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 10, boxShadow: "var(--shadow-sm)", textAlign: "left", cursor: "pointer" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}><span style={{ width: 7, height: 7, borderRadius: 99, background: "var(--accent)" }} /><span style={{ fontSize: 14, fontWeight: 600 }}>Crypto</span><span style={{ fontSize: 10.5, color: "var(--mute)", marginLeft: 4 }}>2 positions</span></div>
            <div className="mono" style={{ fontSize: 22, fontWeight: 600 }}>$8,402.10</div>
            <div style={{ fontSize: 11, color: "var(--mute)" }}>Day <span className="neg" style={{ fontWeight: 600 }}>−0.84%</span> · 24/7</div>
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── iPhone 12 ────────────────────────────────────────────── */
function SplashTodayPhone() {
  return (
    <div className="artboard-app">
      <div style={{ height: 22, background: "var(--bg)" }} />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", padding: 16, gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><BrandMark size={22} /><span style={{ fontSize: 12.5, fontWeight: 600 }}>Trading Platform</span></div>
        <div style={{ fontSize: 16, fontWeight: 600 }}>Where would you like to trade?</div>
        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 12 }}>
          {[
            { label: "Stocks", color: "var(--pos)", value: "$124,316.42", sub: "Day +1.24% · 3 positions" },
            { label: "Crypto", color: "var(--accent)", value: "$8,402.10", sub: "24/7 · 2 positions" },
          ].map(c => (
            <div key={c.label} style={{
              flex: 1, background: "var(--panel)",
              border: `1.5px solid ${c.color}`,
              boxShadow: `0 0 0 3px ${c.color === "var(--pos)" ? "oklch(48% 0.11 155 / 0.13)" : "oklch(46% 0.07 200 / 0.13)"}`,
              borderRadius: "var(--r-lg)", padding: 16,
              display: "flex", flexDirection: "column", gap: 8,
            }}>
              <div style={{ fontSize: 11.5, fontWeight: 600, color: c.color, letterSpacing: "0.04em", textTransform: "uppercase" }}>{c.label}</div>
              <div className="mono" style={{ fontSize: 26, fontWeight: 600, color: c.color, letterSpacing: "-0.02em" }}>{c.value}</div>
              <div style={{ fontSize: 11, color: "var(--text-2)" }}>{c.sub}</div>
              <button style={{ marginTop: "auto", alignSelf: "flex-start", background: c.color, color: "#fff", border: 0, padding: "7px 12px", borderRadius: 7, fontSize: 11.5, fontWeight: 600 }}>Enter →</button>
            </div>
          ))}
        </div>
      </div>
      <Annotations notes={[
        { x: 16, y: 360, n: 1, side: "right", small: true, label: "On iPhone 12 the second card sits below the fold." },
      ]} />
    </div>
  );
}

function SplashProposedPhone() {
  return (
    <div className="artboard-app">
      <div style={{ height: 22, background: "var(--bg)" }} />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "stretch", justifyContent: "center", padding: 16, gap: 14 }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, marginBottom: 4 }}>
          <BrandMark />
          <div style={{ fontSize: 10, color: "var(--mute)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Paper trading</div>
        </div>
        <div style={{ fontSize: 17, fontWeight: 600, letterSpacing: "-0.015em", textAlign: "center", lineHeight: 1.3 }}>Pick a market to step into.</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 6 }}>
          <button style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 4, padding: 14, background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 10, boxShadow: "var(--shadow-sm)", textAlign: "left", cursor: "pointer" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}><span style={{ width: 6, height: 6, borderRadius: 99, background: "var(--pos)" }} /><span style={{ fontSize: 13, fontWeight: 600 }}>Stocks</span><span style={{ fontSize: 10, color: "var(--mute)", marginLeft: 2 }}>3 positions</span></div>
            <div className="mono" style={{ fontSize: 20, fontWeight: 600 }}>$124,316.42</div>
            <div style={{ fontSize: 10.5, color: "var(--mute)" }}>Day <span className="pos" style={{ fontWeight: 600 }}>+1.24%</span> · Open until 16:00</div>
          </button>
          <button style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 4, padding: 14, background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 10, boxShadow: "var(--shadow-sm)", textAlign: "left", cursor: "pointer" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}><span style={{ width: 6, height: 6, borderRadius: 99, background: "var(--accent)" }} /><span style={{ fontSize: 13, fontWeight: 600 }}>Crypto</span><span style={{ fontSize: 10, color: "var(--mute)", marginLeft: 2 }}>2 positions</span></div>
            <div className="mono" style={{ fontSize: 20, fontWeight: 600 }}>$8,402.10</div>
            <div style={{ fontSize: 10.5, color: "var(--mute)" }}>Day <span className="neg" style={{ fontWeight: 600 }}>−0.84%</span> · 24/7</div>
          </button>
        </div>
        <div style={{ fontSize: 10, color: "var(--mute)", textAlign: "center", marginTop: 8 }}>Tap the brand mark to switch any time</div>
      </div>
    </div>
  );
}

Object.assign(window, {
  SplashTodayDesktop, SplashProposedDesktop,
  SplashTodayIpad, SplashProposedIpad,
  SplashTodayPhone, SplashProposedPhone,
});
