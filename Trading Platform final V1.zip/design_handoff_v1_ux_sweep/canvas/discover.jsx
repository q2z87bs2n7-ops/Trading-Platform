/* ─────────────────────────────────────────────────────────────────
   Discover surface — current state + proposed redesign at 3 viewports.
   ───────────────────────────────────────────────────────────────── */

/* Hero card that's used in the CURRENT desktop discover */
function HeroCurrent() {
  return (
    <Card p="16px 18px">
      <Eyebrow>Account · paper</Eyebrow>
      <div className="mono" style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-0.02em", marginTop: 4 }}>
        {FMT.money(124316.42)}
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
        <PLChip value={1532.18} pct={0.0124} />
      </div>
    </Card>
  );
}

function SparkCardCurrent({ s }) {
  const up = s.day >= 0;
  return (
    <Card p="12px 14px">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <span style={{ fontSize: 13, fontWeight: 600 }}>{s.sym}</span>
        <span className={up ? "mono pos" : "mono neg"} style={{ fontSize: 12 }}>{FMT.pct(s.day)}</span>
      </div>
      <div className="mono" style={{ fontSize: 14, fontWeight: 600, marginTop: 2 }}>${s.last.toFixed(2)}</div>
      <div style={{ height: 24, marginTop: 6 }}>
        <Spark data={s.spark} color={up ? "var(--pos)" : "var(--neg)"} stroke={1} />
      </div>
    </Card>
  );
}

function AllocationCurrent() {
  return (
    <Card p="14px 16px">
      <Eyebrow>Allocation</Eyebrow>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 8 }}>
        <Donut size={56} thickness={11} parts={[
          { value: 38, color: "var(--pos)" },
          { value: 32, color: "var(--accent)" },
          { value: 25, color: "var(--warn)" },
          { value: 5,  color: "var(--panel-3)" },
        ]} />
        <div style={{ fontSize: 11, color: "var(--text-2)", lineHeight: 1.7 }}>
          <div>AAPL 38%</div>
          <div>NVDA 32%</div>
          <div>TSLA 25%</div>
          <div style={{ color: "var(--mute)" }}>Cash 5%</div>
        </div>
      </div>
    </Card>
  );
}

function DiscoverTodayDesktop() {
  const wl = window.MOCK.watchlist;
  return (
    <div className="silo-stocks artboard-app">
      {/* tiny header so the page reads as real */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 24px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <BrandMark size={24} />
          <span style={{ fontSize: 13, color: "var(--mute)", fontFamily: "var(--font-mono)" }}>Trading Platform · stocks · v1.4.2</span>
        </div>
        <ModePill active="Discover" />
      </div>

      <div style={{ flex: 1, overflow: "auto", padding: 20 }}>
        <SectionHeading label="Discover" ctx="stocks · paper" />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 280px", gap: 14 }}>
          {/* Left: hero + watchlist 3-col */}
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <HeroCurrent />
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
              {wl.map(s => <SparkCardCurrent key={s.sym} s={s} />)}
            </div>
            <div style={{
              border: "1px dashed var(--border-2)", borderRadius: "var(--r)",
              padding: 14, fontSize: 12, color: "var(--mute)", textAlign: "center",
            }}>+ Add to watchlist</div>
          </div>
          {/* Right: side rail */}
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <AllocationCurrent />
            <Card p="14px 16px">
              <Eyebrow>Market summary</Eyebrow>
              <div style={{ marginTop: 8, padding: "16px 12px", textAlign: "center", fontSize: 11.5, color: "var(--mute)", border: "1px dashed var(--border)", borderRadius: 8 }}>
                <div style={{ marginBottom: 4 }}>⚡ AI is off</div>
                <div>Turn it on in Settings to see a daily summary.</div>
                <div style={{ marginTop: 6, color: "var(--accent)", fontWeight: 500 }}>Open Settings →</div>
              </div>
            </Card>
          </div>
        </div>
      </div>
      <Annotations notes={[
        { x: 30, y: 90, n: 1, side: "right", label: "Hero is a single stacked metric block — no graphic anchor for the most-watched number on the page." },
        { x: 30, y: 215, n: 2, side: "right", label: "Spark cards are phone-sized at 3 cols. 18M sparkline + tiny green stroke on warm bg ≈ disappears on a sunlit laptop." },
        { x: 880, y: 90, n: 3, side: "left", label: "Allocation donut is the most visual element on the page, AND the smallest. Stuck in a side rail." },
        { x: 880, y: 320, n: 4, side: "left", label: "MarketSummary disabled state is colourless — no AI identity, no in-place 'turn on' CTA." },
      ]} />
    </div>
  );
}

/* ─── Proposed desktop Discover ──────────────────────── */
function HeroProposed() {
  return (
    <Card p="18px 20px">
      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 24, alignItems: "stretch" }}>
        <div>
          <Eyebrow>Equity · stocks · paper</Eyebrow>
          <div className="mono" style={{ fontSize: 36, fontWeight: 600, letterSpacing: "-0.02em", marginTop: 4 }}>
            {FMT.money(124316.42)}
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 8 }}>
            <PLChip value={1532.18} pct={0.0124} />
            <span style={{ fontSize: 11, color: "var(--mute)" }}>Day · vs market open</span>
          </div>
          <div style={{ display: "inline-flex", gap: 4, padding: 3, marginTop: 12, background: "var(--panel-2)", border: "1px solid var(--border)", borderRadius: 8 }}>
            {["1D","1W","1M","YTD","ALL"].map((p,i)=>(
              <span key={p} style={{
                fontSize: 11, padding: "4px 9px",
                background: i===0?"var(--panel)":"transparent",
                color: i===0?"var(--text)":"var(--text-2)",
                fontWeight: i===0?600:500,
                borderRadius: 6,
                boxShadow: i===0?"var(--shadow-sm)":"none",
              }}>{p}</span>
            ))}
          </div>
          <div style={{ marginTop: 14, height: 80 }}>
            <Spark data={window.MOCK.pnlCurve} color="var(--pos)" fill stroke={1.75} />
          </div>
        </div>
        <div style={{
          borderLeft: "1px solid var(--hairline)", paddingLeft: 20,
          display: "flex", flexDirection: "column", justifyContent: "space-between",
        }}>
          <Eyebrow>Allocation</Eyebrow>
          <div style={{ display: "flex", alignItems: "center", gap: 16, marginTop: 8 }}>
            <Donut size={120} thickness={20} parts={[
              { value: 38, color: "var(--pos)" },
              { value: 32, color: "var(--accent)" },
              { value: 25, color: "var(--warn)" },
              { value: 5,  color: "var(--panel-3)" },
            ]} />
            <div style={{ fontSize: 12.5, lineHeight: 1.8 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}><span style={{ width: 8, height: 8, background: "var(--pos)", borderRadius: 99 }} /><span style={{ fontWeight: 500 }}>AAPL</span><span className="mono" style={{ marginLeft: "auto", color: "var(--mute)" }}>38%</span></div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}><span style={{ width: 8, height: 8, background: "var(--accent)", borderRadius: 99 }} /><span style={{ fontWeight: 500 }}>NVDA</span><span className="mono" style={{ marginLeft: "auto", color: "var(--mute)" }}>32%</span></div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}><span style={{ width: 8, height: 8, background: "var(--warn)", borderRadius: 99 }} /><span style={{ fontWeight: 500 }}>TSLA</span><span className="mono" style={{ marginLeft: "auto", color: "var(--mute)" }}>25%</span></div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, color: "var(--mute)" }}><span style={{ width: 8, height: 8, background: "var(--panel-3)", border: "1px solid var(--border)", borderRadius: 99 }} /><span>Cash</span><span className="mono" style={{ marginLeft: "auto" }}>5%</span></div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}

function SparkCardProposed({ s }) {
  const up = s.day >= 0;
  return (
    <Card p="14px 16px">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <div>
          <div style={{ fontSize: 14, fontWeight: 600 }}>{s.sym}</div>
          <div style={{ fontSize: 10.5, color: "var(--mute)" }}>{s.name}</div>
        </div>
        <div className="mono" style={{ fontSize: 16, fontWeight: 600 }}>${s.last.toFixed(2)}</div>
      </div>
      <div style={{ height: 48, marginTop: 10 }}>
        <Spark data={s.spark} color={up ? "var(--pos)" : "var(--neg)"} fill stroke={1.5} />
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8 }}>
        <PLChip value={s.last * s.day} pct={s.day} sm />
        <span style={{ fontSize: 10.5, color: "var(--mute)", fontFamily: "var(--font-mono)" }}>Vol {s.vol} · {s.cap}</span>
      </div>
    </Card>
  );
}

function MarketSummaryProposed() {
  return (
    <Card p="14px 18px" style={{ borderLeft: "3px solid var(--cb-accent)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ color: "var(--cb-accent)", fontSize: 14 }}>✦</span>
        <div style={{ fontSize: 13, fontWeight: 600 }}>Mid-day update</div>
        <span style={{ marginLeft: "auto", fontSize: 10.5, color: "var(--mute)", fontFamily: "var(--font-mono)" }}>14:32 · refresh</span>
      </div>
      <div style={{ fontSize: 13, color: "var(--text-2)", lineHeight: 1.55, marginTop: 8 }}>
        Big tech leading the tape; semis green after a soft CPI print. Small-cap rotation continues into healthcare, particularly biotech. Crypto sees BTC consolidating near $108k.
      </div>
    </Card>
  );
}

function DiscoverProposedDesktop() {
  const wl = window.MOCK.watchlist;
  return (
    <div className="silo-stocks artboard-app">
      <div style={{
        display: "grid", gridTemplateColumns: "auto 1fr auto",
        alignItems: "center", columnGap: 24, padding: "12px 24px",
        background: "var(--panel)", borderBottom: "1px solid var(--border)",
      }}>
        <button style={{ display: "inline-flex", alignItems: "center", gap: 10, background: "transparent", border: 0, padding: 0, cursor: "pointer" }}>
          <BrandMark />
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15, alignItems: "flex-start" }}>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Stocks <span style={{ fontSize: 10, color: "var(--mute)" }}>▾</span></span>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 10.5, color: "var(--mute)" }}>
              <span style={{ width: 5, height: 5, borderRadius: 99, background: "var(--pos)" }} />
              Open · until 16:00
            </span>
          </div>
        </button>
        <div style={{ justifySelf: "center" }}><ModePill active="Discover" /></div>
        <div style={{ display: "inline-flex", alignItems: "center", gap: 12 }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", lineHeight: 1.15 }}>
            <span className="mono" style={{ fontSize: 13, fontWeight: 600 }}>{FMT.money(124316.42)}</span>
            <span className="mono pos" style={{ fontSize: 11, fontWeight: 600 }}>+1.24% today</span>
          </div>
          <IconBtn style={{ borderColor: "var(--accent)", color: "var(--accent)" }}>
            <span style={{ color: "var(--accent)" }}>✦</span>
            <span>Ask</span>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, padding: "1px 5px", border: "1px solid var(--border)", borderRadius: 4, color: "var(--mute)" }}>⌘K</span>
          </IconBtn>
          <IconBtn ghost style={{ width: 30, height: 30, justifyContent: "center" }}>☾</IconBtn>
          <IconBtn ghost style={{ width: 30, height: 30, justifyContent: "center" }}>⚙</IconBtn>
        </div>
      </div>

      <div style={{ flex: 1, overflow: "auto", padding: "20px 24px" }}>
        <HeroProposed />
        <div style={{ marginTop: 14 }}>
          <MarketSummaryProposed />
        </div>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginTop: 18, marginBottom: 10 }}>
          <SectionHeading size="lg" label="Watchlist" ctx="6 symbols · streaming" />
          <span style={{ fontSize: 11.5, color: "var(--mute)" }}>Sort: market value ▾</span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
          {wl.map(s => <SparkCardProposed key={s.sym} s={s} />)}
          <div style={{
            border: "1px dashed var(--border-2)", borderRadius: "var(--r)",
            display: "grid", placeItems: "center",
            fontSize: 13, color: "var(--mute)", cursor: "pointer",
            minHeight: 120,
          }}>+ Add a symbol</div>
        </div>
      </div>

      <Annotations notes={[
        { x: 40, y: 90, n: "A", side: "right", label: "Hero is 60/40 — equity + window switcher + day-curve sparkline (uses your usePnlHistory hook) on the left, allocation donut PROMOTED into the hero on the right." },
        { x: 880, y: 90, n: "B", side: "left", label: "Donut is large + has a labelled legend with %s. The most visual element on the page is now the most visible." },
        { x: 40, y: 365, n: "C", side: "right", label: "MarketSummary keeps the violet rail even when AI is on — credit-spending surfaces have a colour identity, like the chartbot rail." },
        { x: 40, y: 460, n: "D", side: "right", label: "Spark cards earn their density: name + cap + vol + 48px sparkline w/ 12% area fill. Reads on a sunlit laptop." },
      ]} />
    </div>
  );
}

/* ─── iPad portrait (Discover) ──────────────────────── */
function DiscoverTodayIpad() {
  const wl = window.MOCK.watchlist.slice(0, 4);
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ padding: "10px 18px", background: "var(--panel)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><BrandMark size={24} /><span style={{ fontSize: 13, fontWeight: 600 }}>Discover</span></div>
        <ModePill active="Discover" />
      </div>
      <div style={{ flex: 1, padding: 16, overflow: "auto" }}>
        <HeroCurrent />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 12 }}>
          {wl.map(s => <SparkCardCurrent key={s.sym} s={s} />)}
        </div>
        <div style={{ marginTop: 12 }}><AllocationCurrent /></div>
      </div>
    </div>
  );
}

function DiscoverProposedIpad() {
  const wl = window.MOCK.watchlist.slice(0, 4);
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ padding: "10px 18px", background: "var(--panel)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <button style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "transparent", border: 0, padding: 0, cursor: "pointer" }}>
          <BrandMark size={24} />
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15, alignItems: "flex-start" }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>Stocks ▾</span>
            <span style={{ fontSize: 10, color: "var(--mute)", display: "inline-flex", alignItems: "center", gap: 4 }}>
              <span style={{ width: 5, height: 5, borderRadius: 99, background: "var(--pos)" }} />Open · until 16:00
            </span>
          </div>
        </button>
        <ModePill active="Discover" />
      </div>
      <div style={{ flex: 1, padding: 16, overflow: "auto" }}>
        <HeroProposed />
        <div style={{ marginTop: 12 }}><MarketSummaryProposed /></div>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginTop: 16, marginBottom: 8 }}>
          <SectionHeading size="md" label="Watchlist" ctx="6 symbols · streaming" />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {wl.map(s => <SparkCardProposed key={s.sym} s={s} />)}
        </div>
      </div>
    </div>
  );
}

/* ─── iPhone 12 ───────────────────────────────────────── */
function DiscoverTodayPhone() {
  const wl = window.MOCK.watchlist.slice(0, 4);
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ height: 22, background: "var(--panel)" }} />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <span style={{ fontSize: 18 }}>☰</span>
        <span style={{ fontSize: 14, fontWeight: 600 }}>Discover</span>
        <div style={{ display: "flex", gap: 6 }}>
          <IconBtn style={{ borderColor: "var(--accent)", color: "var(--accent)", width: 28, height: 28, justifyContent: "center" }}>✦</IconBtn>
          <IconBtn style={{ width: 28, height: 28, justifyContent: "center" }}>⚙</IconBtn>
        </div>
      </div>
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        padding: "6px 14px", fontSize: 11,
        background: "var(--panel)", borderBottom: "1px solid var(--border)",
      }}>
        <span style={{ width: 7, height: 7, borderRadius: 99, background: "var(--pos)" }} />
        <span style={{ fontWeight: 700, color: "var(--pos)", fontSize: 10.5 }}>OPEN</span>
        <span style={{ color: "var(--mute)", fontSize: 10 }}>16:00</span>
        <button style={{ marginLeft: "auto", display: "inline-flex", alignItems: "center", gap: 5, background: "transparent", border: 0, padding: 0 }}>
          <span className="mono" style={{ fontWeight: 600, fontSize: 12 }}>$124,316</span>
          <Chip color="var(--pos)" bg="var(--pos-bg)" sm>+1.24%</Chip>
          <span style={{ color: "var(--mute)", fontSize: 10 }}>▾</span>
        </button>
      </div>
      <div style={{ flex: 1, padding: 12, overflow: "auto" }}>
        <Card p="14px 16px">
          <Eyebrow>Equity</Eyebrow>
          <div className="mono" style={{ fontSize: 28, fontWeight: 600, marginTop: 4 }}>{FMT.money(124316.42)}</div>
          <div style={{ marginTop: 6 }}><PLChip value={1532.18} pct={0.0124} /></div>
          <div style={{ marginTop: 8 }}><Donut size={56} thickness={11} parts={[
            { value: 38, color: "var(--pos)" }, { value: 32, color: "var(--accent)" }, { value: 25, color: "var(--warn)" }, { value: 5, color: "var(--panel-3)" }
          ]} /></div>
        </Card>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 10 }}>
          {wl.map(s => <SparkCardCurrent key={s.sym} s={s} />)}
        </div>
      </div>
    </div>
  );
}

function DiscoverProposedPhone() {
  const wl = window.MOCK.watchlist.slice(0, 4);
  return (
    <div className="silo-stocks artboard-app">
      <div style={{ height: 22, background: "var(--panel)" }} />
      <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", columnGap: 10, alignItems: "center", padding: "10px 14px", background: "var(--panel)", borderBottom: "1px solid var(--border)" }}>
        <span style={{ fontSize: 18 }}>☰</span>
        <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.15 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>Discover</span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 10.5, color: "var(--mute)" }}>
            <span style={{ width: 5, height: 5, borderRadius: 99, background: "var(--pos)" }} />
            Open · until 16:00
          </span>
        </div>
        <button style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 9px", background: "var(--panel)", border: "1px solid var(--border)", borderRadius: 8 }}>
          <span className="mono" style={{ fontWeight: 600, fontSize: 12 }}>$124,316</span>
          <Chip color="var(--pos)" bg="var(--pos-bg)" sm>+1.24%</Chip>
        </button>
      </div>
      <div style={{ flex: 1, padding: 12, overflow: "auto" }}>
        <Card p="14px 16px">
          <Eyebrow>Equity</Eyebrow>
          <div className="mono" style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-0.02em", marginTop: 2 }}>{FMT.money(124316.42)}</div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 6 }}>
            <PLChip value={1532.18} pct={0.0124} />
          </div>
          <div style={{ marginTop: 10, height: 48 }}>
            <Spark data={window.MOCK.pnlCurve} color="var(--pos)" fill stroke={1.5} />
          </div>
          <div style={{ display: "inline-flex", gap: 4, padding: 3, marginTop: 10, background: "var(--panel-2)", border: "1px solid var(--border)", borderRadius: 8 }}>
            {["1D","1W","1M","YTD","ALL"].map((p,i)=>(
              <span key={p} style={{
                fontSize: 10, padding: "3px 8px",
                background: i===0?"var(--panel)":"transparent",
                color: i===0?"var(--text)":"var(--text-2)",
                fontWeight: i===0?600:500, borderRadius: 5,
                boxShadow: i===0?"var(--shadow-sm)":"none",
              }}>{p}</span>
            ))}
          </div>
        </Card>
        <div style={{ marginTop: 10 }}><MarketSummaryProposed /></div>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginTop: 14, marginBottom: 8 }}>
          <span style={{ fontSize: 13, fontWeight: 600 }}>Watchlist</span>
          <span style={{ fontSize: 10.5, color: "var(--mute)" }}>6 symbols</span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {wl.map(s => <SparkCardProposed key={s.sym} s={s} />)}
        </div>
      </div>
      {/* floating ✦ Ask launcher */}
      <button style={{
        position: "absolute", right: 14, bottom: 70, zIndex: 5,
        width: 44, height: 44, borderRadius: 99, border: 0,
        background: "var(--accent)", color: "#fff", fontSize: 18,
        boxShadow: "var(--shadow)", cursor: "pointer",
      }}>✦</button>
    </div>
  );
}

Object.assign(window, {
  DiscoverTodayDesktop, DiscoverProposedDesktop,
  DiscoverTodayIpad, DiscoverProposedIpad,
  DiscoverTodayPhone, DiscoverProposedPhone,
});
