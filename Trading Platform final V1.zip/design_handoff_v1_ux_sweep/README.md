# Handoff — Trading Platform V1 UX sweep

Pre-demo polish pass for the paper-trading platform built on Alpaca. The
intent of this package is a focused implementation sprint — there's a
prioritized list of 12 changes, each tied to specific files in the existing
codebase.

---

## 1 · What's in this package

```
design_handoff_v1_ux_sweep/
├── README.md                  ← this file. Start here.
├── PRIORITIES.md              ← the 12 changes, ordered by impact / effort.
├── SURFACES.md                ← per-surface implementation specs with file pointers.
├── TOKENS.md                  ← design-system reference (already in the codebase).
├── PROMPTS.md                 ← copy-paste prompts for Claude Code, one per priority.
└── canvas/                    ← the visual design references (open index.html).
    ├── index.html             ← pan/zoom canvas with every surface, current + proposed.
    ├── tokens.css             ← exact Calm v2 tokens lifted from frontend/src/index.css.
    ├── lib.jsx                ← shared primitives used across all artboards.
    ├── splash.jsx             ← Splash & Hub artboards (today vs proposed).
    ├── topbar.jsx             ← TopBar artboards.
    ├── discover.jsx           ← Discover artboards.
    ├── portfolio.jsx          ← Portfolio artboards.
    ├── trade.jsx              ← TradeBar + OrderSheet artboards.
    ├── chart.jsx              ← Chart mode + ChartBot artboards.
    ├── workspace.jsx          ← Workspace artboards.
    ├── app.jsx                ← Canvas assembly.
    ├── design-canvas.jsx      ← Pan/zoom container.
    └── data.js                ← Mock data so the mockups look real.
```

---

## 2 · About the design files

**The files in `canvas/` are design references created in HTML + JSX. They
are not production code to copy.**

Each artboard recreates the surface using the project's actual
[Calm v2 design tokens](./TOKENS.md), real Inter / IBM Plex Mono typography,
and tabular numerals — so the visual decisions read pixel-accurate against
the live app. But the React inside each artboard is a sketch: inline styles,
no hooks, no state management, no a11y refinement.

**Your job: recreate the *proposed* artboards in the existing
`frontend/` codebase using its established patterns** — Tailwind utilities
where they've been migrated, hand-styled spans where they haven't,
`useAccount` / `usePnlHistory` / `useWatchlist` hooks for real data,
`SectionHeading` / `IconButton` / `Card` / etc. for shared primitives.

The canvas exists to settle visual decisions and call out what changes,
not to be copied. Do not paste the styles object from `splash.jsx` into a
component. Read what the artboard expresses, then build it in the
codebase's vocabulary.

### Fidelity

**High-fidelity.** Colors, type, spacing, radii, and shadows are exact
(all token-driven). Layout grid columns / gaps / breakpoints are exact.
Copy is final. Annotation pins on each artboard call out the specific
intent change vs. the existing surface.

---

## 3 · The 12-change implementation plan

See [PRIORITIES.md](./PRIORITIES.md) for the ordered list with effort
estimates and per-change rationale. Summary:

| # | Change | Effort | Surface |
|---|---|---|---|
| 1 | TopBar → one row, three zones | ~3 h | `App.tsx`, `TopBar.tsx` |
| 2 | TradeBar → OrderSheet continuity | ~3 h | `trade/TradeBar.tsx`, `trade/OrderSheet.tsx` |
| 3 | Desktop Discover hero + 2-col cards | ~4 h | `DiscoverPage.tsx`, `BalanceCard.tsx`, `SparkCard.tsx` |
| 4 | Calm the splash, promote the brand button | ~2 h | `AssetClassSplash.tsx`, `App.tsx` |
| 5 | Workspace channels-as-centrepiece | ~4 h | `Workspace.tsx` |
| 6 | ChartBot rail + chip empty state | ~2 h | `chat/ChatPanel.tsx`, `chat/ChatEmptyState.tsx` |
| 7 | AI disabled-state CTA + first-open hints | ~2 h | `AiDisabledNotice.tsx`, `ask/AskBar.tsx` |
| 8 | Portfolio hierarchy (Hero / Positions primary) | ~3 h | `PortfolioHero.tsx`, `Positions.tsx`, `Orders.tsx` |
| 9 | One mobile header strip | ~2 h | `MobileHeader.tsx`, `TopBar.tsx` |
| 10 | The polish nits (top 8) | ~1 d | mixed |
| 11 | Split `OrderSheet.tsx` (1,390 → 4 files) | ~1-2 d | `trade/OrderSheet.tsx` (code-health, no visual change) |
| 12 | Finish Tailwind preflight migration | ~1 d | `tailwind.config.js` + grep |

**Recommended sequence:** ship 1-3 first as a single PR — that's the
demo-blocker tier and they share enough vocabulary (brand button, equity
readout, accent system) that doing them together avoids rework.

---

## 4 · What NOT to do

Restraint matters. Several decisions in the existing app are deliberate
and should be left alone:

- **Don't touch the OKLCH palette.** Hard-won, calibrated for the warm bg, and the single best visual signal a trading-firm reviewer will register. See `frontend/src/index.css`.
- **Don't replace TradingView's native chrome.** Their library's drawing rail / Account Manager / header is kept *intentionally* (see `docs/landmines.md`). The chrome *around* it is what changes — our chrome.
- **Don't redesign the channel concept.** Just promote it visually (priority 5). The model is right.
- **Don't add new AI surfaces.** Market Summary, Ask anything, and ChartBot is the right three. Make them feel finished; don't ship a fourth.
- **Don't add filler.** No trending-stocks carousel, no news ticker, no onboarding modal. The app's restraint is its strength.

---

## 5 · Things to confirm with the team before shipping

A handful of decisions are bigger than a polish pass — surface them and
get a thumbs-up:

1. **Splash dismissal model.** The current behaviour is "splash every load."
   Proposal in priority 4: first session only, then dismiss; brand-button
   re-opens. Confirm with @Craig before changing the dismissal logic.
2. **Workspace gating on iPad portrait.** Today's Workspace works on iPad
   but Dockview's touch behaviour is rough at that size. Proposal: hide
   the Workspace mode pill on iPad portrait, allow on landscape (≥ 1024
   px). Alternative: bump resize handles to 12 px on `pointer: coarse`.
3. **Equity-curve full-bleed hero.** Optional aggressive move in
   `PortfolioHero` — make the hero card a full equity-curve panel with
   the number floated over it. Don't do this without product sign-off.

---

## 6 · How to use the canvas

Open `canvas/index.html` in a browser. Pan with click-drag, zoom with
trackpad pinch, double-click any artboard to focus it fullscreen (Esc
exits). Each artboard has a "Hide notes" button in the corner — toggle
the red annotation pins on/off.

Sections, in order:
1. **Splash & Hub** — first screen.
2. **App shell / TopBar** — chrome.
3. **Discover** — landing surface.
4. **Portfolio** — hero + positions + orders.
5. **TradeBar → OrderSheet** — order flow.
6. **Chart & ChartBot** — TV mode + the right rail.
7. **Workspace** — channels rework.

Within each section, current state and proposed state sit side-by-side at
iPhone 12 (390 px wide) / iPad portrait (834 px) / Desktop (1280 px).

---

## 7 · Codebase orientation reminder

Pulled from the conversation that produced this handoff, in case useful:

- **Design tokens** live in `frontend/src/index.css` (Calm v2). OKLCH-defined accents, dark-mode under `html[data-theme="dark"]`.
- **Tailwind preflight is OFF** (`tailwind.config.js`). Some surfaces are hand-styled, some use utilities. Don't introduce new utility-only components in hand-styled areas without finishing the migration first.
- **TradingView is on a CDN bridge** — see `docs/landmines.md` for the gotchas; don't fight it.
- **Streaming relay** has a 9-minute keepalive ping; the yellow "Polling · stream off" chip is intentional honesty about backend state.
- **All three AI flags default off** (`docs/ai.md`). Build the disabled state to look intentional.

Good luck. Ship the first three changes, then check in.
