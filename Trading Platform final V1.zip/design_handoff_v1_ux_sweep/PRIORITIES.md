# Priorities

The 12-change implementation plan, ordered by impact-per-hour. Each entry
is a code-pointer + a one-paragraph rationale. Detailed visual specs are
in [SURFACES.md](./SURFACES.md); copy-paste prompts are in [PROMPTS.md](./PROMPTS.md).

---

## Tier 1 — demo blockers (do these first)

### 1 · TopBar → one row, three zones · ~3 h
**Files:** `frontend/src/App.tsx` (top row), `frontend/src/components/TopBar.tsx` (status strip)

Today the desktop has two header rows: `BrandMark · version · stocks/crypto
toggle · Modes · Ask · ☾ · ⚙` then `Polling · OPEN · Equity ▾ · Day P/L
· BP`. Six surface treatments in ~80 px. Collapse to one row, three zones:

- **Left** — single brand button (silo name + version + inline OPEN/CLOSED status). Tapping re-opens the hub. Asset-class toggle dies — switching silo is what the hub is *for*.
- **Centre** — Modes pill, centred. Primacy by position.
- **Right** — Equity + Day-% as a single right-aligned readout, then `✦ Ask · ⌘K` · ☾ · ⚙.

Status strip deletes entirely. Polling chip becomes a yellow dot next to
the silo dot, only visible when actually polling. BP moves to the
Portfolio hero (it's buying power, not session status).

Canvas: `splash-d-now` vs `splash-d-new`, `shell-d-*`, `shell-i-*`, `shell-p-*`.

### 2 · TradeBar → OrderSheet continuity · ~3 h
**Files:** `frontend/src/components/trade/TradeBar.tsx`, `frontend/src/components/trade/OrderSheet.tsx`

Today the TradeBar (slim dock with symbol pill + live quote + Buy/Sell)
and the OrderSheet (centred modal with its own header + side picker +
fields) read as two unrelated tools. Three moves:

1. **The TradeBar's symbol chip visually becomes the sheet's header chip.** Use a FLIP-style transition or just keep the same shape so the eye reads continuity.
2. **The side decision is sticky.** Tapping Buy on the bar opens the sheet with the Buy face filled (green); tapping Sell opens it Sell-filled (red). The face stays tappable to switch, which re-colours the primary CTA.
3. **Estimated cost is a coloured pill** (matches the side colour) — same treatment as the bar's quote chip. Primary CTA reads the trade back: *"Buy 10 AAPL · $2,248.30"*, never "Review & place".

Canvas: `trade-p-now`, `trade-p-new-buy`, `trade-p-new-sell`, `trade-p-new-crypto`, `trade-d-new`.

### 3 · Desktop Discover hero + 2-col cards · ~4 h
**Files:** `frontend/src/components/DiscoverPage.tsx`, `frontend/src/components/discover/BalanceCard.tsx`, `frontend/src/components/discover/SparkCard.tsx`, `frontend/src/components/discover/AllocationCard.tsx`

Desktop Discover today: stacked metric block hero on the left, 3-col
SparkCards underneath, allocation donut + summary in a 280 px side rail.
Phone cards on a desktop. Three moves:

1. **Hero promotion** — 60/40 split: equity + window switcher (1D/1W/1M/YTD/ALL) + a ~70 px PnL curve from `usePnlHistory` on the left, allocation donut + labelled legend (% per symbol) on the right.
2. **Spark cards earn density** — name + market cap + volume + a 48 px sparkline with 12% area fill. Stroke bumps to 1.5 px (already done in the hero sparkline). 2-col on iPad, 3-col on desktop.
3. **MarketSummary keeps a violet identity** — 3 px left rail in `--cb-accent`, ✦ glyph, "refresh" link. When AI is off, the rail STAYS on the AiDisabledNotice so the user retains spatial memory of where the summary was.

Canvas: `disc-d-*`, `disc-i-*`, `disc-p-*`.

---

## Tier 2 — fast wins

### 4 · Calm the splash, promote the brand button · ~2 h
**Files:** `frontend/src/components/AssetClassSplash.tsx`, `frontend/src/App.tsx`

Today's splash is two huge cards with 1.5 px accent borders + 3 px outer
rings + inner filled CTAs + equity heroes in colour. Reads like a Stripe
"pick your plan" landing. Proposed: calm summary cards (1 px borders,
whole-card affordance, no inner CTA, equity as content not billboard),
mirroring pattern across silos (stocks shows Day-% + session-status,
crypto shows Day-% + "24/7"). Brand mark in TopBar becomes a real button
with a ▾ chevron — that's the new way to re-open the hub.

**Pair with #1** — they share the brand-button definition.

Canvas: `splash-d-*`, `splash-i-*`, `splash-p-*`.

### 5 · Workspace channels-as-centrepiece · ~4 h
**Files:** `frontend/src/components/Workspace.tsx` (ChannelsStrip + toolbar)

Today the toolbar stacks `+ Add widget` · `Layouts ▾` · `Channels` (with
4 chips) as peer-level controls. The channel concept is the most
innovative thing in the app and visually it's the most generic.

- **Channels become the toolbar centrepiece** — boxed, eyebrow-labelled, centred. Active channels show widget count. Empty channels render as dashed-outline `+ green / + amber` affordances (one tap to bind a symbol — self-explanatory before the user reads docs).
- **Layouts** moves left as a NAMED preset (`▦ Trader ▾`) instead of generic "Layouts ▾".
- **+ Widget** drops to a quiet right-side ghost button.
- **Empty state gets a third option**: `✦ Ask AI to build one` with violet outline + inline example caption — surfaces the killer feature that's currently hidden behind ⌘K.

Canvas: `ws-d-now`, `ws-d-new`, `ws-empty-now`, `ws-empty-new`.

### 6 · ChartBot rail + chip empty state · ~2 h
**Files:** `frontend/src/components/chat/ChatPanel.tsx`, `frontend/src/components/chat/ChatEmptyState.tsx`, `frontend/src/components/chat/ChatHeader.tsx`

Today, when ChatPanel collapses, a small violet ✦ circle hovers as a
floating button over TV's pane — looks like a chat-widget drop. Two
moves:

- **Collapsed stub becomes a 36 px full-height vertical rail** in `--cb-accent` at low opacity, ✦ at top, rotated `CHARTBOT` label, expand chevron at bottom. Now reads as a permanent feature of the UI, not debris.
- **Expanded header carries chart context.** Today: `ChartBot · clear · ×`. Proposed: small `AAPL` chip + `5m · NASDAQ · streaming` underneath. The bot visibly *knows* what you're looking at.
- **Empty-state prompts become verb-chips.** Today they're wall-of-text. Proposed: `Draw · support at yesterday's low`, `Add · 50-MA + RSI`, `Mark · earnings beats`, `Summarise · this chart`. Background `--cb-accent-soft`, rounded full, leading bold verb.

Canvas: `chart-d-*`.

### 7 · AI disabled-state CTA + first-open hints · ~2 h
**Files:** `frontend/src/components/AiDisabledNotice.tsx`, `frontend/src/components/ask/AskBar.tsx`, `frontend/src/components/chat/ChatPanel.tsx`, `frontend/src/components/SettingsMenu.tsx`

Today the `AiDisabledNotice` is a colourless flat container. Since all
three AI flags default off, this is the first AI surface a reviewer
sees and it reads as "feature missing." Two moves:

- **Keep the AI surface's colour identity** when disabled — `--cb-accent` (violet) rail on MarketSummary/ChartBot disabled state, `--accent` (teal/blue) rail on Ask disabled state.
- **"Turn on" becomes a CTA in the notice itself.** Inline button, deep-linked to the right Settings toggle. Add a `~$0.001 per generation` caveat so the credit cost is transparent.
- **First-open footer hint** names the convention in 12 words on AskBar and ChartPanel — *"Teal — instant local parse · free · always on."* / *"Violet — cloud AI · ~3-5 s."* Dismissible; never seen again after first 2-3 opens.

Canvas: see annotation pins on `chart-d-new-expanded` (footer hint).

### 8 · Portfolio hierarchy (hero + primary positions) · ~3 h
**Files:** `frontend/src/components/PortfolioHero.tsx`, `frontend/src/components/SectionHeading.tsx`, `frontend/src/components/Positions.tsx`, `frontend/src/components/Orders.tsx`, `frontend/src/components/Activities.tsx`

Today all four sections (Hero · Positions · Orders · Activity) use the
same `SectionHeading` at the same size. Reads as one long uniform list.

- **Promote the hero**: 38 px equity, window switcher (1D / 1W / 1M / YTD / ALL), inline Cash / Buying Power / Total P/L / Realised metrics, ~70 px PnL curve.
- **`SectionHeading` gets a size variant.** Positions uses `size="lg"`; Orders / Activity stay `size="md"`. Positions block is full-width with a taller heading.
- **Orders + Activity drop to a secondary two-column row** below Positions. Orders rows stay actionable (inline `Cancel` button — replace the existing `window.confirm()` for cancel-all with an inline confirm row). Activity gets a "View all →" footer and pagination.

Canvas: `port-d-*`, `port-i-*`, `port-p-*`.

### 9 · One mobile header strip · ~2 h
**Files:** `frontend/src/components/MobileHeader.tsx`, `frontend/src/components/TopBar.tsx` (MobileStatusStrip)

Today mobile has two strips: `MobileHeader` (☰ + page name + ✦ + ⚙) and
`MobileStatusStrip` (polling + OPEN/CLOSED + equity ▾). On iPhone 12
this eats ~62 pt before content.

Merge to one strip: ☰ on the left, page name + inline `● Open · until
16:00` micro-status, equity-pill on the right. ✦ Ask moves to a small
floating launcher (44×44, bottom-right) — same affordance ChartBot uses
already.

Canvas: `shell-p-now` vs `shell-p-new`, also `disc-p-new` shows the
floating launcher.

---

## Tier 3 — drag-a-Tuesday-across

### 10 · The polish nits (top 8 from the catalog) · ~1 d

Pick from this list, all individually small:

- **Theme glyph** — swap to ☀ in dark / ☾ in light (name the destination). `App.tsx` ThemeToggle.
- **SettingsMenu grouping** — AI / Account / System with thin separators. `SettingsMenu.tsx`.
- **Loading skeletons** — 4-line shimmer on each card at first load. Reuse one component across `PortfolioHero`, `Discover`, `Positions`.
- **Toaster spacing** — 8 px gap between stacked toasts, max-3-visible, count overflow. `Toaster.tsx`.
- **Dark-mode `--pos`** — bump to ~62 % lightness so positive P/L rows stop looking "selected." `index.css` dark variant.
- **Cancel-all inline confirm** — replaces `window.confirm()` in `Orders.tsx`.
- **`SheetHandle` component** — extract the 36×4 grabber, use everywhere. `EquitySheet`, `OrderSheet`, `BalanceSheet`, `AddToWatchlistSheet`. Bonus: real swipe-to-dismiss.
- **ChartBot "clear" → ⋯ menu** — destructive, shouldn't be one mis-click away. `ChatHeader.tsx`.

### 11 · Split `OrderSheet.tsx` (1,390 → 4 files) · ~1-2 d
**Files:** `frontend/src/components/trade/OrderSheet.tsx`

Pure code-health. No visual change. Crypto vs stock branches,
market/limit/stop/stopLimit/trailing branches, mobile vs desktop, TIF
gating, fractional-quantity logic, est-cost compute, AssetSearch popover —
all in one file. Split:

- `OrderSheet.tsx` — shell + state
- `OrderSheetFields.tsx` — fields per order type
- `OrderSheetConfirm.tsx` — confirm step
- `useOrderTicket.ts` — state hook

Demo reviewers *will* read code; 1,390 lines in one TSX is a red flag.

### 12 · Finish (or hard-cap) the Tailwind preflight migration · ~1 d
**Files:** `frontend/tailwind.config.js`, grep for `<button>` / `<input>` / `<ul>` in `components/`

Today `corePlugins.preflight: false`. Pre-migration branches ride on
browser-default styles; migrated branches use utilities. Visible tells:
inconsistent button focus rings, bullet list rendering inside ChatPanel
bubbles, margin drift between hand-styled and utility-styled containers.

Two paths:

- **A · Finish the migration.** Enable preflight, fix every regression. Right answer, takes longer.
- **B · Ship a minimal `app-reset.css`** that zeros the 4-5 things preflight would have killed: button background/border/padding, list-style, fieldset margin, h1–h6 margins. Safe.

Recommend B before the demo, A after.
